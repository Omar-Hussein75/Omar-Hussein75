# Technical architecture and implementation plan

Status: approved direction for implementation. No application code ships with this document.

Audience: engineers implementing the Angular SPA and the API it depends on.

Angular facts below match the Angular 22 line (stable 22.1.x as of September 2026; 22.2 was still a release candidate). Re-check the patch version at M1 scaffold time and pin it.

---

## 1. Analysis

### 1.1 What the system is

An authenticated Angular SPA. Operators open a configured view, set a bounded filter, and see one of:

- a page of rows
- an aggregated chart or KPI
- the status of an export job, then a file download

Administrators publish the navigation tree, the parameter set, and the permission required to open a view. They do not publish components, scripts, or URLs.

The backend owns filtering, sorting, pagination, aggregation, search, export generation, and authorization. The SPA owns presentation of bounded results and the request lifecycle around them.

### 1.2 Architectural problems in the requirements

These are the problems that will make the application fail if they are treated as library choices instead of design constraints.

**1. Dynamic navigation is easy to turn into remote code execution.**

If an admin field is a component path, a script, or an arbitrary API URL, the configuration store becomes an injection channel. A stolen admin account, or a bug in config validation, would let the browser load code or send data to an unexpected host. The SPA also cannot keep a secure route table if every new report adds a hand-written route that must be deployed.

**2. “Virtual scrolling” does not make a million-row array safe.**

CDK virtual scroll and AG Grid row virtualization limit DOM nodes. They do not limit transfer size or JavaScript heap. Holding the export in memory, then windowing it, still freezes the tab. Infinite scroll that appends every block has the same failure, delayed by a few minutes.

**3. Offset pagination and exact totals do not scale.**

`page=5000&pageSize=100` forces the database to walk and discard hundreds of thousands of rows. `COUNT(*)` on a weakly filtered fact table is often slower than the page query. A UI that always asks for “page 12 of 4,821,003” creates the expensive query even when the user only needed the next screen.

**4. A chart library cannot repair an unbounded series.**

Sending a year of raw network samples to ECharts, uPlot, or Highcharts copies the large-data problem into a canvas. Client-side downsampling still requires the raw series to arrive first. The contract has to cap points before the response is built.

**5. Browser-side export copies the dataset into the worst possible place.**

Building a multi-million-row CSV or Parquet file in JavaScript retains multiple copies of the data (source array, serialized string, Blob). `fetch().blob()` does the same on download. The download manager can stream a `Content-Disposition: attachment` response to disk. The page should not.

**6. Filter-as-you-type against a warehouse is a self-inflicted outage.**

Each change of region, site, and status is a new heavy query. Without cancellation, the January response can arrive after February and render stale data. Without an explicit apply step, cascading selects fan out into parallel full scans.

**7. Global state duplicates the only data that is large.**

A root store that caches every report response, plus a component copy, plus an HTTP cache, multiplies the heap. Invalidating that cache on permission changes is also easy to get wrong: a cached response from another user or another region is an authorization bug, not a performance feature.

**8. Frontend permission checks are a navigation hint.**

Hiding a nav item does not stop a pasted URL or a replayed `POST /query`. Parameter constraints such as “this user only sees region EU” must be applied by the server onto the query. If the client sends them, the client can omit them.

**9. Admin-configured endpoints are server-side request forgery if the API fetches them, and data exfiltration if the browser calls them.**

The report identifier in configuration must be a key in a server-side catalog. The browser always calls the platform API. The platform resolves the key to a data source.

**10. Dynamic parameters are an injection surface.**

A filter document that accepts field names, operators, and nested boolean trees is powerful enough to be abused if the server concatenates it into SQL, Elasticsearch query strings, or an ORM expression. The field catalog is an allowlist. The operator list is an enum. Values are typed. Cursors are opaque and signed.

**11. Change detection and template work become the bottleneck after the data is already small.**

A 100-row page can still stutter if every keystroke runs default change detection over a large component tree, if templates call methods that sort or map arrays, or if chart options objects are recreated on every pass. Zoneless Angular removes the zone, and it does not remove those patterns.

**12. Caching the wrong thing is both a performance and a security defect.**

A service worker that caches `POST /query` responses will show stale rows after a permission revocation and can leak a previous user’s body on a shared machine. IndexedDB is the same risk with a larger quota.

**13. Observability that logs payloads will store customer data.**

API timing is required. Request and response bodies of report queries are not telemetry. Filter values often contain customer identifiers, site names, and account numbers.

**14. SSR does not help this application.**

The useful bytes are authorized, user-specific, and query-specific. Server-rendering them increases complexity, makes caching harder, and does not reduce the cost of a warehouse query. The shell can be a small client-rendered bundle.

### 1.3 Design principle

Minimize, in order:

1. bytes transferred
2. bytes retained in the JavaScript heap
3. bytes processed on the main thread
4. DOM nodes mounted

The server performs work that grows with the size of the export. The browser performs work that grows with the size of the viewport.

### 1.4 Non-goals for the first releases

- Ad hoc SQL, query builders that accept expressions, or user-supplied widgets
- Client-side OLAP, pivot of a loaded fact table, or spreadsheet editing of the export
- Offline access to report rows
- Server-side rendering or hydration of report data
- A native mobile client
- A general workflow engine

Pivot and grouping can be added later as server-side operations. They are not a reason to load the fact table.

---

## 2. Phase 1 — Architecture

### 2.1 System context

```text
Browser SPA
    │  cookie session, same origin
    ▼
BFF / API gateway
    │  session, CSRF check, body limit, rate limit
    ▼
Application API
    │  permission check, parameter schema, mandatory filters
    ├── Report catalog  → warehouse / operational stores
    ├── Reference data  → small dimension tables
    ├── Config store    → published navigation and view metadata
    └── Export workers  → object storage, presigned download
```

The SPA has one origin. It never receives a warehouse connection string, a storage credential, or an upstream URL.

### 2.2 Frontend architecture

Standalone Angular 22 application. Zoneless change detection is the framework default from v21 onward and stays on. New applications use `OnPush` as the default strategy; feature components keep that default. State that the template reads is held in signals.

Layers, and the only direction of calls:

```text
Route component
    → View facade (view-scoped)
        → Query gateway or metadata API (application-wide)
            → HttpClient (fetch backend)
                → BFF
```

Components do not inject `HttpClient`. Facades do not build URLs from configuration. The gateway is the only place that knows URL shapes.

| State | Owner | Lifetime | Size bound |
| --- | --- | --- | --- |
| Session and permission set | `SessionStore` | until logout | kilobytes |
| Published navigation and view metadata | `ConfigStore` | session, revalidated | kilobytes to low hundreds of KB |
| Filter draft | view component signals | view | kilobytes |
| Current page or current series | view-scoped facade | view, replaced on each apply | one page or one capped series |
| Request status | `httpResource` or gateway signal | in flight | one status per request |
| UI preferences (density, column widths, sidebar) | `PreferencesStore` | persisted locally | kilobytes |
| Export job ids the user is watching | `ExportTracker` | until terminal or logout | tens of jobs |

`ReportFacade` is provided on the view route component, not `providedIn: 'root'`. When the user leaves the view, the facade is destroyed, in-flight work is aborted, and the page array becomes unreachable.

There is no NgRx, NGXS, or Akita in the first releases. A root store would encourage copying pages into global state. Revisit a signal store library only when a workflow must survive across several views with a small shared model (for example a reconciliation case id and its status). Row payloads stay out of that store.

RxJS remains at the edges where streams are the right tool: typeahead, export polling, and router events. `httpResource` and `resource` are stable in Angular 22 and are the default for reactive reads. Mutations, including `POST /query` and `POST /exports`, use `HttpClient` directly. The framework documentation explicitly steers `httpResource` away from mutations.

### 2.3 Routing and lazy loading

Navigation is data. The router stays a closed set:

```text
/login
/app
/app/views/:viewId
/app/exports
/app/exports/:jobId
/admin
/admin/navigation
/admin/views/:viewId
/admin/access
```

`viewId` is an opaque id generated by the server. A human slug may be displayed in the breadcrumb. It is not a path the router interprets, and it is not a file path.

`ViewHost` loads the published view definition, checks that the session permission set contains `requiredPermission` (a hint), then resolves `view.kind` through a registry that exists only in source code:

```ts
export const VIEW_LOADERS = {
  dashboard: () => import('./views/dashboard/dashboard'),
  'data-table': () => import('./views/data-table/data-table'),
  'time-series': () => import('./views/time-series/time-series'),
  'kpi-board': () => import('./views/kpi-board/kpi-board'),
  export: () => import('./views/export/export'),
} as const;

export type ViewKind = keyof typeof VIEW_LOADERS;
```

Unknown `kind` renders a fixed “unsupported view” state. The loader map is never indexed by a string that came from the server until that string has been narrowed to `ViewKind`. Dynamic `import()` receives a literal inside the registry, which is what lets the bundler split chunks.

Folders in the nav tree have no view. Activating a folder expands it. The URL changes only when a leaf is selected.

Guards:

- `sessionGuard` on `/app` and `/admin` — redirects to login when the session probe fails
- `permissionGuard('config.manage')` on `/admin` — UX only
- `ViewHost` treats 403 and 404 from the view API as dedicated states, including when the user typed a `viewId` by hand

Preloading: a custom strategy preloads the data-table chunk after the shell is idle. Chart chunks load when a time-series or dashboard nav item is hovered or focused, and otherwise when that route activates. `PreloadAllModules` is not used.

`@defer` wraps chart panels, admin editors, and the export history table so their components are not created on first paint of the shell.

### 2.4 Backend and API architecture

The API is a resource-oriented HTTP API. Interactive queries are synchronous and bounded. Exports are asynchronous jobs. Configuration reads are cacheable GETs. Configuration writes are audited commands.

| Endpoint | Behavior | Response |
| --- | --- | --- |
| `GET /api/session` | Probe cookie session | user, permission set, config version |
| `GET /api/navigation` | Published tree already filtered to the caller’s permissions | small tree |
| `GET /api/views/{viewId}` | View definition and parameter schema | metadata |
| `GET /api/references/{name}` | Allowlisted dimension list | pages of options |
| `POST /api/reports/{reportId}/query` | One page, allowlisted columns, required filters enforced | page |
| `POST /api/reports/{reportId}/aggregate` | Bucketed metrics, point cap enforced | series or groups |
| `POST /api/exports` | Create job | `202` and job |
| `GET /api/exports/{jobId}` | Status for the owner of the job | job |
| `POST /api/exports/{jobId}/cancel` | Cancel if still running | job |
| `GET /api/exports/{jobId}/download` | Stream or redirect to a short-lived object URL | file |
| `GET /api/admin/...` | Draft and publish configuration | metadata |

`reportId` is resolved inside the application API to a catalog entry (data source, field catalog, required permission, mandatory filter template, max window, max page size). The client cannot supply a source name.

Authorization on every report and export call:

1. Authenticate the session.
2. Confirm the caller has the report’s permission.
3. Reject the call if the view is disabled.
4. Validate the body against the parameter schema and the field catalog.
5. Merge mandatory filters from the caller’s entitlements (region, tenant, customer scope). Client filters cannot widen them.
6. Enforce `limit`, `maxPoints`, required time range, and per-user rate limits.
7. Execute with bound parameters.

Tenant or organization id comes from the session. A matching field in the body is ignored.

### 2.5 Data flow for an interactive view

```text
User edits filter draft (local signals only)
    → Apply
        → facade validates draft against metadata
        → gateway aborts the previous query
        → POST /query or /aggregate
            → API authorizes, validates, runs
            → bounded JSON
        → facade replaces the current page or series
        → OnPush view renders that result
```

A generation counter travels with the request. The facade applies a response only when its generation is still current. Cancellation is the fast path. The generation check covers a response that arrives after a failed abort.

`provideHttpClient(withFetch())` is required so unsubscribing aborts the underlying fetch. `httpResource` already aborts when its reactive params change; use it for session, navigation, view metadata, and reference search.

Text typeahead for reference data waits 250 ms and requires at least 2 characters. The report query itself runs on Apply, not on every control change. Apply stays disabled until required parameters validate, including the maximum date window from metadata.

Identical in-flight reads (same method, URL, and canonical JSON body) share one promise. The key is dropped when the request settles. This deduplicates double-clicks and duplicate metadata loads. It does not deduplicate across users or across tabs via storage.

### 2.6 Authentication and authorization

Target: a backend-for-frontend on the same site.

- The BFF talks to the identity provider with authorization code + PKCE.
- Tokens stay in the BFF session store.
- The browser receives an `HttpOnly`, `Secure`, `SameSite=Lax` session cookie, scoped to the site.
- Mutating requests must send a custom header (`X-CSRF-Token` echoed from a readable cookie, or an equivalent double-submit). A cross-site form post cannot set that header.
- `GET /api/session` is the SPA’s source for display name, permissions, and the published config version.
- 401 triggers one silent session refresh, then navigation to login.
- Logout revokes the server session and clears in-memory stores. It does not need to clear report rows from disk because report rows are not stored there.

A pure SPA holding tokens in `localStorage` is not the design. In-memory PKCE is acceptable only as a temporary development stand-in, and it is removed before production.

Permission model:

- Coarse permissions are string keys owned by the identity/authorization service (`network.read`, `billing.read`, `config.manage`).
- The admin UI selects keys from `GET /api/admin/permissions`. It does not invent new authorization semantics.
- The navigation API omits leaves the caller cannot open, so the sidebar matches the session.
- The report API repeats the check. Direct calls fail closed with 403.
- Field-level and row-level scope is a server-side mandatory filter, not a hidden form control.

Route guards and disabled buttons implement the same rules for usability. They are not the control.

### 2.7 Admin configuration architecture

Configuration is a document with a JSON Schema, stored as draft or published.

```text
Admin edits draft
    → schema validation in the browser (fast feedback)
    → PUT draft (server validates again)
    → Publish
        → server validates references: reportId exists, kind is known,
          permission exists, parameter keys are unique,
          icons are in the icon registry, parent ids form a tree
        → monotonic version increments
        → audit record (actor, before, after, version)
    → clients revalidate when their cached version differs
```

Published documents are immutable versions. Rollback publishes a previous version forward under a new version number. Editing never mutates the live document in place.

What an admin may set on a navigation node:

| Field | Rule |
| --- | --- |
| `id` | Server-generated, stable |
| `parentId` | Existing node or null; no cycles |
| `label` | Plain text, length-capped, rendered as text |
| `icon` | Key in the client icon registry |
| `order` | Integer among siblings |
| `enabled` | Disabled leaves disappear from the published tree |
| `requiredPermission` | Key from the permission catalog |
| `view.kind` | Enum: `dashboard`, `data-table`, `time-series`, `kpi-board`, `export` |
| `view.reportId` | Key in the server report catalog |
| `view.parameterSetId` | Parameter schema id |

What an admin may not set:

- component selectors, module paths, remote module URLs
- arbitrary HTTP URLs or hosts
- raw SQL, query language, or aggregation expressions
- HTML or SVG markup
- a permission expression language

Parameter schema (also versioned):

```json
{
  "id": "network-performance-params",
  "version": 4,
  "maxWindowDays": 31,
  "parameters": [
    {
      "key": "startDate",
      "label": "Start",
      "type": "date",
      "required": true,
      "bindsTo": "timestamp",
      "operator": "gte"
    },
    {
      "key": "endDate",
      "label": "End",
      "type": "date",
      "required": true,
      "bindsTo": "timestamp",
      "operator": "lt"
    },
    {
      "key": "region",
      "label": "Region",
      "type": "multi-select",
      "required": false,
      "bindsTo": "regionCode",
      "operator": "in",
      "source": { "kind": "reference", "name": "regions" }
    },
    {
      "key": "status",
      "label": "Status",
      "type": "select",
      "required": false,
      "bindsTo": "status",
      "operator": "eq",
      "source": {
        "kind": "static",
        "options": [
          { "value": "ACTIVE", "label": "Active" },
          { "value": "INACTIVE", "label": "Inactive" }
        ]
      }
    }
  ]
}
```

`source.kind` is `static` or `reference`. `reference.name` must exist in the server reference catalog. The browser loads options from `GET /api/references/{name}`, never from a URL in the document.

The report catalog itself is delivered by engineering when a new data source is wired (field types, indexes, the query handler). Admins bind views to catalog entries. Adding a report the platform cannot query is a deployment, not a configuration edit. This split is what keeps configuration powerful without making it a programming surface.

### 2.8 Project structure

```text
src/app/
  app.config.ts                 providers: router, http+fetch, error listeners
  app.routes.ts                 closed route table
  core/
    session/                    session store, session guard
    auth/                       permission guard, permission types
    http/                       query gateway, problem parser, dedup, retry
    telemetry/                  sink interface, web-vitals, api timing
    config/                     view-kind registry, icon registry
  layout/
    shell/                      sidenav, header, content router-outlet
  features/
    view-host/                  loads metadata, dispatches kind
    views/
      data-table/
      time-series/
      dashboard/
      kpi-board/
      export/
    admin/
      navigation/
      view-editor/
      access/
  shared/
    ui/                         filter bar, status panel, page toolbar, kpi
    models/                     hand-written contracts until OpenAPI codegen
```

Each feature folder contains the route component, its facade, and its tests. Shared UI has no API knowledge. `core/http` has no UI knowledge.

Path aliases: `@app/*`. Strict TypeScript. `strictTemplates`. Angular budgets enforced in CI (see Phase 2).

### 2.9 Technology decisions

Each decision records why it is needed, the alternatives, and the implications. “When” is the milestone that introduces it.

#### Angular 22

| | |
| --- | --- |
| Why | Current stable line. Zoneless by default, OnPush by default, stable signals, stable `resource` / `httpResource` / `rxResource`, stable signal forms, Vitest as the default test runner. |
| Alternatives | Stay on Angular 20 LTS for a longer patch window. React or Vue would abandon the required stack. |
| Performance | Zoneless avoids zone patches on every async task. OnPush skips unchanged subtrees. Neither helps if a component retains a large array. |
| Scale | Standalone lazy routes and `@defer` match a growing view catalog without a root module. |
| Security | Framework sanitization for interpolation. The team still owns CSP and the view registry. |
| When | M1, pinned patch. |

#### Angular Material and CDK for chrome

| | |
| --- | --- |
| Why | Sidenav, dialogs, menus, form fields, and focus management are maintained with Angular. License is MIT. The CDK scrolling module is available if a view later needs a virtual list. |
| Alternatives | PrimeNG (larger, less aligned with zoneless OnPush), Spartan/shadcn-style ports (more assembly), a fully custom design system (slower to reach accessibility). |
| Performance | Import per component. Do not import a legacy NgModule barrel into the shell. |
| Scale | Chrome stays stable while views are added. Material is not the data grid. |
| Security | No `innerHTML` binding of labels. Icons are local SVG components selected by key. |
| When | M1. |

#### Server-paged table first; AG Grid Enterprise only with a license and a grouping requirement

| | |
| --- | --- |
| Why | At a page size of 100, DOM virtualization is not the constraint. A small table component with server sort, column projection, and track-by is enough and adds no license. AG Grid Community’s client-side row model is the wrong default because it is designed to hold the dataset. Community’s infinite row model can block-load, and it still lacks server-side grouping. Enterprise server-side row model is the product that matches grouping, pivoting, and block cache purge. It is commercial (EULA, per developer). |
| Alternatives | TanStack Table is headless and framework-agnostic; the Angular integration is extra surface. Material table is acceptable for the 100-row page if styling consistency matters more than a custom lightweight table. |
| Performance | Page arrays are short-lived and small. A block cache, if introduced later, keeps a fixed number of blocks and drops the rest. |
| Scale | The API contract (cursor, limit, columns, sort) does not change if the widget changes from a custom table to AG Grid SSRM. |
| Security | Client export buttons in grid libraries export what is loaded. The only full-fidelity export path is the job API. |
| When | Custom or Material paged table at M4. Re-evaluate AG Grid Enterprise before any requirement for server-side group expansion. Do not add the community client-side model as a stepping stone. |

#### Apache ECharts for dashboards, uPlot for dense time series

| | |
| --- | --- |
| Why | Dashboard views need several chart types (line, bar, pie, scatter of already-aggregated points). ECharts is Apache-2.0, canvas-based, and lazy-loadable per chart type. A full ECharts entry is on the order of 150–170 KB gzip, so it must not be in the initial bundle. uPlot is MIT, about 22 KB gzip, and is built for time series (tens or hundreds of thousands of points on canvas). Network traffic views use uPlot. Both sit behind the same `ChartPointCap`. |
| Alternatives | Chart.js is fine for small charts and slower to pan on large series. Highcharts is commercial. Plotly is far too large. D3 as a default encourages SVG node-per-point. AG Charts adds another license if AG Grid is not already chosen. |
| Performance | The server caps points (default max 2,000, hard client refusal at 5,000). ECharts `large` mode is a backstop, not the plan. uPlot is allowed a higher cap (10,000) only for a single time-series view whose API still aggregated first. |
| Scale | New chart types register in the dashboard view and arrive in their own deferred chunk. |
| Security | Chart option objects are built in code from typed series. Category labels are treated as data, not as HTML. |
| When | KPI and a single ECharts line at M5. uPlot when the first high-density time-series view is built. |

#### Signals, facades, `httpResource`, `HttpClient`

| | |
| --- | --- |
| Why | View state is local and small. `httpResource` models read status (`loading`, `resolved`, `error`, `reloading`) and cancels the previous read when params change. `HttpClient` covers POST queries and export commands, with cancellation via unsubscribe on the fetch backend. Signal forms (stable in v22) fit the admin editors, which have stable field shapes. The dynamic report filter uses a metadata-driven `FilterDraft` signal and a pure validator, because the parameter list differs per view and is not a compile-time form model. |
| Alternatives | NgRx Signal Store or ComponentStore if cross-route workflows appear. Hand-rolled RxJS facades for everything, which duplicate what `httpResource` now does for reads. |
| Performance | One current page lives in one signal. Computed values derive columns and chart options. Templates do not map arrays. |
| Scale | New view kinds add a facade. They do not add a global reducer. |
| Security | Session signals are in memory. No persistence of permissions in `localStorage`. |
| When | M1 session and config. M3 filters. M4 queries. |

#### Cookie-session BFF

| | |
| --- | --- |
| Why | Report users work in a browser that also runs third-party extensions. An access token in web storage is stealable from any XSS. The BFF keeps tokens on the server. |
| Alternatives | `angular-oauth2-oidc` with in-memory tokens and silent refresh. It is a reasonable local-dev stand-in and a weaker production posture. Third-party hosted login widgets that drop tokens in `localStorage` are rejected. |
| Performance | One session probe per full load, then memory. Refresh is rare. |
| Scale | The BFF is stateless if the session is server-side storage (Redis or the platform session store), so API instances scale horizontally. |
| Security | HttpOnly cookie, CSRF header, short session idle timeout, rotation on privilege change, logout revocation. CSP without inline scripts. `frame-ancestors 'none'`. |
| When | Fake session fixture at M2 so the UI can be built. Real BFF before any production data. |

#### Caching approach

Detailed in Phase 2. Summary: private HTTP revalidation for navigation and metadata, in-memory TTL for reference data, a tiny LRU of pages inside the active view only, service worker for hashed static assets only, preferences in `localStorage`, no IndexedDB for rows.

#### Export handling

Async job plus browser download manager. Detailed in Phase 2. Libraries that generate Excel files in the browser (SheetJS, exceljs) are out of scope for full extracts. A later “export this page” can build a CSV of the already-loaded page client-side because that page is bounded. It is a separate action from “export all matching rows.”

#### Monitoring

A `TelemetrySink` interface from M1. The default sink is a no-op in production until an endpoint exists, and a console sink in development. Web Vitals and API timings are the first events. OpenTelemetry browser SDK is a later sink implementation, not a dependency of the shell, because of its size.

#### OpenAPI types

The contract in Phase 4 is hand-written at first so the mock and the SPA can move together. From M4, the OpenAPI document becomes the source of truth and generates TypeScript types only. A generated HTTP client is not introduced; the gateway stays hand-written so cancellation, dedup, and generation checks remain visible.

### 2.10 Decision summary

| Topic | Choice | First milestone |
| --- | --- | --- |
| Framework | Angular 22, zoneless, OnPush, standalone | M1 |
| Chrome | Angular Material + CDK | M1 |
| Routes | Closed table, one view host, kind registry | M1 |
| State | View-scoped facades and signals | M1 |
| Reads | `httpResource` | M1 |
| Queries | `HttpClient` POST, abort on apply, generation guard | M4 |
| Table | Server-paged, page size 100, limit 500 | M4 |
| Charts | Lazy ECharts, lazy uPlot, server point cap | M5 |
| Auth | BFF cookie session | M2 fixture, real BFF before production |
| Config | Versioned draft/publish, no URLs, no code | M7 |
| Export | Async job, streamed download | M6 |
| Cache | Metadata only, plus a view-local page LRU | M4–M9 |

---

## 3. Phase 2 — Performance

### 3.1 Large dataset strategy

| View | Server work | Browser receives | Browser retains |
| --- | --- | --- | --- |
| Table | Filter, sort, project columns, cursor page | ≤ 100 rows by default, ≤ 500 if the user raises page size | The current page. Previous page is eligible for GC. Optional LRU of 3 pages for instant back navigation |
| Time series | Filter, date-histogram or equivalent, downsample to the bucket | ≤ 2,000 points typical | The current series only |
| Dashboard | Several aggregates, each capped | A handful of small series and KPI numbers | Same |
| KPI | Scalar or small group-by | Numbers | Numbers |
| Export | Full filtered scan in a worker, file in object storage | Job status JSON, then a streamed file the JS heap does not hold | Job status |

Rules enforced in the API and repeated in the client as a safety net:

- `limit` default 100, maximum 500. Requests above the maximum are `400`, not silently truncated.
- `columns` is required and must be a subset of the report field catalog. No `SELECT *` over the wire.
- A time-bounded report rejects a missing range or a range above `maxWindowDays`.
- `includeTotal` defaults to false. The UI shows “more results” via `hasMore`. An exact count is a separate control, “Count matching rows,” which calls the API with `includeTotal: true` and is allowed to be slow.
- Sort keys are an allowlist. The server appends the primary key as a tie-breaker so cursors are stable.
- Aggregation requests include `maxPoints`. If the bucket size would exceed it, the API returns `422` with a problem type `https://api.example.com/problems/point-cap` and a suggested coarser bucket. The client does not render a series over the hard cap.

Cursor pagination is the default. The cursor is an opaque, HMAC-signed token containing the last sort values and the primary key. The client does not parse it. Offset pagination is not offered on fact-table reports. Admin lists and reference data may use offset because they are small and users expect page numbers there.

Search runs on the server against indexed fields declared in the catalog. The client does not filter the current page as a substitute for search. A highlight of the current page is allowed only as a visual hint and must not hide that other pages exist.

### 3.2 API optimization

- POST query bodies stay compact: filter tree, sort, cursor, limit, columns. No duplicated metadata.
- Responses are arrays of compact row objects. Omit nulls if the contract documents it, and keep types stable.
- Brotli or gzip at the edge for JSON and for static assets.
- `Content-Length` is set so telemetry can record size without reading the body twice.
- HTTP/2 or HTTP/3 so the shell’s small parallel metadata calls multiplex.
- Rate limits per session: interactive queries, aggregate queries, and export creation have separate budgets. The SPA surfaces `429` with `Retry-After` as a distinct state.
- The API rejects unknown JSON fields. This keeps clients from sending a payload the server would ignore while the warehouse still pays for an unbounded query.

Query handlers stream from the database cursor into the page builder and stop after `limit` rows. They do not materialize the full result in application memory either. Export workers are the path that scans a large result, and they write to object storage in chunks.

### 3.3 Rendering strategy

- Server pagination is the primary control. Virtual scrolling is added only for a view that intentionally shows a tall block (for example a 300-row dense log) and then only over that block.
- `@for (row of rows(); track row.id)` with a stable primary key.
- Column definitions and formatted values are `computed` signals, built when the page arrives, not in the template.
- No pipes that allocate per row per change detection unless they are pure and the input identity is stable. Prefer formatting once when the page is stored.
- Charts receive an options object that changes only when the series signal changes.
- Sidebar, header, and filter bar are OnPush and do not read the row signal.
- Route-level providers reset view state on `viewId` change. A parameter map subscription updates a signal; it does not nest subscriptions.
- Destroy path: `takeUntilDestroyed()` for any RxJS subscription, abort of the active query, `chart.dispose()` for ECharts, `plot.destroy()` for uPlot.

Angular’s zoneless scheduler still needs an explicit notification. Signals, `httpResource`, and `HttpClient` provide it. Direct DOM handlers or third-party chart callbacks that mutate component fields must write a signal or call `ChangeDetectorRef.markForCheck()`. Chart libraries are wrapped so that callback is the only bridge.

### 3.4 Memory management

- One page array, replaced rather than pushed. Do not keep `allLoadedRows`.
- Do not `structuredClone` the page. Derive view models with `computed` or a single map at the facade boundary.
- Export download uses navigation to the download URL (`location` assign via an `<a download>` with the cookie session) or a redirect to a presigned URL. The code path `await response.blob()` is disallowed for job downloads. A lint or review rule covers it.
- Object URLs, if ever created for a small page-level CSV, are revoked immediately.
- Subscriptions and chart instances are tied to the component destroy hook.
- The page LRU stores at most 3 page payloads per live facade and is dropped with the facade.
- Long sessions: leaving a view drops its data. A periodic session probe does not retain responses. Telemetry may call `measureUserAgentSpecificMemory` only when the document is cross-origin isolated; otherwise memory is not collected. `performance.memory` is not a portability plan.

### 3.5 Caching

| Data | Where | Freshness | Invalidation |
| --- | --- | --- | --- |
| Hashed JS/CSS | `ngsw` or the CDN | immutable | new deploy hash |
| Navigation, view metadata | Memory, plus `ETag` / `Cache-Control: private, max-age=60, stale-while-revalidate=30` | 60 seconds, then revalidate | Publish bumps `configVersion`. Session probe compares versions and clears `ConfigStore` on mismatch. Logout clears memory |
| Permission set | Memory only | for the session | logout, 401, 403 on a view the user could previously open |
| Reference lists | Memory LRU, 15 minute TTL, max 50 entries | 15 minutes | logout, admin reference publish |
| Query pages | View-local LRU, 3 entries, keyed by canonical body | until the facade is destroyed or the key is evicted | Apply with a new body, logout |
| Aggregates | Same as pages, inside that facade | same | same |
| Export file | Not cached by the SPA | `Cache-Control: no-store` on the download | object retention policy on the server |
| Preferences | `localStorage` | until the user resets | versioned key so a schema change drops old prefs |

Query and aggregate responses use `Cache-Control: no-store`. They are POST, so shared caches should already refuse them. `no-store` covers a misconfigured intermediary.

The service worker configuration allowlists only static asset routes. API paths are denylisted. This is a security control as much as a performance one.

IndexedDB is not used for rows, metadata, or permissions. The quota would hide mistakes until a machine ran out of disk, and the data would outlive the session. If a future offline draft of an admin editor is required, IndexedDB may store that draft document alone, encrypted only if the threat model demands it, and cleared on logout.

Invalidation rule: any 401 clears session, config, references, and view caches. Any publish notification (version mismatch) clears config and view metadata, not the user’s filter draft.

### 3.6 Request behavior

| Mechanism | Policy |
| --- | --- |
| Cancellation | New Apply aborts the previous query. View destroy aborts. `httpResource` aborts stale reads |
| Generation guard | Facade ignores a response whose id is not the latest |
| Debounce | 250 ms on reference typeahead only |
| Apply | Explicit for report query and aggregate |
| Dedup | In-flight map for identical reads and identical queries |
| Retry | Idempotent GETs: up to 2 retries on network error and 503, exponential backoff, honor `Retry-After`. No retry on POST query or POST export (a retry can start a second heavy query or a second job). User-driven retry buttons exist in the error state |
| Timeout | 30 s for interactive query, 60 s for aggregate, 15 s for metadata. Timeout aborts and surfaces the timeout state |
| Compression | Accept gzip and br |
| Concurrency | At most one interactive query and one aggregate per view. Export status polls are separate and low rate |

### 3.7 Export architecture

```text
POST /api/exports
    → 202 { jobId, status: "queued" }
Worker
    → reads with the same authorizer and filter merger as /query
    → writes CSV or Parquet, gzipped, to object storage
    → updates status: queued → running → ready | failed | cancelled
SPA
    → polls GET /api/exports/{jobId} at 1s, 2s, 4s, then every 5s
    → stops on terminal status or view destroy
    → ready: shows Download
Download
    → GET /api/exports/{jobId}/download
    → 200 streamed attachment, or 302 to a presigned URL that expires in minutes
```

The job record stores the user id, report id, canonical filter, column list, format, timestamps, byte size, and error code. Download checks the owner. A presigned URL is single-purpose and short-lived. The SPA does not receive storage credentials.

Formats:

- CSV (gzip) for interoperability
- Parquet (already columnar and compressed) for very large analytical extracts

Row estimates are shown before submit when the API can return a cheap estimate. The user confirms when the estimate exceeds a configured threshold. The server enforces a maximum export size and fails the job with a typed error if the threshold is exceeded, rather than producing a partial file silently.

Polling is the first status channel. Server-Sent Events are a later optimization for the export page and must still fall back to polling. WebSockets are unnecessary for this cadence.

Cancelled and failed jobs delete partial objects. Ready objects expire (for example after 24 hours). The status endpoint then returns `expired`.

### 3.8 Initial load

- Shell route is the initial bundle: session probe, layout, icon registry, telemetry stub.
- Material components used by the shell only.
- View kinds, ECharts, uPlot, and admin are lazy.
- Budget guidance for CI (uncompressed Angular budget figures, tightened after the first production build is measured): initial bundle warning at 350 KB, error at 500 KB; each lazy view warning at 200 KB, error at 350 KB. Chart chunks are excluded from the initial budget by being lazy. If a lazy chart chunk exceeds its budget, import ECharts chart modules individually.
- Tree shaking: `sideEffects` respected, no barrel files that re-export entire features.
- Compression and long-cache headers on hashed assets at the CDN.
- Fonts: a small local subset, no blocking third-party font CSS.

### 3.9 Risks and mitigations

| Risk | Mitigation |
| --- | --- |
| A view is configured without a required time range and scans a fact table | Catalog marks the range required. API rejects. Apply stays disabled |
| Users raise page size to 500 and the table stutters | 500 is the hard max. Track-by and preformatted cells. If a specific report is still heavy, lower that report’s max in the catalog |
| Exact counts are launched casually | Count is a separate action with its own timeout and rate limit |
| Stale response overwrites a newer filter | Abort plus generation counter |
| Admin publishes a broken tree | Schema and reference checks on publish. Rollback to the previous version |
| Chart chunk delays first dashboard paint | `@defer` with a skeleton. Hover preload |
| Metadata cache outlives a permission change | Short TTL, private cache, version check, clear on 403 |
| Export worker and interactive API disagree on filters | One query compiler shared by `/query`, `/aggregate`, and the worker |
| Memory leak from chart instances | Wrapper owns `dispose`/`destroy` in `DestroyRef` |
| Double export jobs | Disable submit while the POST is in flight. No automatic retry. Server idempotency key header `Idempotency-Key` on `POST /api/exports` |
| Cursor tampering | HMAC, reject invalid signature with 400 |
| Large JSON on a slow device | Column projection and page cap. Brotli. Avoid pretty-printed responses |

---

## 4. Phase 3 — UI and UX

### 4.1 Layout

Desktop: persistent left sidenav (272 px), top bar (product name, view title, session menu), content region. The sidenav collapses to icons at widths under 1200 px and becomes a modal drawer under 768 px. Focus moves into the drawer when it opens and returns to the menu button when it closes.

The content region stacks, in order:

1. View title and one-line description from metadata
2. Filter bar
3. Status row (loading, empty, error, partial warning)
4. Result: table, chart, KPI grid, or export panel

Only one primary result is mounted for a view kind. Dashboards mount several cards, each with its own request state, and each card is deferred.

### 4.2 Sidebar

- Built from `GET /api/navigation`, already permission-filtered.
- Nested lists for folders. Expansion state is a UI preference keyed by node id.
- The active leaf is highlighted from the `viewId` route param.
- Disabled and unauthorized nodes are absent, not shown as disabled, except inside the admin editor where editors must see them.
- Keyboard: the tree is navigable with standard disclosure controls (buttons, `aria-expanded`, `aria-current="page"` on the active link).
- Order is the configured `order` field, not alphabetical, so admins control it.

### 4.3 Tabs

Top-level product areas are the roots of the nav tree, not a second hard-coded tab strip. A view may define secondary sections (for example “Chart” and “Table”) as local tabs when both are projections of the same filter. Switching tabs does not refetch if that projection is already the current signal. A dashboard is not a set of hidden live queries for every tab; inactive tabs do not poll.

### 4.4 Dashboard

A dashboard view binds several widgets. Each widget has a `widgetId`, a presentation (`kpi`, `line`, `bar`, `table`), and a query preset (aggregate or page) that still passes through the same APIs. Widget queries share the page-level filter draft. Apply refreshes all widgets; in-flight widget requests are aborted as a group.

A widget error does not blank the whole dashboard. Each card has its own status.

Drill-down sets an additional filter on the draft and navigates to a configured target `viewId`, or stays on the view and re-applies. Drill-down is another bounded query. It is not a client-side slice of a hidden full extract.

### 4.5 Tables

- Header row: column labels from metadata, sort affordance on allowlisted sortable fields, one active sort plus the server-managed tie-break.
- Body: current page only.
- Footer: “Previous” and “Next” using cursors. No “jump to page 4000.” Page size choices: 50, 100, 200. 500 is omitted from the default UI and can be enabled per report if a catalog flag says the row width is small.
- Column picker writes `columns` into the next query. It does not hide columns in a full payload.
- Empty, loading, and error replace the body and leave the filter bar mounted so the user can correct input.
- Row activation opens a detail request `GET /api/reports/{reportId}/records/{id}` that returns one record. The list payload stays narrow.

### 4.6 Filters

The filter bar is generated from the parameter schema.

| Type | Control |
| --- | --- |
| `date`, `date-time` | Date field |
| `select` | Single select |
| `multi-select` | Multi select with typeahead when the reference is large |
| `text` | Text field, used as a server search parameter, not as a local filter |
| `number` | Number field |

Required fields are marked. The window constraint (`maxWindowDays`) is visible next to the date pair (“Maximum range 31 days”). Apply is the primary button. Reset restores the view’s default draft from metadata.

Changing a control never starts a report query. Reference typeahead is the exception, and it only loads options.

Invalid combinations surface inline (end before start, range too wide, missing required). The server repeats those checks and the UI maps `422` field errors onto the same controls.

### 4.7 Charts

- Skeleton while the aggregate request is in flight.
- Title, bucket size, and point count are visible (“Hourly, 720 points”) so the user can see that the series is aggregated.
- If the API returns the point-cap problem, the panel explains that the bucket must be coarser or the range shorter, and offers the suggested bucket when present.
- Legend and series colors come from a fixed palette in code.
- A data table of the aggregated points can sit under the chart. That table is the aggregate, not the raw export.

### 4.8 Export UX

On a view, “Export matching rows” opens a confirm dialog: format, columns (default the current projection), and the active filter summary in plain language. Submit creates the job and routes to the job page or shows a tracker in the header.

Job states the user can see: Queued, Running, Ready, Failed, Cancelled, Expired. Running may show a server-provided percent only when the worker has a real progress figure. A spinner without a fake percent is preferable to an invented one.

Download is enabled only for Ready and before expiry. Failure shows the problem title and a Retry that creates a new job. It does not replay a half-finished local buffer, because there is none.

### 4.9 Admin interface

Sections:

1. Navigation tree — reorder siblings, add folder, add leaf, enable, disable, delete (delete is refused while a published descendant exists; admin must remove or reparent first).
2. View binding — kind, report catalog entry, permission, parameter set.
3. Parameter editor — add parameters from the field catalog of the chosen report. The field dropdown is the allowlist. Operators offered are the operators legal for that field type.
4. Access — read-only display of which permission a view requires, plus a link to the identity system if assignment happens there. This SPA does not become the identity provider.
5. History — published versions and rollback.

The editor works on a draft. A banner states “Draft, not visible to users” until publish. Publish shows a diff of labels, order, permissions, and bindings.

Admin screens use signal forms. Report filters do not.

### 4.10 Status language

Every data region uses the same component and the same vocabulary.

| State | What the user sees |
| --- | --- |
| Loading | Skeleton or inline progress, previous result cleared when the filter changed. Optional “Updating” if a future stale-while-revalidate is ever enabled for a page; default is to clear |
| Success | The result |
| Empty | “No rows match these filters” and the filter summary |
| Error | Problem title, retry when the method allows it |
| Timeout | “The query took too long” and guidance to narrow the range |
| Forbidden | “You do not have access to this view” |
| Not found | “This view is not available” |
| Processing | Export job states |
| Cancelled | “Query cancelled” only if the user hit Cancel; a superseded request is silent |
| Too many requests | “Wait N seconds” from `Retry-After` |
| Point cap | Guidance to coarsen the bucket |

---

## 5. Phase 4 — Data and API contract

Media types: `application/json` for documents, `application/problem+json` for errors (RFC 9457). Dates are ISO-8601 in UTC. Ids are strings. Unknown enum values fail validation.

### 5.1 Session

`GET /api/session`

```json
{
  "user": { "id": "u_123", "displayName": "Amina Shah" },
  "permissions": ["network.read", "billing.read"],
  "configVersion": 18
}
```

### 5.2 Navigation

`GET /api/navigation`

```json
{
  "version": 18,
  "nodes": [
    {
      "id": "nav_dashboard",
      "parentId": null,
      "label": "Dashboard",
      "icon": "dashboard",
      "order": 10,
      "enabled": true,
      "viewId": "view_overview"
    },
    {
      "id": "nav_network",
      "parentId": null,
      "label": "Network",
      "icon": "network",
      "order": 20,
      "enabled": true,
      "viewId": null
    },
    {
      "id": "nav_network_perf",
      "parentId": "nav_network",
      "label": "Performance",
      "icon": "activity",
      "order": 10,
      "enabled": true,
      "viewId": "view_net_perf"
    }
  ]
}
```

`viewId: null` means a folder. The client builds the tree. Orphans and cycles are server bugs; the client drops nodes that participate in a cycle and reports telemetry.

### 5.3 View metadata

`GET /api/views/{viewId}`

```json
{
  "id": "view_net_perf",
  "version": 4,
  "label": "Network performance",
  "description": "Latency and loss for the selected window.",
  "kind": "time-series",
  "reportId": "network_performance",
  "requiredPermission": "network.read",
  "defaults": {
    "startDate": "P7D",
    "endDate": "now",
    "region": []
  },
  "parameters": [
    {
      "key": "startDate",
      "label": "Start",
      "type": "date-time",
      "required": true,
      "bindsTo": "timestamp",
      "operator": "gte"
    },
    {
      "key": "endDate",
      "label": "End",
      "type": "date-time",
      "required": true,
      "bindsTo": "timestamp",
      "operator": "lt"
    },
    {
      "key": "region",
      "label": "Region",
      "type": "multi-select",
      "required": false,
      "bindsTo": "regionCode",
      "operator": "in",
      "source": { "kind": "reference", "name": "regions" }
    }
  ],
  "constraints": { "maxWindowDays": 31 },
  "table": {
    "columns": [
      { "key": "timestamp", "label": "Time", "sortable": true, "type": "date-time" },
      { "key": "regionCode", "label": "Region", "sortable": true, "type": "string" },
      { "key": "latencyMs", "label": "Latency (ms)", "sortable": true, "type": "number" }
    ],
    "defaultColumns": ["timestamp", "regionCode", "latencyMs"],
    "defaultSort": [{ "field": "timestamp", "direction": "desc" }]
  },
  "chart": {
    "timeField": "timestamp",
    "defaultBucket": "hour",
    "buckets": ["hour", "day"],
    "maxPoints": 2000,
    "series": [
      { "field": "latencyMs", "fn": "avg", "label": "Avg latency" }
    ]
  }
}
```

Relative defaults (`P7D`, `now`) are resolved by the client at view open so metadata stays cacheable.

### 5.4 Filter, sort, and page models

Filter node:

```json
{
  "op": "and",
  "conditions": [
    { "field": "timestamp", "op": "gte", "value": "2026-09-01T00:00:00Z" },
    { "field": "timestamp", "op": "lt", "value": "2026-09-08T00:00:00Z" },
    { "field": "regionCode", "op": "in", "value": ["eu-west", "eu-central"] }
  ]
}
```

Operators: `eq`, `in`, `gte`, `lt`, `between`, `contains`. `contains` is allowed only on fields the catalog marks searchable. Nested `and` / `or` is limited to a depth of 3 and a maximum of 50 conditions. The client builder only emits the shape produced by the parameter schema. Power users do not get a free-form tree in v1, which keeps the UI and the validator aligned. The API still accepts the tree so aggregates, exports, and queries share one compiler.

Sort:

```json
[{ "field": "timestamp", "direction": "desc" }]
```

Maximum three user sort fields. The server appends `{ "field": "id", "direction": "desc" }` if `id` is not already present.

Page request:

```json
{ "limit": 100, "cursor": null, "includeTotal": false }
```

### 5.5 Query

`POST /api/reports/network_performance/query`

```json
{
  "filter": {
    "op": "and",
    "conditions": [
      { "field": "timestamp", "op": "gte", "value": "2026-09-01T00:00:00Z" },
      { "field": "timestamp", "op": "lt", "value": "2026-09-08T00:00:00Z" }
    ]
  },
  "sort": [{ "field": "timestamp", "direction": "desc" }],
  "page": { "limit": 100, "cursor": null, "includeTotal": false },
  "columns": ["id", "timestamp", "regionCode", "latencyMs"]
}
```

Response `200`:

```json
{
  "rows": [
    {
      "id": "row_01",
      "timestamp": "2026-09-07T23:00:00Z",
      "regionCode": "eu-west",
      "latencyMs": 18.4
    }
  ],
  "page": {
    "limit": 100,
    "nextCursor": "opaque",
    "prevCursor": null,
    "hasMore": true
  },
  "total": null,
  "meta": { "queryMs": 120, "columns": ["id", "timestamp", "regionCode", "latencyMs"] }
}
```

`id` is always allowed in `columns` because cursors and track-by need it. The table can hide it.

### 5.6 Aggregate

`POST /api/reports/network_performance/aggregate`

```json
{
  "filter": {
    "op": "and",
    "conditions": [
      { "field": "timestamp", "op": "gte", "value": "2026-09-01T00:00:00Z" },
      { "field": "timestamp", "op": "lt", "value": "2026-09-08T00:00:00Z" }
    ]
  },
  "time": { "field": "timestamp", "bucket": "hour" },
  "metrics": [{ "field": "latencyMs", "fn": "avg", "as": "latencyMs" }],
  "maxPoints": 2000
}
```

Response `200`:

```json
{
  "bucket": "hour",
  "series": [
    {
      "name": "latencyMs",
      "points": [
        { "t": "2026-09-01T00:00:00Z", "v": 17.2 }
      ]
    }
  ],
  "meta": { "queryMs": 80, "pointCount": 168, "truncated": false }
}
```

`truncated: true` is not used to sneak extra points. If the cap would be exceeded, the status is `422` and no series is returned.

KPI aggregate omits `time` and returns:

```json
{ "metrics": { "latencyMs": 16.1 }, "meta": { "queryMs": 40 } }
```

### 5.7 References

`GET /api/references/regions?q=eu&limit=50&cursor=`

```json
{
  "items": [{ "value": "eu-west", "label": "EU West" }],
  "page": { "nextCursor": null, "hasMore": false }
}
```

Reference payloads are small. `limit` maximum is 100.

### 5.8 Export job

`POST /api/exports` with header `Idempotency-Key: <uuid>`

```json
{
  "reportId": "network_performance",
  "filter": { "op": "and", "conditions": [] },
  "columns": ["timestamp", "regionCode", "latencyMs"],
  "format": "csv",
  "gzip": true
}
```

Response `202`:

```json
{
  "id": "job_123",
  "status": "queued",
  "reportId": "network_performance",
  "format": "csv",
  "createdAt": "2026-09-23T10:00:00Z",
  "expiresAt": null
}
```

`GET /api/exports/job_123` when ready:

```json
{
  "id": "job_123",
  "status": "ready",
  "reportId": "network_performance",
  "format": "csv",
  "bytes": 104857600,
  "rowCount": 2500000,
  "createdAt": "2026-09-23T10:00:00Z",
  "finishedAt": "2026-09-23T10:04:12Z",
  "expiresAt": "2026-09-24T10:04:12Z"
}
```

Status enum: `queued`, `running`, `ready`, `failed`, `cancelled`, `expired`.

`GET /api/exports/job_123/download` responds `200` with `Content-Disposition: attachment` and `Cache-Control: no-store`, or `302` to a pre-signed URL. The body is not JSON.

### 5.9 Errors

```json
{
  "type": "https://api.example.com/problems/validation",
  "title": "The date range is too wide",
  "status": 422,
  "detail": "network_performance allows at most 31 days.",
  "instance": "/api/reports/network_performance/query",
  "errors": [
    { "field": "endDate", "code": "window_exceeded" }
  ]
}
```

| Status | `type` suffix | When |
| --- | --- | --- |
| 400 | `invalid-body` | Malformed JSON, bad cursor signature, unknown field |
| 401 | `unauthenticated` | No session |
| 403 | `forbidden` | Authenticated, missing permission or not job owner |
| 404 | `not-found` | Unknown view, report, or job |
| 409 | `conflict` | Publish conflict, idempotency key reused with a different body |
| 413 | `payload-too-large` | Body over the small limit (1 MB for query documents) |
| 422 | `validation` or `point-cap` | Schema or cap |
| 429 | `rate-limited` | Budget exceeded, `Retry-After` set |
| 503 | `unavailable` | Dependency down |
| 504 | `timeout` | Server-side query timeout |

The SPA maps these to the status language in Phase 3. A response that is not problem+json becomes a generic unavailable error. The raw body is not shown.

### 5.10 Admin write model

`PUT /api/admin/drafts/navigation` replaces the caller’s draft after schema validation.

`POST /api/admin/publications` publishes the draft. `409` if `baseVersion` is not the current published version.

```json
{ "baseVersion": 18, "draftId": "draft_9" }
```

Response includes the new `version`. Audit entries are append-only and available at `GET /api/admin/audit?limit=50`.

---

## 6. Phase 5 — Implementation milestones

Each milestone is deployable on its own and leaves the previous behavior working. Contract tests against the mock accompany the milestone that introduces the endpoint. Production warehouse adapters are behind the same interface and are not required to demo the SPA.

### M1 — Shell and closed routes

Scaffold Angular 22 with the router, Material sidenav, zoneless default, fetch HTTP client, and budgets. Static navigation fixture feeds the sidebar. `ViewHost` renders a placeholder per kind using the registry. Lazy chunks are visible in the build output.

Done when: a user can move between Overview, a nested Network item, and Billing on desktop and mobile widths, and the initial bundle stays inside budget.

### M2 — Session fixture and guards

`SessionStore` loads `GET /api/session` from a mock. Guards protect `/app` and `/admin`. Logout clears stores. A forbidden placeholder exists.

Done when: an anonymous session cannot open `/app` by URL, and an authenticated session without `config.manage` cannot open `/admin`.

### M3 — Metadata-driven filters

`GET /api/views/{viewId}` drives the filter bar. Validation covers required fields and `maxWindowDays`. Apply emits a `FilterDraft` and does not call the query API yet. Reference typeahead calls the reference endpoint with debounce and cancellation.

Done when: two views render different controls from metadata, and a too-wide range cannot be applied.

### M4 — Paged table

Query gateway, generation guard, dedup, and timeouts. Data-table view posts the contract and renders one page with cursor controls, server sort, and column projection. The mock returns 100 rows and rejects a missing page limit or a limit above 500. View-local LRU of three pages.

Done when: changing Apply aborts the in-flight mock request, a late response cannot overwrite the new page, and the DOM contains only the current page’s rows.

### M5 — Aggregates and charts

Aggregate endpoint and a time-series view using lazy uPlot or lazy ECharts according to the view kind. Point-cap `422` renders the dedicated state. A dashboard view with KPI cards and one chart shares the filter and isolates card errors.

Done when: the chart chunk is absent from the initial bundle, and a response with more than the hard cap is refused in the client even if a faulty mock sends it.

### M6 — Export jobs

Create, poll, cancel, and download against the mock. Download uses an attachment response. The confirm dialog summarizes the filter. Idempotency key is sent. Header tracker shows non-terminal jobs.

Done when: a job can move from queued to ready, failure is distinct from empty results, and the implementation contains no blob accumulation of the file.

### M7 — Admin draft and publish

Admin tree editor, view binding, parameter editor constrained by the field catalog, publish, version check that refreshes a second session’s navigation, rollback.

Done when: an admin can add “Network / Performance”, bind it to `network_performance`, publish, and see it appear in a session that has `network.read`, while a session without that permission does not receive the node.

### M8 — Authorization hardening

Mandatory filter merge demonstrated in the mock (a user scoped to one region cannot remove it). Job download returns 403 for a different user. Direct `POST /query` without the permission returns 403. UI states for 401, 403, and 404 match the contract.

Done when: contract tests cover those three cases and the UI states.

### M9 — Cache, telemetry, and budgets

ETag revalidation for navigation, reference TTL, service worker limited to static files, telemetry sink with route timing, API timing, payload size, and web vitals. No request bodies in events.

Done when: two identical metadata loads in flight share one request, a publish version bump refetches navigation, and a sample telemetry event does not contain filter values.

### M10 — Hardening

Performance pass on the table and chart views, security pass from the test list in Phase 6, accessibility pass on shell, filters, table, and dialogs. Fix issues before adding a new view kind.

The backend warehouse adapter, real identity provider, and object storage can proceed in parallel with M4–M6 once the contract is frozen. They are not SPA milestones.

---

## 7. Phase 6 — Testing

### 7.1 Unit tests

Vitest, the Angular 22 default.

- Filter validator: required fields, window length, operator allowed for type
- Query body builder: parameter draft becomes the canonical filter, columns, and sort
- Generation guard: older response dropped
- Cursor controls: Next disabled when `hasMore` is false
- View registry: unknown kind does not produce an import
- Tree builder: order, nesting, cycle drop
- Problem parser: maps known types and rejects non-problem bodies safely
- Cache key: canonical JSON so key order does not duplicate entries

### 7.2 Component tests

- Filter bar renders controls from a fixture schema and disables Apply when invalid
- Status panel shows each state from the shared vocabulary
- Table renders the fixture page and uses the row id as track key
- Sidebar marks the active `viewId` and nests children
- Export dialog shows the filter summary and disables submit while in flight
- Admin editor refuses a parameter whose field is not in the catalog

### 7.3 API contract tests

Run against the mock and, later, the application API.

- Missing `page.limit` → 400
- `limit` 10_000 → 400
- Unknown column → 400
- Range beyond `maxWindowDays` → 422
- Aggregate over the point cap → 422 and no points
- Missing permission → 403
- Mandatory region appears in the executed filter even when the body omits it
- Invalid cursor signature → 400
- Export idempotency key replay with the same body returns the same job; a different body → 409
- Download by another user → 403

### 7.4 Performance tests

- Production build budget check in CI
- A scripted route load that fails if the initial transfer (brotli) exceeds the agreed budget once the CDN compression settings are known
- Table test with a 100-row fixture asserts the row count in the DOM
- A faulty 5,000-row payload is not a supported mode; the gateway rejects `limit` above 500 before render. A test locks that rejection
- Chart test feeds 2,000 points and asserts one canvas, not thousands of SVG nodes
- Typeahead test asserts a single request after a burst of keystrokes

### 7.5 Large dataset tests

These run against the API or a fixture warehouse, not against a browser holding the data.

- Page query on a multi-million-row table returns within the interactive timeout for a selective indexed filter
- The same query without a time predicate is rejected
- `includeTotal: true` is measured separately and is allowed to be slower
- Export worker completes a large CSV/Parquet, and the API process memory stays flat during an interactive query issued in parallel
- Client test uses a mocked slow response and confirms abort when Apply is clicked again (no second application of rows)

### 7.6 Memory tests

- Open a view, apply, navigate away, and confirm the facade provider is destroyed (test bed) and chart `dispose` was called
- Repeat apply 50 times in a component test and confirm the facade retains one page array
- Download helper test asserts it sets an anchor to the download URL and does not call `blob()`

Manual profiling with Chrome heap snapshots is scheduled in M10 on a long session (open three views, export one job, navigate for several minutes). It is not a substitute for the automated destroy tests.

### 7.7 Security tests

- Nav label fixture containing markup is rendered as text
- Config document with `kind` outside the enum is rejected on publish
- Config document with a URL field is rejected by the schema
- Reference `source.name` outside the catalog is rejected
- CSRF: mutating request without the header is rejected by the BFF
- Session cookie attributes asserted in the BFF test (`HttpOnly`, `Secure`, `SameSite`)
- Job id enumeration returns 404 or 403 without revealing existence to a non-owner (pick one and test it; prefer 404)
- Query body with an extra `tenantId` does not change the tenant used
- Content-Security-Policy present on the document response
- Service worker config test: an API path is not in the asset group

### 7.8 End-to-end tests

A small Playwright suite against the SPA and the mock:

1. Sign in with the fixture session, land on the default view
2. Open a nested nav item, apply a valid filter, see rows
3. Apply an invalid range, see the inline error, see no query
4. Next page requests a cursor and renders the next fixture page
5. Switch to the chart view and see the aggregated series
6. Start an export, see it become ready, see a download link
7. As an admin, add a leaf, publish, see it as the permitted user, and not as the other fixture user
8. Mobile viewport: open the drawer, navigate, close it

E2E does not load a million rows. Large-data behavior is covered by contract tests and API tests.

### 7.9 Accessibility checks

In M10, keyboard-only passes for sidenav, filter apply, table header sort, dialogs, and admin tree. Visible focus, labels on every generated control, status messages in a live region for loading and errors. Color is not the only indicator of job status.

---

## 8. Implementation order and freeze points

1. Freeze the Phase 4 contract before M4 so the mock, SPA, and API do not drift.
2. Build M1–M3 without a warehouse.
3. Build M4–M6 against the mock, and implement the real query compiler in parallel.
4. Bind the first real report (`network_performance` or the customer’s actual first report) only after the compiler enforces limit, window, columns, and permission.
5. Build admin publish (M7) before more than a handful of views exist, so new views arrive as configuration.
6. Complete M8 before any production data.
7. M9 and M10 before encouraging long-running daily use.

The first production view should be one paged table and one aggregated chart on the same report. That pair exercises the principle end to end. Additional nav items after that are configuration, as long as their `reportId` already exists in the catalog.
