# HyperViz

Angular workspace for exploring large operational exports without pulling those exports into the browser.

The architecture plan lives in [docs/architecture.md](docs/architecture.md). This app is the first working slice: a zoneless Angular 22 SPA, a closed view registry, and an in-memory contract API that enforces the same bounds the plan expects from a real backend.

## What you can do

Sign in as a fixture session. Sessions stay in memory and end on refresh.

| Session | Person | Access |
| --- | --- | --- |
| Network analyst | Amina Shah | Network and report views |
| Platform admin | Jordan Lee | Billing views, plus navigation draft and publish |

Then:

- Open nested navigation that comes from `GET /api/navigation`, already filtered by permission.
- Apply filters. Editing a control does not start a query. Apply does, and a newer apply cancels the one still in flight.
- Page a table. The response is at most 500 rows, and the grid renders that page only.
- Open Traffic and switch the bucket to minute over a week. The API refuses the series instead of sending thousands of raw points.
- Export matching rows. The demo worker writes at most 250 CSV rows and says so. Download that file from the job page.
- As Jordan, add or rename a navigation item, publish, and see the sidebar update without a new frontend build.
- Open Rating Validation. Job Admin pages the September runs. Click a run for its accuracy gauges, five aggregate tables (each with its own filters), decoded counts, and a short CSL sample. Job Summary totals those job results for the window.

The Activity panel lists method, path, status, time, and payload size. It does not record filter values.

## Run locally

Node.js 22.22.3 or newer is required.

```bash
npm install
npm start
```

The dev server listens on port **43123**.

```bash
npm test
npm run build
```

## Contract mock

`ContractApi` answers `/api/*` inside the browser so the UI can be exercised without a warehouse. It still refuses missing page limits, limits above 500, windows beyond the report maximum, unknown columns, and chart requests over the point cap. A production deployment replaces this interceptor with the backend-for-frontend described in the architecture plan. Do not point the SPA at arbitrary URLs from navigation config.
