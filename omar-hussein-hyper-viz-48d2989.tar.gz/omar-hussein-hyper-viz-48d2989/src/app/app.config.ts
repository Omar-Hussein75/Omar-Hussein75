import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideRouter, withPreloading } from '@angular/router';
import { routes } from './app.routes';
import { contractMockInterceptor, csrfInterceptor } from './core/http/api.interceptor';
import { SelectivePreload } from './core/config/selective-preload';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes, withPreloading(SelectivePreload)),
    provideHttpClient(withInterceptors([csrfInterceptor, contractMockInterceptor])),
  ],
};
