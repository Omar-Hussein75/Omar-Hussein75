import { Injectable, signal } from '@angular/core';
import type { FilterDraft, FilterTree, Problem, ViewDefinition } from '../../core/models/contracts';
import { buildFilter, defaultsFor } from '../../core/query/query-rules';

@Injectable()
export class FilterState {
  readonly draft = signal<FilterDraft>({});
  readonly error = signal<string | null>(null);
  private viewId = '';

  reset(view: ViewDefinition): boolean {
    if (view.id === this.viewId) return false;
    this.viewId = view.id;
    this.draft.set(defaultsFor(view));
    this.error.set(null);
    return true;
  }

  compile(view: ViewDefinition): { filter: FilterTree } | { problem: Problem } {
    return buildFilter(view.parameters, this.draft(), view.constraints);
  }

  fail(issue: Problem): void {
    this.error.set(issue.detail ? `${issue.title}. ${issue.detail}` : issue.title);
  }
}
