import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import type { ReferenceItem } from '../../core/models/contracts';

@Injectable({ providedIn: 'root' })
export class ReferenceStore {
  private readonly http = inject(HttpClient);
  private readonly cache = new Map<string, { at: number; items: ReferenceItem[] }>();
  private readonly inflight = new Map<string, Promise<ReferenceItem[]>>();

  load(name: string, query = ''): Promise<ReferenceItem[]> {
    const key = `${name}:${query}`;
    const cached = this.cache.get(key);
    if (cached && Date.now() - cached.at < 15 * 60_000) return Promise.resolve(cached.items);
    const pending = this.inflight.get(key);
    if (pending) return pending;
    const request = firstValueFrom(
      this.http.get<{ items: ReferenceItem[] }>(`/api/references/${name}?q=${encodeURIComponent(query)}&limit=50`),
    )
      .then((response) => {
        this.cache.set(key, { at: Date.now(), items: response.items });
        return response.items;
      })
      .finally(() => this.inflight.delete(key));
    this.inflight.set(key, request);
    return request;
  }

  clear(): void {
    this.cache.clear();
    this.inflight.clear();
  }
}
