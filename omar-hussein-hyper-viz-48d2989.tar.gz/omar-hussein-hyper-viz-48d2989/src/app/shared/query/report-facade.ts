import { DestroyRef, Injectable, inject, signal } from '@angular/core';
import { Subscription } from 'rxjs';
import { QueryGateway } from '../../core/http/query-gateway';
import type {
  AggregateRequest,
  AggregateResponse,
  Problem,
  QueryRequest,
  QueryResponse,
  UiKind,
} from '../../core/models/contracts';
import { MAX_PAGE_LIMIT, asProblem, problem, uiKindFor } from '../../core/query/query-rules';

@Injectable()
export class ReportFacade {
  private readonly gateway = inject(QueryGateway);
  private subscription: Subscription | null = null;
  private generation = 0;

  readonly status = signal<'idle' | 'loading' | 'ready' | 'empty' | UiKind>('idle');
  readonly issue = signal<Problem | null>(null);
  readonly response = signal<QueryResponse | null>(null);
  readonly aggregate = signal<AggregateResponse | null>(null);

  constructor() {
    inject(DestroyRef).onDestroy(() => this.subscription?.unsubscribe());
  }

  load(reportId: string, body: QueryRequest): void {
    const generation = this.begin();
    this.subscription = this.gateway.query(reportId, body).subscribe({
      next: (response) => {
        if (generation !== this.generation) return;
        if (response.rows.length > MAX_PAGE_LIMIT) {
          this.response.set(null);
          this.fail(
            problem(422, 'validation', 'Response exceeded the page cap', 'The view refused to render more than 500 rows.'),
          );
          return;
        }
        this.response.set(response);
        this.aggregate.set(null);
        this.issue.set(null);
        this.status.set(response.rows.length === 0 ? 'empty' : 'ready');
      },
      error: (error: unknown) => this.onError(generation, error),
    });
  }

  loadAggregate(reportId: string, body: AggregateRequest): void {
    const generation = this.begin();
    this.subscription = this.gateway.aggregate(reportId, body).subscribe({
      next: (response) => {
        if (generation !== this.generation) return;
        const points = response.series?.points.length ?? 0;
        if (points > 5000) {
          this.aggregate.set(null);
          this.fail(problem(422, 'point-cap', 'This chart would contain too many points'));
          return;
        }
        this.aggregate.set(response);
        this.response.set(null);
        this.issue.set(null);
        this.status.set('ready');
      },
      error: (error: unknown) => this.onError(generation, error),
    });
  }

  private begin(): number {
    this.subscription?.unsubscribe();
    this.generation += 1;
    this.status.set('loading');
    this.issue.set(null);
    return this.generation;
  }

  private onError(generation: number, error: unknown): void {
    if (generation !== this.generation) return;
    const issue = asProblem(error);
    if (issue.status === 0) return;
    this.fail(issue);
  }

  private fail(issue: Problem): void {
    this.issue.set(issue);
    this.status.set(uiKindFor(issue));
    this.response.set(null);
    this.aggregate.set(null);
  }
}
