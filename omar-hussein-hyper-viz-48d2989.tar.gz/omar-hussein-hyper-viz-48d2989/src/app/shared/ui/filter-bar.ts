import { Component, effect, inject, input, model, output, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import type { FilterDraft, ParameterDef, ReferenceItem } from '../../core/models/contracts';
import { toLocalInput } from '../../core/query/query-rules';
import { ReferenceStore } from '../query/reference-store';

@Component({
  selector: 'app-filter-bar',
  imports: [MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule],
  templateUrl: './filter-bar.html',
})
export class FilterBar {
  private readonly references = inject(ReferenceStore);
  private searchTimer: ReturnType<typeof setTimeout> | null = null;

  readonly parameters = input.required<ParameterDef[]>();
  readonly maxWindowDays = input<number | null>(null);
  readonly draft = model.required<FilterDraft>();
  readonly message = input<string | null>(null);
  readonly busy = input(false);
  readonly applied = output<void>();

  readonly options = signal<Record<string, ReferenceItem[]>>({});

  constructor() {
    effect(() => {
      for (const parameter of this.parameters()) {
        if (parameter.source?.kind === 'static') {
          this.options.update((current) => ({ ...current, [parameter.key]: parameter.source?.kind === 'static' ? parameter.source.options : [] }));
        }
        if (parameter.source?.kind === 'reference') {
          const name = parameter.source.name;
          void this.references.load(name).then((items) => {
            this.options.update((current) => ({ ...current, [name]: items }));
          });
        }
      }
    });
  }

  optionsFor(parameter: ParameterDef): ReferenceItem[] {
    if (parameter.source?.kind === 'reference') return this.options()[parameter.source.name] ?? [];
    if (parameter.source?.kind === 'static') return this.options()[parameter.key] ?? parameter.source.options;
    return [];
  }

  textValue(key: string): string {
    const value = this.draft()[key];
    return typeof value === 'string' ? value : '';
  }

  localDate(key: string): string {
    return toLocalInput(this.textValue(key));
  }

  listValue(key: string): string[] {
    const value = this.draft()[key];
    return Array.isArray(value) ? value : [];
  }

  setValue(key: string, value: string | string[]): void {
    this.draft.update((draft) => ({ ...draft, [key]: value }));
  }

  onDate(key: string, event: Event): void {
    const target = event.target;
    if (target instanceof HTMLInputElement) this.setValue(key, target.value);
  }

  onText(key: string, event: Event): void {
    const target = event.target;
    if (target instanceof HTMLInputElement) this.setValue(key, target.value);
  }

  searchReference(parameter: ParameterDef, event: Event): void {
    const target = event.target;
    if (!(target instanceof HTMLInputElement) || parameter.source?.kind !== 'reference') return;
    const name = parameter.source.name;
    const query = target.value;
    if (this.searchTimer) clearTimeout(this.searchTimer);
    this.searchTimer = setTimeout(() => {
      void this.references.load(name, query).then((items) => {
        this.options.update((current) => ({ ...current, [name]: items }));
      });
    }, 250);
  }

  apply(): void {
    this.applied.emit();
  }
}
