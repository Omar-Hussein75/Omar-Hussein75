import { Component, input } from '@angular/core';
import type { UiKind } from '../../core/models/contracts';

@Component({
  selector: 'app-status',
  template: `
    <div class="hv-status" [attr.data-kind]="kind()" role="status">
      <p class="hv-status-title">{{ title() }}</p>
      @if (detail()) {
        <p class="hv-status-detail">{{ detail() }}</p>
      }
    </div>
  `,
})
export class StatusPanel {
  readonly kind = input.required<UiKind>();
  readonly title = input.required<string>();
  readonly detail = input<string | null>(null);
}
