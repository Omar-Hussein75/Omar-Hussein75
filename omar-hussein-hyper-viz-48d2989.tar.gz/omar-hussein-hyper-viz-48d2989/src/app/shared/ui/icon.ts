import { Component, computed, input } from '@angular/core';

const PATHS: Record<string, string> = {
  dashboard: 'M3 3h8v8H3V3zm10 0h8v5h-8V3zM3 13h8v8H3v-8zm10 3h8v5h-8v-5z',
  users:
    'M8 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm8 0a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM2 19v-1.5C2 15.5 5.1 14 8 14s6 1.5 6 3.5V19H2zm12 .1c.3-.8 1.2-1.6 2.5-2.1 1.6-.6 3.5-.1 3.5 1.5V19h-6v.1z',
  network: 'M12 3 4 7.5v9L12 21l8-4.5v-9L12 3zm0 2.2 5.5 3.1v6.4L12 17.8 6.5 14.7V8.3L12 5.2z',
  activity: 'M2 13h4l2.2-6.2L12 18l2.4-7H22v-2h-6.2l-1.6 4.6L10 4 7.2 13H2v0z',
  pulse: 'M2 12h4l2-5 3 10 2-5h9v-2H12.2L11 14 8.5 6 6.8 12H2z',
  traffic: 'M5 19V5h2v14H5zm6 0V9h2v10h-2zm6 0v-7h2v7h-2z',
  billing: 'M3 6h18v12H3V6zm2 4h14V8H5v2zm0 2v4h7v-4H5z',
  reconcile: 'M4 6h16v2H4V6zm0 5h10v2H4v-2zm0 5h16v2H4v-2z',
  reports: 'M6 3h8l5 5v13H6V3zm7 1.5V9h4.5L13 4.5zM8 12h8v1.8H8V12zm0 4h8v1.8H8V16z',
  rating: 'M7 3h10v2h3v16H4V5h3V3zm2 2v2h6V5H9zm1 6h8v2h-8v-2zm0 4h5v2h-5v-2z',
  folder: 'M3 6h6l2 2h10v10H3V6z',
};

@Component({
  selector: 'app-icon',
  template: `
    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <path [attr.d]="path()" />
    </svg>
  `,
})
export class Icon {
  readonly name = input('folder');
  readonly path = computed(() => PATHS[this.name()] ?? PATHS['folder']);
}
