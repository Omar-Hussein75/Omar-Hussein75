export function formatCell(value: string | number | undefined, type: string): string {
  if (value === undefined) return '';
  if (type === 'date-time' && typeof value === 'string') {
    const parsed = Date.parse(value);
    if (Number.isNaN(parsed)) return value;
    return new Date(parsed).toISOString().replace('T', ' ').slice(0, 16);
  }
  if (type === 'number' && typeof value === 'number') {
    return new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 }).format(value);
  }
  return String(value);
}

export function formatMetric(value: number | undefined, unit?: string): string {
  if (value === undefined || Number.isNaN(value)) return '—';
  const formatted = new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 }).format(value);
  if (!unit) return formatted;
  if (unit === 'bytes') return formatBytes(value);
  return `${formatted} ${unit}`;
}

export function formatBytes(value: number): string {
  if (value < 1024) return `${value} B`;
  const units = ['KB', 'MB', 'GB', 'TB'];
  let current = value;
  let unit = 'B';
  for (const next of units) {
    if (current < 1024) break;
    current /= 1024;
    unit = next;
  }
  return `${current.toFixed(current >= 100 || unit === 'B' ? 0 : 1)} ${unit}`;
}
