import { httpResource } from '@angular/common/http';
import { Component, DestroyRef, computed, inject, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import type { NavPayload } from '../../core/models/contracts';
import { SessionStore } from '../../core/session/session-store';
import { Telemetry } from '../../core/telemetry/telemetry';
import { Icon } from '../../shared/ui/icon';
import { buildTree } from '../nav-tree';

@Component({
  selector: 'app-shell',
  imports: [RouterOutlet, RouterLink, RouterLinkActive, MatSidenavModule, MatButtonModule, Icon],
  templateUrl: './shell.html',
})
export class Shell {
  private readonly router = inject(Router);
  readonly sessionStore = inject(SessionStore);
  readonly telemetry = inject(Telemetry);
  readonly compact = signal(false);
  readonly opened = signal(true);
  readonly activityOpen = signal(false);
  readonly expanded = signal<Record<string, boolean>>({});

  readonly navigation = httpResource<NavPayload>(() => {
    const session = this.sessionStore.session();
    if (!session) return undefined;
    return `/api/navigation?v=${session.configVersion}`;
  });

  readonly tree = computed(() => (this.navigation.hasValue() ? buildTree(this.navigation.value().nodes) : []));
  readonly version = computed(() => (this.navigation.hasValue() ? this.navigation.value().version : null));

  constructor() {
    const query = window.matchMedia('(max-width: 860px)');
    const apply = () => {
      this.compact.set(query.matches);
      if (query.matches) this.opened.set(false);
    };
    apply();
    query.addEventListener('change', apply);
    inject(DestroyRef).onDestroy(() => query.removeEventListener('change', apply));
  }

  isOpen(id: string): boolean {
    return this.expanded()[id] ?? true;
  }

  toggleFolder(id: string): void {
    this.expanded.update((state) => ({ ...state, [id]: !(state[id] ?? true) }));
  }

  toggleActivity(): void {
    this.activityOpen.update((open) => !open);
  }

  logout(): void {
    this.sessionStore.logout().subscribe(() => {
      void this.router.navigateByUrl('/login');
    });
  }
}
