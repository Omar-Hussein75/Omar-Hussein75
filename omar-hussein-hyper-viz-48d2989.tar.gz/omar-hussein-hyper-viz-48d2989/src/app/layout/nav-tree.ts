import type { NavNode } from '../core/models/contracts';

export interface TreeNode extends NavNode {
  children: TreeNode[];
}

export function buildTree(nodes: NavNode[]): TreeNode[] {
  const mapped = new Map<string, TreeNode>();
  for (const node of nodes) mapped.set(node.id, { ...node, children: [] });
  const roots: TreeNode[] = [];
  for (const node of mapped.values()) {
    const parent = node.parentId ? mapped.get(node.parentId) : undefined;
    if (parent) parent.children.push(node);
    else roots.push(node);
  }
  const sortNodes = (items: TreeNode[]): void => {
    items.sort((left, right) => left.order - right.order);
    for (const item of items) sortNodes(item.children);
  };
  sortNodes(roots);
  return roots;
}
