import { Component, DestroyRef, ElementRef, effect, inject, input, signal, viewChild } from '@angular/core';
import { Subscription } from 'rxjs';
import { QueryGateway } from '../../../core/http/query-gateway';
import type { FilterDraft, Problem, ViewDefinition, WidgetDef } from '../../../core/models/contracts';
import { asProblem } from '../../../core/query/query-rules';
import { SessionStore } from '../../../core/session/session-store';
import { formatMetric } from '../../../shared/format';
import { FilterState } from '../../../shared/query/filter-state';
import { FilterBar } from '../../../shared/ui/filter-bar';
import { StatusPanel } from '../../../shared/ui/status-panel';

interface CardState {
  title: string;
  mode: 'loading' | 'ready' | 'error' | 'skipped';
  value: string;
  detail: string;
}

@Component({
  selector: 'app-dashboard',
  imports: [FilterBar, StatusPanel],
  providers: [FilterState],
  templateUrl: './dashboard.html',
})
export class Dashboard {
  private readonly gateway = inject(QueryGateway);
  private readonly session = inject(SessionStore);
  readonly filters = inject(FilterState);
  readonly view = input.required<ViewDefinition>();
  readonly cards = signal<CardState[]>([]);
  readonly banner = signal<string | null>(null);
  private subscription = new Subscription();
  private chart: { dispose: () => void; resize: () => void } | null = null;
  private readonly trend = viewChild<ElementRef<HTMLElement>>('trend');
  private readonly trendPoints = signal<{ t: string; v: number }[] | null>(null);

  constructor() {
    inject(DestroyRef).onDestroy(() => {
      this.subscription.unsubscribe();
      this.chart?.dispose();
    });
    effect(() => {
      if (this.filters.reset(this.view())) this.apply();
    });
    effect(() => {
      const points = this.trendPoints();
      const host = this.trend();
      if (!points || !host || points.length > 5000) return;
      void this.draw(host.nativeElement, points);
    });
  }

  apply(): void {
    const view = this.view();
    const compiled = this.filters.compile(view);
    if ('problem' in compiled) {
      this.filters.fail(compiled.problem);
      return;
    }
    this.filters.error.set(null);
    this.banner.set(null);
    this.subscription.unsubscribe();
    this.subscription = new Subscription();
    const permissions = this.session.session()?.permissions ?? [];
    const widgets = view.widgets ?? [];
    this.cards.set(
      widgets
        .filter((widget) => widget.presentation === 'kpi')
        .map((widget) => ({
          title: widget.title,
          mode: permissions.includes(widget.permission) ? 'loading' : 'skipped',
          value: '—',
          detail: permissions.includes(widget.permission) ? 'Querying the aggregate' : 'Not included for this session',
        })),
    );
    this.trendPoints.set(null);
    widgets.forEach((widget, index) => {
      if (!permissions.includes(widget.permission)) return;
      const request =
        widget.presentation === 'line'
          ? this.gateway.aggregate(widget.reportId, {
              filter: compiled.filter,
              time: { field: 'timestamp', bucket: 'hour' },
              metric: widget.metric,
              maxPoints: 2000,
            })
          : this.gateway.aggregate(widget.reportId, {
              filter: compiled.filter,
              kpis: [widget.metric],
              maxPoints: 2000,
            });
      this.subscription.add(
        request.subscribe({
          next: (response) => this.accept(widget, response.metrics?.[widget.metric], response.series?.points ?? null, response.meta.pointCount),
          error: (error: unknown) => this.reject(widget, index, asProblem(error)),
        }),
      );
    });
  }

  updateDraft(draft: FilterDraft): void {
    this.filters.draft.set(draft);
  }

  private accept(widget: WidgetDef, metric: number | undefined, points: { t: string; v: number }[] | null, pointCount: number): void {
    if (widget.presentation === 'line') {
      if (pointCount > 5000) {
        this.banner.set('The trend was refused because it exceeded the point cap.');
        return;
      }
      this.trendPoints.set(points);
      this.banner.set(`${pointCount} hourly points, aggregated before the chart.`);
      return;
    }
    this.cards.update((cards) =>
      cards.map((card) =>
        card.title === widget.title
          ? { ...card, mode: 'ready', value: formatMetric(metric, widget.unit), detail: 'Server aggregate' }
          : card,
      ),
    );
  }

  private reject(widget: WidgetDef, _index: number, issue: Problem): void {
    if (widget.presentation === 'line') {
      this.banner.set(issue.title);
      return;
    }
    this.cards.update((cards) =>
      cards.map((card) =>
        card.title === widget.title ? { ...card, mode: 'error', value: '—', detail: issue.title } : card,
      ),
    );
  }

  private async draw(host: HTMLElement, points: { t: string; v: number }[]): Promise<void> {
    const echarts = await import('echarts/core');
    const { LineChart } = await import('echarts/charts');
    const { GridComponent, TooltipComponent } = await import('echarts/components');
    const { CanvasRenderer } = await import('echarts/renderers');
    echarts.use([LineChart, GridComponent, TooltipComponent, CanvasRenderer]);
    this.chart?.dispose();
    const chart = echarts.init(host);
    chart.setOption({
      animation: false,
      grid: { left: 56, right: 16, top: 24, bottom: 32 },
      tooltip: { trigger: 'axis' },
      xAxis: { type: 'time' },
      yAxis: { type: 'value' },
      series: [
        {
          type: 'line',
          showSymbol: false,
          color: '#0f766e',
          data: points.map((point) => [point.t, point.v]),
        },
      ],
    });
    this.chart = chart;
  }
}
