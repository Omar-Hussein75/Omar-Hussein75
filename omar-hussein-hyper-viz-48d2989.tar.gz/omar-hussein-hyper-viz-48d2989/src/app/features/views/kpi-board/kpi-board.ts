import { Component, effect, inject, input } from '@angular/core';
import type { FilterDraft, ViewDefinition } from '../../../core/models/contracts';
import { formatMetric } from '../../../shared/format';
import { FilterState } from '../../../shared/query/filter-state';
import { ReportFacade } from '../../../shared/query/report-facade';
import { FilterBar } from '../../../shared/ui/filter-bar';
import { StatusPanel } from '../../../shared/ui/status-panel';
import type { UiKind } from '../../../core/models/contracts';

@Component({
  selector: 'app-kpi-board',
  imports: [FilterBar, StatusPanel],
  providers: [ReportFacade, FilterState],
  templateUrl: './kpi-board.html',
})
export class KpiBoard {
  readonly facade = inject(ReportFacade);
  readonly filters = inject(FilterState);
  readonly view = input.required<ViewDefinition>();

  constructor() {
    effect(() => {
      if (this.filters.reset(this.view())) this.apply();
    });
  }

  apply(): void {
    const view = this.view();
    const compiled = this.filters.compile(view);
    if ('problem' in compiled) {
      this.filters.fail(compiled.problem);
      return;
    }
    this.filters.error.set(null);
    this.facade.loadAggregate(view.reportId, {
      filter: compiled.filter,
      kpis: (view.kpis ?? []).map((kpi) => kpi.key),
      maxPoints: 1,
    });
  }

  updateDraft(draft: FilterDraft): void {
    this.filters.draft.set(draft);
  }

  value(key: string, unit?: string): string {
    return formatMetric(this.facade.aggregate()?.metrics?.[key], unit);
  }

  statusKind(): UiKind {
    const status = this.facade.status();
    if (status === 'idle' || status === 'ready' || status === 'loading' || status === 'empty') return 'error';
    return status;
  }
}
