import { Component, DestroyRef, ElementRef, effect, inject, input, signal, viewChild } from '@angular/core';
import type { Bucket, FilterDraft, ViewDefinition } from '../../../core/models/contracts';
import { FilterState } from '../../../shared/query/filter-state';
import { ReportFacade } from '../../../shared/query/report-facade';
import { FilterBar } from '../../../shared/ui/filter-bar';
import { StatusPanel } from '../../../shared/ui/status-panel';
import type { UiKind } from '../../../core/models/contracts';

@Component({
  selector: 'app-time-series',
  imports: [FilterBar, StatusPanel],
  providers: [ReportFacade, FilterState],
  templateUrl: './time-series.html',
})
export class TimeSeries {
  readonly facade = inject(ReportFacade);
  readonly filters = inject(FilterState);
  readonly view = input.required<ViewDefinition>();
  readonly bucket = signal<Bucket>('hour');
  private readonly chartHost = viewChild<ElementRef<HTMLElement>>('chart');
  private plot: { destroy: () => void } | null = null;

  constructor() {
    inject(DestroyRef).onDestroy(() => this.plot?.destroy());
    effect(() => {
      const view = this.view();
      if (this.filters.reset(view)) {
        this.bucket.set(view.chart?.defaultBucket ?? 'hour');
        this.apply();
      }
    });
    effect(() => {
      const series = this.facade.aggregate()?.series;
      const host = this.chartHost();
      if (!series || !host || (series.points.length ?? 0) > 5000) return;
      void this.draw(host.nativeElement, series.points, this.view().chart?.metricLabel ?? series.name);
    });
  }

  apply(): void {
    const view = this.view();
    const chart = view.chart;
    if (!chart) return;
    const compiled = this.filters.compile(view);
    if ('problem' in compiled) {
      this.filters.fail(compiled.problem);
      return;
    }
    this.filters.error.set(null);
    this.facade.loadAggregate(view.reportId, {
      filter: compiled.filter,
      time: { field: chart.timeField, bucket: this.bucket() },
      metric: chart.metric,
      maxPoints: chart.maxPoints,
    });
  }

  updateDraft(draft: FilterDraft): void {
    this.filters.draft.set(draft);
  }

  setBucket(event: Event): void {
    const target = event.target;
    if (!(target instanceof HTMLSelectElement)) return;
    if (target.value === 'minute' || target.value === 'hour' || target.value === 'day') {
      this.bucket.set(target.value);
      this.apply();
    }
  }

  statusKind(): UiKind {
    const status = this.facade.status();
    if (status === 'idle' || status === 'ready' || status === 'loading' || status === 'empty') return 'error';
    return status;
  }

  suggestion(): string | null {
    return this.facade.issue()?.errors?.find((error) => error.suggestion)?.suggestion ?? null;
  }

  private async draw(host: HTMLElement, points: { t: string; v: number }[], label: string): Promise<void> {
    const uPlot = (await import('uplot')).default;
    this.plot?.destroy();
    host.replaceChildren();
    this.plot = new uPlot(
      {
        width: Math.max(320, host.clientWidth),
        height: 340,
        series: [{}, { label, stroke: '#0f766e', width: 2, fill: 'rgba(15, 118, 110, 0.12)' }],
        axes: [{ stroke: '#5c6b67' }, { stroke: '#5c6b67' }],
        scales: { x: { time: true } },
      },
      [points.map((point) => Date.parse(point.t) / 1000), points.map((point) => point.v)],
      host,
    );
  }
}
