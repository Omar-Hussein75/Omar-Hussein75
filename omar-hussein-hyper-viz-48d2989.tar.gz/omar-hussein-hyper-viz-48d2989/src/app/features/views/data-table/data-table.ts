import { Component, computed, effect, inject, input, signal, viewChild } from '@angular/core';
import { ElementRef } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { RouterLink } from '@angular/router';
import type { FilterDraft, SortSpec, UiKind, ViewDefinition } from '../../../core/models/contracts';
import { formatCell } from '../../../shared/format';
import { FilterState } from '../../../shared/query/filter-state';
import { ReportFacade } from '../../../shared/query/report-facade';
import { FilterBar } from '../../../shared/ui/filter-bar';
import { StatusPanel } from '../../../shared/ui/status-panel';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-data-table',
  imports: [FilterBar, StatusPanel, MatButtonModule, RouterLink],
  providers: [ReportFacade, FilterState],
  templateUrl: './data-table.html',
})
export class DataTable {
  private readonly http = inject(HttpClient);
  readonly facade = inject(ReportFacade);
  readonly filters = inject(FilterState);
  readonly view = input.required<ViewDefinition>();

  readonly pageSize = signal(100);
  readonly sort = signal<SortSpec[] | null>(null);
  readonly cursor = signal<string | null>(null);
  readonly exportMessage = signal<string | null>(null);
  readonly exportBusy = signal(false);
  private readonly dialog = viewChild<ElementRef<HTMLDialogElement>>('exportDialog');

  readonly columns = computed(() => this.view().table?.columns ?? []);
  readonly rows = computed(() => {
    const response = this.facade.response();
    const columns = this.columns();
    if (!response) return [];
    return response.rows.map((row) => ({
      id: String(row['id']),
      cells: columns.map((column) => formatCell(row[column.key], column.type)),
    }));
  });

  constructor() {
    effect(() => {
      const view = this.view();
      if (this.filters.reset(view)) {
        this.sort.set(view.table?.defaultSort ?? []);
        this.cursor.set(null);
        this.apply(null);
      }
    });
  }

  apply(cursor: string | null): void {
    const view = this.view();
    const table = view.table;
    if (!table) return;
    const compiled = this.filters.compile(view);
    if ('problem' in compiled) {
      this.filters.fail(compiled.problem);
      return;
    }
    this.filters.error.set(null);
    this.cursor.set(cursor);
    this.facade.load(view.reportId, {
      filter: compiled.filter,
      sort: this.sort() ?? table.defaultSort,
      page: { limit: this.pageSize(), cursor, includeTotal: false },
      columns: table.defaultColumns,
    });
  }

  count(): void {
    const view = this.view();
    const table = view.table;
    if (!table) return;
    const compiled = this.filters.compile(view);
    if ('problem' in compiled) {
      this.filters.fail(compiled.problem);
      return;
    }
    this.facade.load(view.reportId, {
      filter: compiled.filter,
      sort: this.sort() ?? table.defaultSort,
      page: { limit: this.pageSize(), cursor: this.cursor(), includeTotal: true },
      columns: table.defaultColumns,
    });
  }

  toggleSort(field: string): void {
    const column = this.columns().find((item) => item.key === field);
    if (!column?.sortable) return;
    const current = this.sort()?.[0];
    const direction = current?.field === field && current.direction === 'asc' ? 'desc' : 'asc';
    this.sort.set([{ field, direction }]);
    this.apply(null);
  }

  sortMark(field: string): string {
    const current = this.sort()?.[0];
    if (current?.field !== field) return '';
    return current.direction === 'asc' ? '↑' : '↓';
  }

  updateDraft(draft: FilterDraft): void {
    this.filters.draft.set(draft);
  }

  statusKind(): UiKind {
    const status = this.facade.status();
    if (status === 'idle' || status === 'ready' || status === 'loading' || status === 'empty') return 'error';
    return status;
  }

  changePageSize(event: Event): void {
    const target = event.target;
    if (!(target instanceof HTMLSelectElement)) return;
    this.pageSize.set(Number(target.value));
    this.apply(null);
  }

  openExport(): void {
    this.exportMessage.set(null);
    this.dialog()?.nativeElement.showModal();
  }

  closeExport(): void {
    this.dialog()?.nativeElement.close();
  }

  requestExport(): void {
    const view = this.view();
    const table = view.table;
    if (!table) return;
    const compiled = this.filters.compile(view);
    if ('problem' in compiled) {
      this.filters.fail(compiled.problem);
      this.closeExport();
      return;
    }
    this.exportBusy.set(true);
    this.http
      .post<{ id: string }>(
        '/api/exports',
        {
          reportId: view.reportId,
          filter: compiled.filter,
          columns: table.defaultColumns,
          format: 'csv',
        },
        { headers: { 'Idempotency-Key': crypto.randomUUID() } },
      )
      .subscribe({
        next: (job) => {
          this.exportBusy.set(false);
          this.exportMessage.set(job.id);
          this.closeExport();
        },
        error: () => {
          this.exportBusy.set(false);
          this.exportMessage.set('failed');
        },
      });
  }
}
