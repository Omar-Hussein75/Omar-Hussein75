import { Component, DestroyRef, computed, effect, inject, input, signal } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { Subscription } from 'rxjs';
import { RatingApi } from '../../../core/http/rating-api';
import type { ViewDefinition } from '../../../core/models/contracts';
import {
  AGG_TABLES,
  type AggPage,
  type AggTableId,
  type DifferenceRow,
  type RatingJob,
  type RatingJobDetail,
  type RatingPage,
  type RatingSummary,
} from '../../../core/mock/rating-jobs';
import { asProblem } from '../../../core/query/query-rules';
import { StatusPanel } from '../../../shared/ui/status-panel';

interface Draft {
  start: string;
  end: string;
  stream: '' | 'IN' | 'BSCS';
  jobStatus: string;
  statusDescr: string;
}

const EMPTY_DRAFT: Draft = {
  start: '2026-09-01',
  end: '2026-09-30',
  stream: '',
  jobStatus: '',
  statusDescr: '',
};

interface AggView {
  text: string;
  minDifference: string;
  appliedText: string;
  appliedMin: string;
  page: AggPage | null;
  status: 'idle' | 'loading' | 'ready' | 'empty' | 'error';
  message: string | null;
}

function blankAggregates(): Record<AggTableId, AggView> {
  const blank = {} as Record<AggTableId, AggView>;
  for (const table of AGG_TABLES) {
    blank[table.id] = {
      text: '',
      minDifference: '',
      appliedText: '',
      appliedMin: '',
      page: null,
      status: 'idle',
      message: null,
    };
  }
  return blank;
}

@Component({
  selector: 'app-rating-jobs',
  imports: [RouterLink, RouterLinkActive, StatusPanel],
  templateUrl: './rating-jobs.html',
})
export class RatingJobs {
  private readonly api = inject(RatingApi);
  private listSub: Subscription | null = null;
  private detailSub: Subscription | null = null;
  private differenceSub: Subscription | null = null;
  private readonly aggSubs = new Map<AggTableId, Subscription>();
  private readonly aggGen: Record<AggTableId, number> = { job: 0, 'rate-plan': 0, 'sub-plan': 0, 'call-type': 0, subscriber: 0 };
  private lastViewId = '';

  readonly view = input.required<ViewDefinition>();
  readonly draft = signal<Draft>({ ...EMPTY_DRAFT });
  readonly page = signal<RatingPage | null>(null);
  readonly summary = signal<RatingSummary | null>(null);
  readonly detail = signal<(RatingJobDetail & { uploads: { name: string; bytes: number; at: string }[] }) | null>(null);
  readonly selectedId = signal<number | null>(null);
  readonly status = signal<'idle' | 'loading' | 'ready' | 'empty' | 'error'>('idle');
  readonly message = signal<string | null>(null);
  readonly runStream = signal<'IN' | 'BSCS'>('IN');
  readonly runBusy = signal(false);
  readonly uploadNote = signal<string | null>(null);
  readonly aggregates = signal<Record<AggTableId, AggView>>(blankAggregates());
  readonly differences = signal<DifferenceRow[] | null>(null);
  readonly showDifferences = signal(false);
  readonly tables = AGG_TABLES;

  readonly rows = computed(() => (this.page()?.rows ?? []).map((job) => decorate(job)));
  readonly summaryCards = computed(() => {
    const summary = this.summary();
    if (!summary) return [];
    return [
      { label: 'Jobs', value: formatNumber(summary.jobs) },
      { label: 'Decoded', value: formatNumber(summary.decoded) },
      { label: 'Filtered', value: formatNumber(summary.filtered) },
      { label: 'Rated', value: formatNumber(summary.rated) },
      { label: 'Errored', value: formatNumber(summary.errored) },
    ];
  });

  constructor() {
    inject(DestroyRef).onDestroy(() => {
      this.listSub?.unsubscribe();
      this.detailSub?.unsubscribe();
      this.differenceSub?.unsubscribe();
      this.cancelAggregates();
    });
    effect(() => {
      const view = this.view();
      if (view.id === this.lastViewId) return;
      this.lastViewId = view.id;
      this.detail.set(null);
      this.selectedId.set(null);
      this.draft.set({ ...EMPTY_DRAFT });
      this.load(null);
    });
  }

  get summaryMode(): boolean {
    return this.view().id === 'view_rating_summary';
  }

  apply(): void {
    this.load(null);
  }

  clear(): void {
    this.draft.set({ ...EMPTY_DRAFT });
    this.message.set(null);
  }

  load(cursor: string | null): void {
    const draft = this.draft();
    this.listSub?.unsubscribe();
    this.status.set('loading');
    this.message.set(null);
    const filters = {
      start: draft.start,
      end: draft.end,
      stream: draft.stream,
      jobStatus: draft.jobStatus,
      statusDescr: draft.statusDescr,
    };
    if (this.summaryMode) {
      this.listSub = this.api.summary(filters).subscribe({
        next: (summary) => {
          this.summary.set(summary);
          this.page.set(null);
          this.status.set('ready');
        },
        error: (error: unknown) => this.failList(error),
      });
      return;
    }
    this.listSub = this.api.query({ ...filters, limit: 15, cursor }).subscribe({
      next: (page) => {
        this.page.set(page);
        this.summary.set(null);
        this.status.set(page.rows.length === 0 ? 'empty' : 'ready');
      },
      error: (error: unknown) => this.failList(error),
    });
  }

  private failList(error: unknown): void {
    this.status.set('error');
    this.message.set(asProblem(error).title);
    this.page.set(null);
    this.summary.set(null);
  }

  open(job: RatingJob): void {
    this.selectedId.set(job.id);
    this.detail.set(null);
    this.differences.set(null);
    this.showDifferences.set(false);
    this.aggregates.set(blankAggregates());
    this.detailSub?.unsubscribe();
    this.differenceSub?.unsubscribe();
    this.detailSub = this.api.detail(job.id).subscribe({
      next: (detail) => {
        if (this.selectedId() !== job.id) return;
        this.detail.set(detail);
        queueMicrotask(() => document.querySelector('.hv-job-detail')?.scrollIntoView({ block: 'nearest' }));
      },
      error: () => this.message.set('The job detail could not be loaded.'),
    });
    for (const table of AGG_TABLES) this.loadAggregate(table.id, null);
  }

  closeDetail(): void {
    this.selectedId.set(null);
    this.detail.set(null);
    this.differences.set(null);
    this.showDifferences.set(false);
    this.detailSub?.unsubscribe();
    this.differenceSub?.unsubscribe();
    this.cancelAggregates();
    this.aggregates.set(blankAggregates());
  }

  agg(id: AggTableId): AggView {
    return this.aggregates()[id];
  }

  setAggField(id: AggTableId, key: 'text' | 'minDifference', event: Event): void {
    const target = event.target;
    if (!(target instanceof HTMLInputElement)) return;
    this.aggregates.update((state) => ({ ...state, [id]: { ...state[id], [key]: target.value } }));
  }

  applyAggregate(id: AggTableId): void {
    this.aggregates.update((state) => ({
      ...state,
      [id]: { ...state[id], appliedText: state[id].text.trim(), appliedMin: state[id].minDifference.trim() },
    }));
    this.loadAggregate(id, null);
  }

  clearAggregate(id: AggTableId): void {
    this.aggregates.update((state) => ({
      ...state,
      [id]: { ...blankAggregates()[id], status: state[id].status, page: state[id].page },
    }));
    this.aggregates.update((state) => ({
      ...state,
      [id]: { ...state[id], appliedText: '', appliedMin: '', text: '', minDifference: '' },
    }));
    this.loadAggregate(id, null);
  }

  clearAggregateFilters(): void {
    this.aggregates.set(blankAggregates());
    for (const table of AGG_TABLES) this.loadAggregate(table.id, null);
  }

  loadAggregate(id: AggTableId, cursor: string | null): void {
    const jobId = this.selectedId();
    if (jobId === null) return;
    const view = this.aggregates()[id];
    const min = view.appliedMin === '' ? null : Number(view.appliedMin);
    if (min !== null && !Number.isFinite(min)) {
      this.patchAggregate(id, { status: 'error', message: 'Minimum value difference must be a number', page: null });
      return;
    }
    const generation = ++this.aggGen[id];
    this.aggSubs.get(id)?.unsubscribe();
    this.patchAggregate(id, { status: 'loading', message: null });
    const sub = this.api
      .aggregate(jobId, { table: id, text: view.appliedText, minDifference: min, limit: 12, cursor })
      .subscribe({
        next: (page) => {
          if (generation !== this.aggGen[id] || this.selectedId() !== jobId) return;
          this.patchAggregate(id, { page, status: page.rows.length === 0 ? 'empty' : 'ready', message: null });
        },
        error: (error: unknown) => {
          if (generation !== this.aggGen[id] || this.selectedId() !== jobId) return;
          this.patchAggregate(id, { status: 'error', message: asProblem(error).title, page: null });
        },
      });
    this.aggSubs.set(id, sub);
  }

  showTopDifferences(): void {
    const jobId = this.selectedId();
    if (jobId === null) return;
    this.showDifferences.set(true);
    this.differenceSub?.unsubscribe();
    this.differenceSub = this.api.differences(jobId).subscribe({
      next: (rows) => {
        if (this.selectedId() === jobId) this.differences.set(rows);
      },
      error: () => this.message.set('Top differences could not be loaded.'),
    });
  }

  showFileSummary(): void {
    document.querySelector('#file-summary')?.scrollIntoView({ block: 'nearest' });
  }

  exportAggregate(id: AggTableId): void {
    const page = this.aggregates()[id].page;
    const jobId = this.selectedId();
    if (!page || jobId === null) return;
    const lines = ['Label,Origin,Original,Value difference,Mismatched,Matched'];
    for (const row of page.rows) {
      lines.push(
        [csvCell(row.label), csvCell(row.origin ?? ''), row.original, row.valueDifference, row.mismatched ?? '', row.matched ?? ''].join(','),
      );
    }
    const blob = new Blob([lines.join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `rating-${jobId}-${id}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  }

  gaugeDash(value: number): string {
    return `${Math.max(0, Math.min(100, value))} 100`;
  }

  money(value: number): string {
    return new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 4 }).format(value);
  }

  exact(iso: string): string {
    const date = new Date(iso);
    if (Number.isNaN(date.getTime())) return iso;
    const pad = (value: number) => String(value).padStart(2, '0');
    return `${date.getUTCFullYear()}-${pad(date.getUTCMonth() + 1)}-${pad(date.getUTCDate())} ${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}:${pad(date.getUTCSeconds())}`;
  }

  private patchAggregate(id: AggTableId, patch: Partial<AggView>): void {
    this.aggregates.update((state) => ({ ...state, [id]: { ...state[id], ...patch } }));
  }

  private cancelAggregates(): void {
    for (const sub of this.aggSubs.values()) sub.unsubscribe();
    this.aggSubs.clear();
  }

  run(): void {
    this.runBusy.set(true);
    this.api.run(this.runStream()).subscribe({
      next: (job) => {
        this.runBusy.set(false);
        this.load(null);
        this.open(job);
        setTimeout(() => {
          if (this.selectedId() === job.id) {
            this.load(null);
            this.open(job);
          }
        }, 1700);
      },
      error: () => {
        this.runBusy.set(false);
        this.message.set('The rating job could not be started.');
      },
    });
  }

  onUpload(event: Event): void {
    const target = event.target;
    if (!(target instanceof HTMLInputElement) || !target.files?.[0]) return;
    const file = target.files[0];
    target.value = '';
    if (file.size > 262_144) {
      this.uploadNote.set('That file is over 256 KB. The browser will not read it. A production worker would store the object.');
      return;
    }
    this.api.registerCsl(file.name, file.size).subscribe({
      next: (upload) => {
        this.uploadNote.set(`Registered ${upload.name} (${formatNumber(upload.bytes)} bytes). The file body was not loaded into the job list.`);
        const selected = this.selectedId();
        if (selected !== null) this.open({ id: selected } as RatingJob);
      },
      error: () => this.uploadNote.set('The CSL file could not be registered.'),
    });
  }

  setField<K extends keyof Draft>(key: K, event: Event): void {
    const target = event.target;
    if (!(target instanceof HTMLInputElement) && !(target instanceof HTMLSelectElement)) return;
    this.draft.update((draft) => ({ ...draft, [key]: target.value }));
  }

  setRunStream(event: Event): void {
    const target = event.target;
    if (target instanceof HTMLSelectElement && (target.value === 'IN' || target.value === 'BSCS')) {
      this.runStream.set(target.value);
    }
  }

  formatCount(value: number): string {
    return formatNumber(value);
  }

  stamp(iso: string): string {
    return formatStamp(iso);
  }

  durationLabel(seconds: number): string {
    return formatDuration(seconds);
  }
}

function decorate(job: RatingJob) {
  return {
    ...job,
    idLabel: formatNumber(job.id),
    startLabel: formatStamp(job.startTime),
    endLabel: formatStamp(job.endTime),
    decodedLabel: formatNumber(job.decoded),
    filteredLabel: formatNumber(job.filtered),
    ratedLabel: formatNumber(job.rated),
    erroredLabel: formatNumber(job.erroredRate),
  };
}

function formatNumber(value: number): string {
  return new Intl.NumberFormat('en-US').format(value);
}

function formatStamp(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const pad = (value: number) => String(value).padStart(2, '0');
  return `${months[date.getUTCMonth()]} ${date.getUTCDate()} ${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}:${pad(date.getUTCSeconds())}`;
}

function csvCell(value: string): string {
  if (/[",\n]/.test(value)) return `"${value.replaceAll('"', '""')}"`;
  return value;
}

export function formatDuration(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const rest = seconds % 60;
  if (minutes <= 0) return `${rest}s`;
  return `${minutes}m ${rest}s`;
}
