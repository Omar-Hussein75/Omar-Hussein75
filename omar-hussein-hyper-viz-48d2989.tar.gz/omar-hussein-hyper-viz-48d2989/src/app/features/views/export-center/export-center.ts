import { HttpClient } from '@angular/common/http';
import { Component, inject, input, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import type { ExportJob, ViewDefinition } from '../../../core/models/contracts';

@Component({
  selector: 'app-export-center',
  imports: [RouterLink],
  templateUrl: './export-center.html',
})
export class ExportCenter {
  private readonly http = inject(HttpClient);
  readonly view = input.required<ViewDefinition>();
  readonly jobs = signal<ExportJob[]>([]);
  readonly failed = signal(false);

  constructor() {
    this.refresh();
  }

  refresh(): void {
    this.http.get<{ jobs: ExportJob[] }>('/api/exports').subscribe({
      next: (response) => {
        this.jobs.set(response.jobs);
        this.failed.set(false);
      },
      error: () => this.failed.set(true),
    });
  }
}
