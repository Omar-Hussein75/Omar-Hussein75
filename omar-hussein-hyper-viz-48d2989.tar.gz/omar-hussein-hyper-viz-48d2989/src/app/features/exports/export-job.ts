import { HttpClient } from '@angular/common/http';
import { Component, DestroyRef, inject, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import type { ExportJob } from '../../core/models/contracts';
import { StatusPanel } from '../../shared/ui/status-panel';

@Component({
  selector: 'app-export-job',
  imports: [RouterLink, StatusPanel],
  templateUrl: './export-job.html',
})
export class ExportJobPage {
  private readonly http = inject(HttpClient);
  private readonly route = inject(ActivatedRoute);
  private readonly destroyRef = inject(DestroyRef);
  readonly job = signal<ExportJob | null>(null);
  readonly issue = signal<string | null>(null);
  private timer: ReturnType<typeof setTimeout> | null = null;
  private attempt = 0;

  constructor() {
    this.route.paramMap.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((params) => {
      this.attempt = 0;
      this.poll(params.get('jobId') ?? '');
    });
    this.destroyRef.onDestroy(() => {
      if (this.timer) clearTimeout(this.timer);
    });
  }

  download(): void {
    const job = this.job();
    if (!job) return;
    this.http.get(`/api/exports/${job.id}/download`, { responseType: 'text' }).subscribe({
      next: (csv) => {
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = `${job.id}.csv`;
        anchor.click();
        URL.revokeObjectURL(url);
      },
      error: () => this.issue.set('The file is not available.'),
    });
  }

  cancel(): void {
    const job = this.job();
    if (!job) return;
    this.http.post<ExportJob>(`/api/exports/${job.id}/cancel`, {}).subscribe({
      next: (next) => this.job.set(next),
      error: () => this.issue.set('The job could not be cancelled.'),
    });
  }

  private poll(jobId: string): void {
    if (!jobId) return;
    if (this.timer) clearTimeout(this.timer);
    this.http.get<ExportJob>(`/api/exports/${jobId}`).subscribe({
      next: (job) => {
        this.job.set(job);
        this.issue.set(null);
        if (job.status === 'queued' || job.status === 'running') {
          const delay = [1000, 2000, 4000, 5000][Math.min(this.attempt, 3)] ?? 5000;
          this.attempt += 1;
          this.timer = setTimeout(() => this.poll(jobId), delay);
        }
      },
      error: () => this.issue.set('That export is not available.'),
    });
  }
}
