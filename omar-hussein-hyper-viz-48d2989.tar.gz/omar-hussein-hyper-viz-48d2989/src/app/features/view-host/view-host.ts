import { httpResource } from '@angular/common/http';
import { NgComponentOutlet } from '@angular/common';
import { Component, effect, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute } from '@angular/router';
import { map } from 'rxjs';
import type { Type } from '@angular/core';
import { isViewKind, VIEW_LOADERS } from '../../core/config/view-registry';
import type { UiKind, ViewDefinition } from '../../core/models/contracts';
import { asProblem, uiKindFor } from '../../core/query/query-rules';
import { StatusPanel } from '../../shared/ui/status-panel';

@Component({
  selector: 'app-view-host',
  imports: [NgComponentOutlet, StatusPanel],
  templateUrl: './view-host.html',
})
export class ViewHost {
  private readonly route = inject(ActivatedRoute);
  private loadGeneration = 0;
  readonly component = signal<Type<unknown> | null>(null);
  readonly unsupported = signal(false);

  readonly viewId = toSignal(this.route.paramMap.pipe(map((params) => params.get('viewId') ?? '')), {
    initialValue: '',
  });

  readonly viewResource = httpResource<ViewDefinition>(() => {
    const id = this.viewId();
    return id ? `/api/views/${id}` : undefined;
  });

  constructor() {
    effect(() => {
      if (!this.viewResource.hasValue()) {
        this.component.set(null);
        return;
      }
      const kind = this.viewResource.value().kind;
      if (!isViewKind(kind)) {
        this.unsupported.set(true);
        this.component.set(null);
        return;
      }
      this.unsupported.set(false);
      const generation = ++this.loadGeneration;
      void VIEW_LOADERS[kind]().then((component) => {
        if (generation === this.loadGeneration) this.component.set(component);
      });
    });
  }

  issueTitle(): string {
    return asProblem(this.viewResource.error()).title;
  }

  issueDetail(): string | null {
    return asProblem(this.viewResource.error()).detail ?? null;
  }

  issueKind(): UiKind {
    return uiKindFor(asProblem(this.viewResource.error()));
  }
}
