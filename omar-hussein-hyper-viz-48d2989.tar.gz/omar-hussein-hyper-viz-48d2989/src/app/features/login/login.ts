import { Component, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { SessionStore } from '../../core/session/session-store';

@Component({
  selector: 'app-login',
  imports: [RouterLink],
  templateUrl: './login.html',
})
export class Login {
  private readonly session = inject(SessionStore);
  private readonly router = inject(Router);
  readonly error = signal<string | null>(null);
  readonly busy = signal(false);

  signIn(userId: string): void {
    this.busy.set(true);
    this.error.set(null);
    this.session.login(userId).subscribe({
      next: () => {
        this.busy.set(false);
        void this.router.navigateByUrl('/app');
      },
      error: () => {
        this.busy.set(false);
        this.error.set('The fixture session could not be started.');
      },
    });
  }
}
