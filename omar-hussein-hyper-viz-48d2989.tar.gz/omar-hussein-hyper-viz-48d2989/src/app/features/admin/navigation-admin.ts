import { HttpClient } from '@angular/common/http';
import { Component, computed, inject, signal } from '@angular/core';
import type { AdminCatalog, IconKey, NavNode, ViewKind } from '../../core/models/contracts';
import { StatusPanel } from '../../shared/ui/status-panel';

@Component({
  selector: 'app-navigation-admin',
  imports: [StatusPanel],
  templateUrl: './navigation-admin.html',
})
export class NavigationAdmin {
  private readonly http = inject(HttpClient);
  readonly nodes = signal<NavNode[]>([]);
  readonly version = signal(0);
  readonly catalog = signal<AdminCatalog | null>(null);
  readonly message = signal<string | null>(null);
  readonly error = signal<string | null>(null);
  readonly label = signal('');
  readonly parentId = signal('');
  readonly icon = signal<IconKey>('folder');
  readonly folder = signal(true);
  readonly kind = signal<ViewKind>('data-table');
  readonly reportId = signal('customer_accounts');
  readonly permission = signal('billing.read');

  readonly ordered = computed(() => [...this.nodes()].sort((a, b) => a.order - b.order));

  constructor() {
    this.http.get<AdminCatalog>('/api/admin/catalog').subscribe({
      next: (catalog) => {
        this.catalog.set(catalog);
        const report = catalog.reports[0];
        const permission = catalog.permissions[0];
        const icon = catalog.icons[0];
        if (report) this.reportId.set(report.id);
        if (permission) this.permission.set(permission);
        if (icon) this.icon.set(icon);
      },
      error: () => this.error.set('The catalog could not be loaded.'),
    });
    this.reload();
  }

  reload(): void {
    this.http.get<{ version: number; nodes: NavNode[] }>('/api/admin/draft').subscribe({
      next: (draft) => {
        this.version.set(draft.version);
        this.nodes.set(draft.nodes);
      },
      error: () => this.error.set('The draft could not be loaded.'),
    });
  }

  saveLabel(node: NavNode, event: Event): void {
    const target = event.target;
    if (!(target instanceof HTMLInputElement)) return;
    this.http.patch<NavNode>(`/api/admin/nodes/${node.id}`, { label: target.value }).subscribe({
      next: () => this.reload(),
      error: () => this.error.set('The label was rejected. Use plain text, up to 60 characters.'),
    });
  }

  toggle(node: NavNode): void {
    this.http.patch(`/api/admin/nodes/${node.id}`, { enabled: !node.enabled }).subscribe({
      next: () => this.reload(),
      error: () => this.error.set('The item could not be updated.'),
    });
  }

  move(node: NavNode, direction: 'up' | 'down'): void {
    this.http.post(`/api/admin/nodes/${node.id}/move`, { direction }).subscribe({
      next: () => this.reload(),
      error: () => this.error.set('The item could not be moved.'),
    });
  }

  add(): void {
    this.error.set(null);
    this.http
      .post('/api/admin/nodes', {
        label: this.label(),
        parentId: this.parentId() || null,
        icon: this.icon(),
        folder: this.folder(),
        kind: this.kind(),
        reportId: this.reportId(),
        requiredPermission: this.permission(),
      })
      .subscribe({
        next: () => {
          this.label.set('');
          this.message.set('Added to the draft. Publish to show it in the live navigation.');
          this.reload();
        },
        error: () => this.error.set('The item was rejected. Check the label, parent, report, and permission.'),
      });
  }

  publish(): void {
    this.http.post<{ version: number }>('/api/admin/publications', { baseVersion: this.version() }).subscribe({
      next: (result) => {
        this.message.set(`Published configuration v${result.version}. Sessions pick it up without a frontend deploy.`);
        this.reload();
      },
      error: () => this.error.set('Publish conflicted. Reload the draft and try again.'),
    });
  }

  rollback(): void {
    this.http.post<{ version: number }>('/api/admin/rollback', {}).subscribe({
      next: (result) => {
        this.message.set(`Restored an earlier publication as v${result.version}.`);
        this.reload();
      },
      error: () => this.error.set('There is no earlier publication to restore.'),
    });
  }

  asText(event: Event): string {
    const target = event.target;
    return target instanceof HTMLInputElement || target instanceof HTMLSelectElement ? target.value : '';
  }

  asChecked(event: Event): boolean {
    const target = event.target;
    return target instanceof HTMLInputElement ? target.checked : false;
  }

  asIcon(event: Event): IconKey {
    const value = this.asText(event);
    return (this.catalog()?.icons ?? []).find((icon) => icon === value) ?? 'folder';
  }

  asKind(event: Event): ViewKind {
    const value = this.asText(event);
    return (this.catalog()?.kinds ?? []).find((kind) => kind === value) ?? 'data-table';
  }

  depth(node: NavNode): number {
    let depth = 0;
    let parent = node.parentId;
    const nodes = this.nodes();
    while (parent) {
      depth += 1;
      parent = nodes.find((item) => item.id === parent)?.parentId ?? null;
    }
    return depth;
  }
}
