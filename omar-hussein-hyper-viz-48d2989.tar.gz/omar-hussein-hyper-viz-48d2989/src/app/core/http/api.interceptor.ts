import { HttpErrorResponse, HttpEvent, HttpInterceptorFn, HttpRequest, HttpResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ContractApi } from '../mock/contract-api';
import { Telemetry } from '../telemetry/telemetry';

export const csrfInterceptor: HttpInterceptorFn = (req, next) => {
  if (!req.url.startsWith('/api/') || req.method === 'GET' || req.method === 'HEAD') return next(req);
  return next(req.clone({ setHeaders: { 'X-CSRF-Token': 'hyperviz' } }));
};

export const contractMockInterceptor: HttpInterceptorFn = (req, next) => {
  if (!req.url.startsWith('/api/')) return next(req);
  const api = inject(ContractApi);
  const telemetry = inject(Telemetry);
  return new Observable<HttpEvent<unknown>>((subscriber) => {
    const started = performance.now();
    let settled = false;
    const timer = setTimeout(() => {
      settled = true;
      const result = api.dispatch(req);
      telemetry.record({
        method: req.method,
        path: pathOf(req),
        status: result.status,
        ms: Math.round(performance.now() - started),
        bytes: result instanceof HttpResponse ? byteSize(result.body) : undefined,
      });
      if (result instanceof HttpErrorResponse) subscriber.error(result);
      else {
        subscriber.next(result);
        subscriber.complete();
      }
    }, api.delayFor(req));
    return () => {
      clearTimeout(timer);
      if (!settled) {
        telemetry.record({
          method: req.method,
          path: pathOf(req),
          status: 'cancelled',
          ms: Math.round(performance.now() - started),
        });
      }
    };
  });
};

function pathOf(req: HttpRequest<unknown>): string {
  return req.url.split('?')[0] ?? req.url;
}

function byteSize(body: unknown): number {
  if (typeof body === 'string') return body.length;
  try {
    return JSON.stringify(body).length;
  } catch {
    return 0;
  }
}
