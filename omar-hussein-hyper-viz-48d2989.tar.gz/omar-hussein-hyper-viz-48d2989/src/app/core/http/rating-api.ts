import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import type {
  AggPage,
  AggTableId,
  DifferenceRow,
  RatingJob,
  RatingJobDetail,
  RatingPage,
  RatingQuery,
  RatingSummary,
} from '../mock/rating-jobs';

@Injectable({ providedIn: 'root' })
export class RatingApi {
  private readonly http = inject(HttpClient);

  query(body: RatingQuery) {
    return this.http.post<RatingPage>('/api/rating/jobs/query', body, { timeout: 30_000 });
  }

  summary(body: Omit<RatingQuery, 'limit' | 'cursor'>) {
    return this.http.post<RatingSummary>('/api/rating/jobs/summary', body, { timeout: 30_000 });
  }

  detail(id: number) {
    return this.http.get<RatingJobDetail & { uploads: { name: string; bytes: number; at: string }[] }>(
      `/api/rating/jobs/${id}`,
    );
  }

  aggregate(id: number, body: { table: AggTableId; text: string; minDifference: number | null; limit: number; cursor: string | null }) {
    return this.http.post<AggPage>(`/api/rating/jobs/${id}/aggregate`, body);
  }

  differences(id: number) {
    return this.http.post<DifferenceRow[]>(`/api/rating/jobs/${id}/differences`, { limit: 8 });
  }

  run(stream: 'IN' | 'BSCS') {
    return this.http.post<RatingJob>('/api/rating/jobs/run', { stream });
  }

  registerCsl(name: string, bytes: number) {
    return this.http.post<{ name: string; bytes: number; at: string }>('/api/rating/csl', { name, bytes });
  }
}
