import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, finalize, shareReplay } from 'rxjs';
import type { AggregateRequest, AggregateResponse, QueryRequest, QueryResponse } from '../models/contracts';

@Injectable({ providedIn: 'root' })
export class QueryGateway {
  private readonly http = inject(HttpClient);
  private readonly inflight = new Map<string, Observable<unknown>>();

  query(reportId: string, body: QueryRequest): Observable<QueryResponse> {
    return this.dedupe(`POST /api/reports/${reportId}/query`, JSON.stringify(body), () =>
      this.http.post<QueryResponse>(`/api/reports/${reportId}/query`, body, { timeout: 30_000 }),
    );
  }

  aggregate(reportId: string, body: AggregateRequest): Observable<AggregateResponse> {
    return this.dedupe(`POST /api/reports/${reportId}/aggregate`, JSON.stringify(body), () =>
      this.http.post<AggregateResponse>(`/api/reports/${reportId}/aggregate`, body, { timeout: 60_000 }),
    );
  }

  private dedupe<T>(name: string, body: string, create: () => Observable<T>): Observable<T> {
    const key = `${name} ${body}`;
    const existing = this.inflight.get(key) as Observable<T> | undefined;
    if (existing) return existing;
    const request = create().pipe(
      finalize(() => this.inflight.delete(key)),
      shareReplay({ bufferSize: 1, refCount: true }),
    );
    this.inflight.set(key, request);
    return request;
  }
}
