import type { Type } from '@angular/core';
import type { ViewKind } from '../models/contracts';

export const VIEW_LOADERS: Record<ViewKind, () => Promise<Type<unknown>>> = {
  dashboard: () => import('../../features/views/dashboard/dashboard').then((module) => module.Dashboard),
  'data-table': () => import('../../features/views/data-table/data-table').then((module) => module.DataTable),
  'time-series': () => import('../../features/views/time-series/time-series').then((module) => module.TimeSeries),
  'kpi-board': () => import('../../features/views/kpi-board/kpi-board').then((module) => module.KpiBoard),
  export: () => import('../../features/views/export-center/export-center').then((module) => module.ExportCenter),
  'rating-jobs': () => import('../../features/views/rating-jobs/rating-jobs').then((module) => module.RatingJobs),
};

export function isViewKind(value: string): value is ViewKind {
  return Object.prototype.hasOwnProperty.call(VIEW_LOADERS, value);
}
