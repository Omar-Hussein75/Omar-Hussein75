import { describe, expect, it } from 'vitest';
import { buildFilter, validatePageLimit, validateWindow } from './query-rules';
import type { ParameterDef } from '../models/contracts';
import { runAggregate, runQuery } from '../mock/virtual-query';

const dates: ParameterDef[] = [
  { key: 'startDate', label: 'Start', type: 'date-time', required: true, bindsTo: 'timestamp', operator: 'gte' },
  { key: 'endDate', label: 'End', type: 'date-time', required: true, bindsTo: 'timestamp', operator: 'lt' },
];

describe('query bounds', () => {
  it('rejects a page limit above 500', () => {
    expect(validatePageLimit(10_000)?.status).toBe(400);
    expect(validatePageLimit(100)).toBeNull();
  });

  it('rejects a window wider than the report allows', () => {
    const issue = validateWindow('2026-01-01T00:00:00.000Z', '2026-03-01T00:00:00.000Z', 31);
    expect(issue?.status).toBe(422);
    expect(issue?.errors?.[0]?.code).toBe('window_exceeded');
  });

  it('keeps optional empty filters out of the query', () => {
    const built = buildFilter(
      [...dates, { key: 'region', label: 'Region', type: 'multi-select', required: false, bindsTo: 'regionCode', operator: 'in' }],
      { startDate: '2026-09-01T00:00', endDate: '2026-09-03T00:00', region: [] },
      { maxWindowDays: 31 },
    );
    expect('filter' in built).toBe(true);
    if ('filter' in built) {
      expect(built.filter.conditions.map((condition) => condition.field)).toEqual(['timestamp', 'timestamp']);
    }
  });
});

describe('virtual reports', () => {
  const filter = {
    op: 'and' as const,
    conditions: [
      { field: 'timestamp', op: 'gte' as const, value: '2026-09-01T00:00:00.000Z' },
      { field: 'timestamp', op: 'lt' as const, value: '2026-09-03T00:00:00.000Z' },
    ],
  };

  it('returns one page and refuses to materialize the whole window', () => {
    const result = runQuery('network_performance', {
      filter,
      sort: [{ field: 'timestamp', direction: 'desc' }],
      page: { limit: 100, cursor: null, includeTotal: true },
      columns: ['timestamp', 'regionCode', 'latencyMs'],
    });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.body.rows).toHaveLength(100);
    expect(result.body.total).toBeGreaterThan(100);
    expect(Object.keys(result.body.rows[0] ?? {}).sort()).toEqual(['id', 'latencyMs', 'regionCode', 'timestamp']);
    expect(result.body.page.hasMore).toBe(true);
  });

  it('rejects an unbounded page request', () => {
    const result = runQuery('network_performance', {
      filter,
      sort: [],
      page: { limit: 5000, cursor: null, includeTotal: false },
      columns: ['timestamp'],
    });
    expect(result.ok).toBe(false);
  });

  it('refuses a minute series that would exceed the point cap', () => {
    const result = runAggregate('network_traffic', {
      filter: {
        op: 'and',
        conditions: [
          { field: 'timestamp', op: 'gte', value: '2026-09-01T00:00:00.000Z' },
          { field: 'timestamp', op: 'lt', value: '2026-09-08T00:00:00.000Z' },
        ],
      },
      time: { field: 'timestamp', bucket: 'minute' },
      metric: 'sumBytes',
      maxPoints: 2000,
    });
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.problem.type).toContain('point-cap');
  });

  it('returns an hourly series instead of raw samples', () => {
    const result = runAggregate('network_performance', {
      filter,
      time: { field: 'timestamp', bucket: 'hour' },
      metric: 'avgLatencyMs',
      maxPoints: 2000,
    });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.body.series?.points.length).toBe(48);
    expect(result.body.meta.truncated).toBe(false);
  });
});
