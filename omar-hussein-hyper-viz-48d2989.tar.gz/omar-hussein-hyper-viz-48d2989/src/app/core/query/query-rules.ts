import type {
  Bucket,
  FilterCondition,
  FilterDraft,
  FilterTree,
  ParameterDef,
  Problem,
  ViewDefinition,
} from '../models/contracts';

export const MAX_PAGE_LIMIT = 500;
export const HARD_POINT_CAP = 5000;
export const DEMO_EXPORT_ROW_CAP = 250;

const PROBLEM_BASE = 'https://api.hyperviz.local/problems';

export function problem(
  status: number,
  kind: string,
  title: string,
  detail?: string,
  errors?: Problem['errors'],
): Problem {
  return { type: `${PROBLEM_BASE}/${kind}`, title, status, detail, errors };
}

export function validatePageLimit(limit: unknown): Problem | null {
  if (typeof limit !== 'number' || !Number.isInteger(limit) || limit < 1) {
    return problem(400, 'invalid-body', 'Page limit is required', 'Send an integer page.limit between 1 and 500.');
  }
  if (limit > MAX_PAGE_LIMIT) {
    return problem(
      400,
      'invalid-body',
      'Page limit is too large',
      `The maximum page size is ${MAX_PAGE_LIMIT} rows.`,
    );
  }
  return null;
}

export function windowDays(startIso: string, endIso: string): number | null {
  const start = Date.parse(startIso);
  const end = Date.parse(endIso);
  if (Number.isNaN(start) || Number.isNaN(end) || end <= start) return null;
  return (end - start) / 86_400_000;
}

export function validateWindow(startIso: string, endIso: string, maxDays: number): Problem | null {
  const start = Date.parse(startIso);
  const end = Date.parse(endIso);
  if (Number.isNaN(start) || Number.isNaN(end)) {
    return problem(422, 'validation', 'Enter a valid date range', 'Start and end must be ISO-8601 timestamps.', [
      { field: 'startDate', code: 'invalid_date' },
    ]);
  }
  if (end <= start) {
    return problem(422, 'validation', 'End must be after start', undefined, [
      { field: 'endDate', code: 'range_order' },
    ]);
  }
  const days = (end - start) / 86_400_000;
  if (days > maxDays) {
    return problem(
      422,
      'validation',
      'The date range is too wide',
      `This report allows at most ${maxDays} days.`,
      [{ field: 'endDate', code: 'window_exceeded' }],
    );
  }
  return null;
}

export function pointCapProblem(points: number, bucket: Bucket, maxPoints: number): Problem {
  const suggestion = bucket === 'minute' ? 'hour' : bucket === 'hour' ? 'day' : undefined;
  return problem(
    422,
    'point-cap',
    'This chart would contain too many points',
    `${points.toLocaleString('en-US')} points exceeds the cap of ${Math.min(maxPoints, HARD_POINT_CAP).toLocaleString('en-US')}. Coarsen the bucket or shorten the range.`,
    suggestion ? [{ code: 'coarsen_bucket', suggestion }] : [{ code: 'shorten_range' }],
  );
}

export function bucketCount(startIso: string, endIso: string, bucket: Bucket): number {
  const start = Date.parse(startIso);
  const end = Date.parse(endIso);
  const size = bucket === 'minute' ? 60_000 : bucket === 'hour' ? 3_600_000 : 86_400_000;
  return Math.ceil((end - start) / size);
}

export function toIso(value: string): string | null {
  if (!value) return null;
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value)) {
    return `${value}:00.000Z`;
  }
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z$/.test(value)) return value;
  const parsed = Date.parse(value);
  if (Number.isNaN(parsed)) return null;
  return new Date(parsed).toISOString();
}

export function toLocalInput(iso: string): string {
  const parsed = Date.parse(iso);
  if (Number.isNaN(parsed)) return '';
  return new Date(parsed).toISOString().slice(0, 16);
}

export function resolveDefault(value: string | string[] | undefined, now = new Date()): string | string[] {
  if (Array.isArray(value)) return value;
  if (!value) return '';
  if (value === 'now') return now.toISOString();
  const relative = /^P(\d+)D$/.exec(value);
  if (relative) {
    const days = Number(relative[1]);
    return new Date(now.getTime() - days * 86_400_000).toISOString();
  }
  return value;
}

export function defaultsFor(view: ViewDefinition, now = new Date()): FilterDraft {
  const draft: FilterDraft = {};
  for (const parameter of view.parameters) {
    draft[parameter.key] = resolveDefault(view.defaults[parameter.key], now);
  }
  return draft;
}

export function buildFilter(
  parameters: ParameterDef[],
  draft: FilterDraft,
  constraints: { maxWindowDays?: number },
): { filter: FilterTree } | { problem: Problem } {
  const conditions: FilterCondition[] = [];
  const dates = new Map<string, { start?: string; end?: string }>();

  for (const parameter of parameters) {
    const raw = draft[parameter.key];
    const empty = raw === undefined || raw === '' || (Array.isArray(raw) && raw.length === 0);
    if (empty) {
      if (parameter.required) {
        return {
          problem: problem(422, 'validation', `${parameter.label} is required`, undefined, [
            { field: parameter.key, code: 'required' },
          ]),
        };
      }
      continue;
    }

    if (parameter.type === 'date-time') {
      const iso = toIso(String(raw));
      if (!iso) {
        return {
          problem: problem(422, 'validation', `${parameter.label} is not a valid date`, undefined, [
            { field: parameter.key, code: 'invalid_date' },
          ]),
        };
      }
      conditions.push({ field: parameter.bindsTo, op: parameter.operator, value: iso });
      const slot = dates.get(parameter.bindsTo) ?? {};
      if (parameter.operator === 'gte') slot.start = iso;
      if (parameter.operator === 'lt') slot.end = iso;
      dates.set(parameter.bindsTo, slot);
      continue;
    }

    if (parameter.operator === 'in') {
      const values = Array.isArray(raw) ? raw : [String(raw)];
      conditions.push({ field: parameter.bindsTo, op: 'in', value: values });
      continue;
    }

    conditions.push({
      field: parameter.bindsTo,
      op: parameter.operator,
      value: String(raw),
    });
  }

  if (constraints.maxWindowDays !== undefined) {
    for (const range of dates.values()) {
      if (!range.start || !range.end) {
        return {
          problem: problem(422, 'validation', 'A start and end are required', undefined, [
            { code: 'window_required' },
          ]),
        };
      }
      const windowProblem = validateWindow(range.start, range.end, constraints.maxWindowDays);
      if (windowProblem) return { problem: windowProblem };
    }
  }

  return { filter: { op: 'and', conditions } };
}

export function encodeCursor(offset: number): string {
  const payload = String(offset);
  return btoa(`${payload}.${hash(payload)}`);
}

export function decodeCursor(cursor: string): number | null {
  try {
    const raw = atob(cursor);
    const dot = raw.lastIndexOf('.');
    if (dot <= 0) return null;
    const payload = raw.slice(0, dot);
    const sig = raw.slice(dot + 1);
    if (hash(payload) !== sig) return null;
    const offset = Number(payload);
    if (!Number.isInteger(offset) || offset < 0) return null;
    return offset;
  } catch {
    return null;
  }
}

function hash(value: string): string {
  let h = 2166136261;
  const salted = `${value}:hyperviz`;
  for (let i = 0; i < salted.length; i += 1) {
    h ^= salted.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16);
}

export function asProblem(error: unknown): Problem {
  if (typeof error === 'object' && error !== null && 'error' in error) {
    const inner = (error as { error?: unknown }).error;
    if (isProblem(inner)) return inner;
  }
  if (isProblem(error)) return error;
  return problem(503, 'unavailable', 'The service did not respond', 'Try the request again.');
}

export function isProblem(value: unknown): value is Problem {
  return (
    typeof value === 'object' &&
    value !== null &&
    'status' in value &&
    'title' in value &&
    'type' in value
  );
}

export function uiKindFor(issue: Problem): 'error' | 'timeout' | 'forbidden' | 'not-found' | 'point-cap' | 'rate-limited' {
  if (issue.type.endsWith('/point-cap')) return 'point-cap';
  if (issue.status === 401 || issue.status === 403) return 'forbidden';
  if (issue.status === 404) return 'not-found';
  if (issue.status === 429) return 'rate-limited';
  if (issue.status === 504 || issue.type.endsWith('/timeout')) return 'timeout';
  return 'error';
}
