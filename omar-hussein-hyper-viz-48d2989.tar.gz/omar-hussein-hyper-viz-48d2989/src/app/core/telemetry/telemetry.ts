import { Injectable, signal } from '@angular/core';

export interface TelemetryEvent {
  at: string;
  method: string;
  path: string;
  status: number | 'cancelled';
  ms: number;
  bytes?: number;
}

@Injectable({ providedIn: 'root' })
export class Telemetry {
  readonly events = signal<TelemetryEvent[]>([]);

  record(event: Omit<TelemetryEvent, 'at'>): void {
    const path = event.path.split('?')[0] ?? event.path;
    const next: TelemetryEvent = { ...event, path, at: new Date().toISOString().slice(11, 19) };
    this.events.update((events) => [next, ...events].slice(0, 30));
  }
}
