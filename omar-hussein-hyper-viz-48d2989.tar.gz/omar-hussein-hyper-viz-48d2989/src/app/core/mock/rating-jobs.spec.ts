import { describe, expect, it } from 'vitest';
import { CSL_SAMPLE_CAP, detailFor, listRatingJobs, queryAggregates, queryRatingJobs, summarizeRatingJobs, topDifferences } from './rating-jobs';

const september = {
  start: '2026-09-01',
  end: '2026-09-30',
  stream: '',
  jobStatus: '',
  statusDescr: '',
  limit: 15,
  cursor: null,
};

describe('rating validation jobs', () => {
  it('returns one page and the full match count', () => {
    const result = queryRatingJobs([], september);
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.body.rows).toHaveLength(15);
    expect(result.body.total).toBeGreaterThan(15);
    expect(result.body.rows[0]?.id).toBe(5329);
    expect(result.body.rows[0]?.erroredRate).toBe(22);
  });

  it('rejects a page above the cap', () => {
    const result = queryRatingJobs([], { ...september, limit: 5000 });
    expect(result.ok).toBe(false);
  });

  it('filters to one stream without dropping the page bound', () => {
    const result = queryRatingJobs([], { ...september, stream: 'BSCS', limit: 100 });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.body.rows.every((job) => job.streamName === 'BSCS')).toBe(true);
    expect(result.body.rows.length).toBeLessThanOrEqual(100);
  });

  it('summarizes every matching job, not the visible page', () => {
    const page = queryRatingJobs([], september);
    const summary = summarizeRatingJobs([], september);
    expect(page.ok && summary.ok).toBe(true);
    if (!page.ok || !summary.ok) return;
    expect(summary.body.jobs).toBe(page.body.total);
    expect(summary.body.decoded).toBeGreaterThan(page.body.rows.reduce((sum, job) => sum + job.decoded, 0));
  });

  it('keeps the CSL sample inside the cap', () => {
    const job = listRatingJobs([])[0];
    expect(job).toBeDefined();
    if (!job) return;
    const detail = detailFor(job);
    expect(detail.inCsl.length).toBeLessThanOrEqual(CSL_SAMPLE_CAP);
    expect(detail.bscsCsl.length).toBeLessThanOrEqual(CSL_SAMPLE_CAP);
    expect(detail.decoded).toBe(382496);
    expect(detail.jobName).toBe('HU');
    expect(detail.comparisonDay).toBe('2026-09-21');
    expect(detail.gauges.overallMatched).toBe(93.13);
    expect(detail.gauges.overallValueAccuracy).toBe(97.15);
  });

  it('filters every aggregate table and keeps the page bounded', () => {
    const job = listRatingJobs([])[0];
    expect(job).toBeDefined();
    if (!job) return;
    const jobTable = queryAggregates(job, { table: 'job', text: '', minDifference: null, limit: 12, cursor: null });
    const plans = queryAggregates(job, { table: 'rate-plan', text: 'flex', minDifference: null, limit: 12, cursor: null });
    const blocked = queryAggregates(job, { table: 'sub-plan', text: '', minDifference: 100000, limit: 12, cursor: null });
    const tooBig = queryAggregates(job, { table: 'call-type', text: '', minDifference: null, limit: 5000, cursor: null });
    expect(jobTable.ok && plans.ok && blocked.ok).toBe(true);
    expect(tooBig.ok).toBe(false);
    if (!jobTable.ok || !plans.ok || !blocked.ok) return;
    expect(jobTable.body.total).toBe(1);
    expect(jobTable.body.rows[0]?.original).toBe(209997.97);
    expect(jobTable.body.rows[0]?.mismatched).toBe(13594);
    expect(plans.body.rows.every((row) => row.label.toLowerCase().includes('flex'))).toBe(true);
    expect(plans.body.total).toBeLessThan(12);
    expect(blocked.body.total).toBe(0);
    const differences = topDifferences(job, 8);
    expect(differences).toHaveLength(8);
    expect(differences[0]?.label).toBe('LOCAL GPRS');
    expect(differences[0]?.valueDifference).toBe(4102.55);
  });
});
