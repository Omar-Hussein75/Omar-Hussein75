import type {
  AggregateResponse,
  Bucket,
  FilterCondition,
  FilterTree,
  Problem,
  QueryResponse,
} from '../models/contracts';
import {
  HARD_POINT_CAP,
  bucketCount,
  decodeCursor,
  encodeCursor,
  pointCapProblem,
  problem,
  validatePageLimit,
  validateWindow,
} from '../query/query-rules';
import { REGIONS, SITES, type ReportDef, reportById } from './catalog';

type Row = Record<string, string | number>;

export type QueryResult = { ok: true; body: QueryResponse } | { ok: false; problem: Problem };
export type AggregateResult = { ok: true; body: AggregateResponse } | { ok: false; problem: Problem };

const QUERY_KEYS = new Set(['filter', 'sort', 'page', 'columns']);
const PAGE_KEYS = new Set(['limit', 'cursor', 'includeTotal']);
const AGG_KEYS = new Set(['filter', 'time', 'metric', 'maxPoints', 'kpis']);

export function runQuery(reportId: string, body: unknown): QueryResult {
  const report = reportById(reportId);
  if (!report) return fail(problem(404, 'not-found', 'Unknown report'));
  if (!isRecord(body) || hasUnknown(body, QUERY_KEYS)) {
    return fail(problem(400, 'invalid-body', 'The query body has unexpected fields'));
  }
  const page = body['page'];
  if (!isRecord(page) || hasUnknown(page, PAGE_KEYS)) {
    return fail(problem(400, 'invalid-body', 'The page object is invalid'));
  }
  const limitProblem = validatePageLimit(page['limit']);
  if (limitProblem) return fail(limitProblem);
  const limit = page['limit'] as number;
  const includeTotal = page['includeTotal'] === true;
  let offset = 0;
  if (page['cursor'] != null) {
    if (typeof page['cursor'] !== 'string') return fail(problem(400, 'invalid-body', 'The cursor is invalid'));
    const decoded = decodeCursor(page['cursor']);
    if (decoded === null) return fail(problem(400, 'invalid-body', 'The cursor signature is invalid'));
    offset = decoded;
  }

  const columns = body['columns'];
  if (!Array.isArray(columns) || columns.length === 0 || columns.some((key) => typeof key !== 'string')) {
    return fail(problem(400, 'invalid-body', 'Choose at least one column'));
  }
  const allowed = new Set(report.fields.map((field) => field.key));
  if (columns.some((key) => !allowed.has(key))) {
    return fail(problem(400, 'invalid-body', 'A requested column is not in the report catalog'));
  }
  const projected = Array.from(new Set(['id', ...columns]));

  const filter = parseFilter(body['filter'], report);
  if ('problem' in filter) return fail(filter.problem);
  const sort = parseSort(body['sort'], report);
  if ('problem' in sort) return fail(sort.problem);
  const resolved = resolveScope(report, filter.filter);
  if ('problem' in resolved) return fail(resolved.problem);
  const scope = resolved.scope;

  const started = performance.now();
  const direction = sort.sort[0]?.direction ?? 'asc';
  const sortField = sort.sort[0]?.field ?? 'id';
  const matches = collect(report, scope, filter.filter);
  const natural =
    sortField === 'id' ||
    sortField === 'timestamp' ||
    (report.id === 'customer_accounts' && sortField === 'name');
  const ordered = natural
    ? direction === 'desc'
      ? matches.reverse()
      : matches
    : matches.sort((a, b) => compare(valueAt(report, scope, a, sortField), valueAt(report, scope, b, sortField), direction));

  const slice = ordered.slice(offset, offset + limit);
  const rows = slice.map((index) => project(materialize(report, scope, index), projected));
  const hasMore = offset + limit < ordered.length;
  const bodyOut: QueryResponse = {
    rows,
    page: {
      limit,
      nextCursor: hasMore ? encodeCursor(offset + limit) : null,
      prevCursor: offset > 0 ? encodeCursor(Math.max(0, offset - limit)) : null,
      hasMore,
    },
    total: includeTotal ? ordered.length : null,
    meta: { queryMs: Math.max(1, Math.round(performance.now() - started)), columns: projected },
  };
  return { ok: true, body: bodyOut };
}

export function runAggregate(reportId: string, body: unknown): AggregateResult {
  const report = reportById(reportId);
  if (!report) return { ok: false, problem: problem(404, 'not-found', 'Unknown report') };
  if (!isRecord(body) || hasUnknown(body, AGG_KEYS)) {
    return { ok: false, problem: problem(400, 'invalid-body', 'The aggregate body has unexpected fields') };
  }
  const filter = parseFilter(body['filter'], report);
  if ('problem' in filter) return { ok: false, problem: filter.problem };
  const resolved = resolveScope(report, filter.filter);
  if ('problem' in resolved) return { ok: false, problem: resolved.problem };
  const scope = resolved.scope;

  const started = performance.now();
  if (isRecord(body['time'])) {
    const bucket = body['time']['bucket'];
    if (bucket !== 'minute' && bucket !== 'hour' && bucket !== 'day') {
      return { ok: false, problem: problem(400, 'invalid-body', 'Unknown time bucket') };
    }
    if (scope.kind !== 'timeline') {
      return { ok: false, problem: problem(422, 'validation', 'This report has no time axis') };
    }
    const requestedCap = typeof body['maxPoints'] === 'number' ? body['maxPoints'] : 2000;
    const cap = Math.min(requestedCap, HARD_POINT_CAP);
    const points = bucketCount(scope.startIso, scope.endIso, bucket);
    if (points > cap) return { ok: false, problem: pointCapProblem(points, bucket, cap) };
    const metric = typeof body['metric'] === 'string' ? body['metric'] : 'avgLatencyMs';
    const series = buildSeries(scope, filter.filter, bucket, metric);
    return {
      ok: true,
      body: {
        bucket,
        series: { name: metric, points: series },
        meta: { queryMs: elapsed(started), pointCount: series.length, truncated: false },
      },
    };
  }

  const kpis = Array.isArray(body['kpis']) ? body['kpis'].filter((item): item is string => typeof item === 'string') : [];
  const metrics = computeKpis(report, scope, filter.filter, kpis.length ? kpis : ['sampleCount']);
  return {
    ok: true,
    body: { metrics, meta: { queryMs: elapsed(started), pointCount: 0, truncated: false } },
  };
}

function fail(issue: Problem): QueryResult {
  return { ok: false, problem: issue };
}

function elapsed(started: number): number {
  return Math.max(1, Math.round(performance.now() - started));
}

interface TimelineScope {
  kind: 'timeline';
  startMs: number;
  endMs: number;
  startIso: string;
  endIso: string;
  regions: string[];
}

interface LedgerScope {
  kind: 'ledger';
  size: number;
  cycle?: string;
}

type Scope = TimelineScope | LedgerScope;

function resolveScope(report: ReportDef, filter: FilterTree): { scope: Scope } | { problem: Problem } {
  if (report.shape === 'timeline') {
    const start = readCondition(filter, 'timestamp', 'gte');
    const end = readCondition(filter, 'timestamp', 'lt');
    if (typeof start !== 'string' || typeof end !== 'string') {
      return { problem: problem(422, 'validation', 'A date range is required for this report') };
    }
    const windowProblem = validateWindow(start, end, report.maxWindowDays ?? 31);
    if (windowProblem) return { problem: windowProblem };
    const regionFilter = readCondition(filter, 'regionCode', 'in');
    const regions = Array.isArray(regionFilter) && regionFilter.length > 0 ? regionFilter : REGIONS.map((region) => region.value);
    if (regions.some((region) => !REGIONS.some((known) => known.value === region))) {
      return { problem: problem(400, 'invalid-body', 'Unknown region') };
    }
    return {
      scope: {
        kind: 'timeline',
        startMs: Date.parse(start),
        endMs: Date.parse(end),
        startIso: start,
        endIso: end,
        regions,
      },
    };
  }

  let cycle: string | undefined;
  if (report.requires.includes('cycle')) {
    const value = readCondition(filter, 'cycle', 'eq');
    if (typeof value !== 'string' || !value) {
      return { problem: problem(422, 'validation', 'A billing cycle is required') };
    }
    cycle = value;
  }
  return { scope: { kind: 'ledger', size: report.ledgerSize ?? 0, cycle } };
}

function collect(report: ReportDef, scope: Scope, filter: FilterTree): number[] {
  const indexes: number[] = [];
  const space = scope.kind === 'timeline' ? timelineSpace(scope) : scope.size;
  for (let index = 0; index < space; index += 1) {
    if (matches(report, scope, index, filter)) indexes.push(index);
  }
  return indexes;
}

function timelineSpace(scope: TimelineScope): number {
  const minutes = Math.floor((scope.endMs - scope.startMs) / 60_000);
  return minutes * scope.regions.length;
}

function matches(report: ReportDef, scope: Scope, index: number, filter: FilterTree): boolean {
  for (const condition of filter.conditions) {
    if (condition.field === 'timestamp' || condition.field === 'cycle' || condition.field === 'regionCode') continue;
    const value = valueAt(report, scope, index, condition.field);
    if (condition.op === 'eq' && String(value) !== condition.value) return false;
    if (condition.op === 'contains') {
      if (typeof condition.value !== 'string') return false;
      if (!String(value).toLowerCase().includes(condition.value.toLowerCase())) return false;
    }
    if (condition.op === 'in' && Array.isArray(condition.value) && !condition.value.includes(String(value))) return false;
  }
  return true;
}

function valueAt(report: ReportDef, scope: Scope, index: number, field: string): string | number {
  return materialize(report, scope, index)[field] ?? '';
}

function materialize(report: ReportDef, scope: Scope, index: number): Row {
  if (scope.kind === 'timeline') return timelineRow(report.id, scope, index);
  return ledgerRow(report.id, scope, index);
}

function timelineRow(reportId: string, scope: TimelineScope, index: number): Row {
  const regionCount = scope.regions.length;
  const minute = Math.floor(index / regionCount);
  const region = scope.regions[index % regionCount] ?? scope.regions[0] ?? 'eu-west';
  const regionIndex = Math.max(0, REGIONS.findIndex((item) => item.value === region));
  const timestamp = new Date(scope.startMs + minute * 60_000).toISOString();
  const regionSites = SITES.filter((site) => site.region === region);
  const site = regionSites[minute % Math.max(1, regionSites.length)]?.value ?? 'dub-1';
  const down = minute % 997 === 0;
  const degraded = minute % 97 === 0;
  const status = down ? 'DOWN' : degraded ? 'DEGRADED' : 'ACTIVE';
  const latencyMs = Math.round((12 + regionIndex * 3 + Math.sin(minute / 40) * 6 + (minute % 5)) * 10) / 10;
  const lossPct = status === 'DOWN' ? 2.4 : status === 'DEGRADED' ? 0.6 : 0.02;
  const bytes = 800_000 + regionIndex * 50_000 + (minute % 800) * 1250;
  return {
    id: `${reportId}_${minute}_${region}`,
    timestamp,
    regionCode: region,
    site,
    status,
    latencyMs,
    lossPct,
    bytes,
  };
}

function ledgerRow(reportId: string, scope: LedgerScope, index: number): Row {
  const region = REGIONS[index % REGIONS.length]?.value ?? 'eu-west';
  if (reportId === 'customer_accounts') {
    const status = index % 5 === 0 ? 'INACTIVE' : 'ACTIVE';
    return {
      id: `acct_${index}`,
      name: `Account ${100000 + index}`,
      regionCode: region,
      status,
      mrr: 40 + (index % 220),
    };
  }
  if (reportId === 'billing_lines') {
    const services = ['Wavelength', 'Transit', 'Cross connect', 'Cloud on-ramp'];
    return {
      id: `bill_${scope.cycle}_${index}`,
      cycle: scope.cycle ?? '',
      customer: `Account ${100000 + (index % 5000)}`,
      service: services[index % services.length] ?? 'Transit',
      status: index % 8 === 0 ? 'DISPUTED' : 'POSTED',
      amount: Math.round((120 + (index % 400) + (index % 17)) * 100) / 100,
    };
  }
  const breaks = ['Rate mismatch', 'Missing usage', 'Duplicate charge'];
  return {
    id: `brk_${scope.cycle}_${index}`,
    cycle: scope.cycle ?? '',
    customer: `Account ${100000 + (index % 1800)}`,
    breakType: breaks[index % breaks.length] ?? 'Rate mismatch',
    status: index % 4 === 0 ? 'OPEN' : 'RESOLVED',
    amount: Math.round((25 + (index % 300)) * 100) / 100,
  };
}

function project(row: Row, columns: string[]): Row {
  const projected: Row = {};
  for (const column of columns) {
    if (column in row) projected[column] = row[column] ?? '';
  }
  return projected;
}

function compare(left: string | number, right: string | number, direction: 'asc' | 'desc'): number {
  const sign = direction === 'asc' ? 1 : -1;
  if (typeof left === 'number' && typeof right === 'number') return (left - right) * sign;
  return String(left).localeCompare(String(right)) * sign;
}

function buildSeries(
  scope: TimelineScope,
  filter: FilterTree,
  bucket: Bucket,
  metric: string,
): { t: string; v: number }[] {
  const size = bucket === 'minute' ? 60_000 : bucket === 'hour' ? 3_600_000 : 86_400_000;
  const points: { t: string; v: number }[] = [];
  for (let cursor = scope.startMs; cursor < scope.endMs; cursor += size) {
    const end = Math.min(scope.endMs, cursor + size);
    const partial: TimelineScope = { ...scope, startMs: cursor, endMs: end };
    const stats = scanTimeline(partial, filter);
    points.push({ t: new Date(cursor).toISOString(), v: metricValue(metric, stats) });
  }
  return points;
}

function computeKpis(report: ReportDef, scope: Scope, filter: FilterTree, keys: string[]): Record<string, number> {
  const stats =
    scope.kind === 'timeline'
      ? scanTimeline(scope, filter)
      : scanLedger(report, scope, filter);
  const metrics: Record<string, number> = {};
  for (const key of keys) metrics[key] = metricValue(key, stats);
  return metrics;
}

interface Stats {
  count: number;
  latency: number;
  loss: number;
  bytes: number;
  up: number;
  amount: number;
  open: number;
}

function scanTimeline(scope: TimelineScope, filter: FilterTree): Stats {
  const stats = emptyStats();
  const space = timelineSpace(scope);
  for (let index = 0; index < space; index += 1) {
    const row = timelineRow('scan', scope, index);
    if (!rowMatches(row, filter)) continue;
    absorb(stats, row);
  }
  return stats;
}

function scanLedger(report: ReportDef, scope: LedgerScope, filter: FilterTree): Stats {
  const stats = emptyStats();
  for (let index = 0; index < scope.size; index += 1) {
    if (!matches(report, scope, index, filter)) continue;
    absorb(stats, ledgerRow(report.id, scope, index));
  }
  return stats;
}

function rowMatches(row: Row, filter: FilterTree): boolean {
  for (const condition of filter.conditions) {
    if (condition.field === 'timestamp' || condition.field === 'cycle' || condition.field === 'regionCode') continue;
    const value = String(row[condition.field] ?? '');
    if (condition.op === 'eq' && value !== condition.value) return false;
    if (condition.op === 'contains' && typeof condition.value === 'string' && !value.toLowerCase().includes(condition.value.toLowerCase())) {
      return false;
    }
    if (condition.op === 'in' && Array.isArray(condition.value) && !condition.value.includes(value)) return false;
  }
  return true;
}

function emptyStats(): Stats {
  return { count: 0, latency: 0, loss: 0, bytes: 0, up: 0, amount: 0, open: 0 };
}

function absorb(stats: Stats, row: Row): void {
  stats.count += 1;
  stats.latency += Number(row['latencyMs'] ?? 0);
  stats.loss += Number(row['lossPct'] ?? 0);
  stats.bytes += Number(row['bytes'] ?? 0);
  stats.amount += Number(row['amount'] ?? row['mrr'] ?? 0);
  if (row['status'] === 'ACTIVE' || row['status'] === 'POSTED' || row['status'] === 'RESOLVED') stats.up += 1;
  if (row['status'] === 'OPEN') stats.open += 1;
}

function metricValue(metric: string, stats: Stats): number {
  if (stats.count === 0) return 0;
  switch (metric) {
    case 'avgLatencyMs':
      return round(stats.latency / stats.count);
    case 'avgLossPct':
      return round(stats.loss / stats.count);
    case 'uptimePct':
      return round((stats.up / stats.count) * 100);
    case 'sumBytes':
      return Math.round(stats.bytes);
    case 'sumAmount':
      return round(stats.amount);
    case 'openBreaks':
      return stats.open;
    case 'sampleCount':
    default:
      return stats.count;
  }
}

function round(value: number): number {
  return Math.round(value * 100) / 100;
}

function parseFilter(value: unknown, report: ReportDef): { filter: FilterTree } | { problem: Problem } {
  if (!isRecord(value) || value['op'] !== 'and' || !Array.isArray(value['conditions'])) {
    return { problem: problem(400, 'invalid-body', 'Filters must be an and-tree') };
  }
  if (value['conditions'].length > 50) {
    return { problem: problem(400, 'invalid-body', 'Too many filter conditions') };
  }
  const allowed = new Set(report.fields.map((field) => field.key));
  const conditions: FilterCondition[] = [];
  for (const raw of value['conditions']) {
    if (!isRecord(raw)) return { problem: problem(400, 'invalid-body', 'A filter condition is invalid') };
    const field = raw['field'];
    const op = raw['op'];
    const conditionValue = raw['value'];
    if (typeof field !== 'string' || !allowed.has(field)) {
      return { problem: problem(400, 'invalid-body', 'A filter field is not in the report catalog') };
    }
    if (op !== 'eq' && op !== 'in' && op !== 'gte' && op !== 'lt' && op !== 'contains') {
      return { problem: problem(400, 'invalid-body', 'Unsupported filter operator') };
    }
    if (op === 'in') {
      if (!Array.isArray(conditionValue) || conditionValue.some((item) => typeof item !== 'string')) {
        return { problem: problem(400, 'invalid-body', 'An in-filter expects a list of strings') };
      }
      conditions.push({ field, op, value: conditionValue });
      continue;
    }
    if (typeof conditionValue !== 'string') {
      return { problem: problem(400, 'invalid-body', 'Filter values must be strings') };
    }
    conditions.push({ field, op, value: conditionValue });
  }
  return { filter: { op: 'and', conditions } };
}

function parseSort(value: unknown, report: ReportDef): { sort: { field: string; direction: 'asc' | 'desc' }[] } | { problem: Problem } {
  if (!Array.isArray(value)) return { problem: problem(400, 'invalid-body', 'Sort must be a list') };
  if (value.length > 3) return { problem: problem(400, 'invalid-body', 'Sort at most three fields') };
  const sortable = new Set(report.fields.filter((field) => field.sortable).map((field) => field.key));
  const sort: { field: string; direction: 'asc' | 'desc' }[] = [];
  for (const raw of value) {
    if (!isRecord(raw)) return { problem: problem(400, 'invalid-body', 'A sort field is invalid') };
    const field = raw['field'];
    const direction = raw['direction'];
    if (typeof field !== 'string' || !sortable.has(field)) {
      return { problem: problem(400, 'invalid-body', 'That column cannot be sorted') };
    }
    if (direction !== 'asc' && direction !== 'desc') {
      return { problem: problem(400, 'invalid-body', 'Sort direction must be asc or desc') };
    }
    sort.push({ field, direction });
  }
  return { sort };
}

function readCondition(filter: FilterTree, field: string, op: string): string | string[] | undefined {
  const found = filter.conditions.find((condition) => condition.field === field && condition.op === op);
  return found?.value;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function hasUnknown(value: Record<string, unknown>, allowed: Set<string>): boolean {
  return Object.keys(value).some((key) => !allowed.has(key));
}
