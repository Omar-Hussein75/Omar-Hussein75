import { Injectable, signal } from '@angular/core';
import type { ExportJob, NavNode, Session, ViewDefinition } from '../models/contracts';
import { seedViews } from './catalog';
import type { RatingJob } from './rating-jobs';

export interface FixtureUser {
  id: string;
  displayName: string;
  roleLabel: string;
  permissions: string[];
}

export const FIXTURE_USERS: Record<string, FixtureUser> = {
  amina: {
    id: 'u_amina',
    displayName: 'Amina Shah',
    roleLabel: 'Network analyst',
    permissions: ['network.read', 'reports.read'],
  },
  jordan: {
    id: 'u_jordan',
    displayName: 'Jordan Lee',
    roleLabel: 'Platform admin',
    permissions: ['network.read', 'billing.read', 'reports.read', 'config.manage'],
  },
};

export function seedNodes(): NavNode[] {
  return [
    { id: 'nav_dash', parentId: null, label: 'Dashboard', icon: 'dashboard', order: 10, enabled: true, viewId: 'view_overview' },
    { id: 'nav_customers', parentId: null, label: 'Customer Data', icon: 'users', order: 20, enabled: true, viewId: 'view_customers' },
    { id: 'nav_network', parentId: null, label: 'Network', icon: 'network', order: 30, enabled: true, viewId: null },
    { id: 'nav_perf', parentId: 'nav_network', label: 'Performance', icon: 'activity', order: 10, enabled: true, viewId: 'view_net_perf' },
    { id: 'nav_avail', parentId: 'nav_network', label: 'Availability', icon: 'pulse', order: 20, enabled: true, viewId: 'view_availability' },
    { id: 'nav_traffic', parentId: 'nav_network', label: 'Traffic', icon: 'traffic', order: 30, enabled: true, viewId: 'view_traffic' },
    { id: 'nav_billing', parentId: null, label: 'Billing', icon: 'billing', order: 40, enabled: true, viewId: 'view_billing' },
    { id: 'nav_recon', parentId: null, label: 'Reconciliation', icon: 'reconcile', order: 50, enabled: true, viewId: 'view_recon' },
    { id: 'nav_rating', parentId: null, label: 'Rating Validation', icon: 'rating', order: 55, enabled: true, viewId: null },
    { id: 'nav_rating_admin', parentId: 'nav_rating', label: 'Job Admin', icon: 'rating', order: 10, enabled: true, viewId: 'view_rating_admin' },
    { id: 'nav_rating_summary', parentId: 'nav_rating', label: 'Job Summary', icon: 'reports', order: 20, enabled: true, viewId: 'view_rating_summary' },
    { id: 'nav_reports', parentId: null, label: 'Reports', icon: 'reports', order: 60, enabled: true, viewId: 'view_reports' },
  ];
}

interface Snapshot {
  version: number;
  nodes: NavNode[];
  views: ViewDefinition[];
}

@Injectable({ providedIn: 'root' })
export class ContractStore {
  readonly session = signal<Session | null>(null);
  published: Snapshot;
  draftNodes: NavNode[];
  draftViews: ViewDefinition[];
  history: Snapshot[] = [];
  jobs: ExportJob[] = [];
  ratingRuns: RatingJob[] = [];
  cslUploads: { name: string; bytes: number; at: string }[] = [];
  files = new Map<string, string>();
  idempotency = new Map<string, { hash: string; jobId: string }>();
  private jobTimers = new Map<string, ReturnType<typeof setTimeout>[]>();
  private seq = 40;

  nextId(prefix: string): string {
    this.seq += 1;
    return `${prefix}_${this.seq}`;
  }

  constructor() {
    const views = seedViews();
    this.published = { version: 18, nodes: seedNodes(), views };
    this.draftNodes = clone(seedNodes());
    this.draftViews = clone(views);
  }

  publish(baseVersion: number): { ok: true; version: number } | { ok: false; conflict: true } {
    if (baseVersion !== this.published.version) return { ok: false, conflict: true };
    this.history.push(clone(this.published));
    this.published = {
      version: this.published.version + 1,
      nodes: clone(this.draftNodes),
      views: clone(this.draftViews),
    };
    this.touchSession();
    return { ok: true, version: this.published.version };
  }

  rollback(): number | null {
    const previous = this.history.pop();
    if (!previous) return null;
    this.published = {
      version: this.published.version + 1,
      nodes: clone(previous.nodes),
      views: clone(previous.views),
    };
    this.draftNodes = clone(previous.nodes);
    this.draftViews = clone(previous.views);
    this.touchSession();
    return this.published.version;
  }

  rememberJob(job: ExportJob, csv: string): void {
    this.jobs.unshift(job);
    this.files.set(job.id, csv);
  }

  schedule(jobId: string, runningIn: number, readyIn: number, onRunning: () => void, onReady: () => void): void {
    const timers = [
      setTimeout(onRunning, runningIn),
      setTimeout(onReady, readyIn),
    ];
    this.jobTimers.set(jobId, timers);
  }

  clearJob(jobId: string): void {
    for (const timer of this.jobTimers.get(jobId) ?? []) clearTimeout(timer);
    this.jobTimers.delete(jobId);
  }

  private touchSession(): void {
    const current = this.session();
    if (!current) return;
    this.session.set({ ...current, configVersion: this.published.version });
  }
}

function clone<T>(value: T): T {
  return structuredClone(value);
}
