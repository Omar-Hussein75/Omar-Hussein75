import type { Problem } from '../models/contracts';
import { decodeCursor, encodeCursor, problem, validateWindow } from '../query/query-rules';

export const RATING_PAGE_DEFAULT = 15;
export const RATING_PAGE_MAX = 100;
export const CSL_SAMPLE_CAP = 8;

export interface RatingJob {
  id: number;
  streamName: 'IN' | 'BSCS';
  startTime: string;
  endTime: string;
  jobStatus: number;
  statusDescr: string;
  decoded: number;
  filtered: number;
  rated: number;
  erroredRate: number;
}

export interface CslLine {
  msisdn: string;
  scope?: number;
  billCycle?: string;
}

export interface RatingGauges {
  overallMatched: number;
  overallValueAccuracy: number;
  overallMatchedAccuracy: number;
  selectionMatched: number;
  selectionValueAccuracy: number;
  selectionMatchedAccuracy: number;
}

export interface RatingJobDetail extends RatingJob {
  durationSec: number;
  ratedOfDecoded: number;
  errorOfRated: number;
  billCycle: string;
  jobName: string;
  comparisonLabel: string;
  comparisonDay: string;
  gauges: RatingGauges;
  inCsl: { msisdn: string; scope: number }[];
  bscsCsl: { msisdn: string; billCycle: string }[];
}

export const AGG_TABLES = [
  { id: 'job', title: 'By Job', textLabel: 'Job' },
  { id: 'rate-plan', title: 'By Rate Plan', textLabel: 'Rate plan' },
  { id: 'sub-plan', title: 'Drill by Sub Plan', textLabel: 'Sub plan' },
  { id: 'call-type', title: 'Drill by Call Type', textLabel: 'Call type' },
  { id: 'subscriber', title: 'By Subscriber Type', textLabel: 'Subscriber type' },
] as const;

export type AggTableId = (typeof AGG_TABLES)[number]['id'];

export interface AggRow {
  id: string;
  label: string;
  origin?: string;
  original: number;
  valueDifference: number;
  mismatched?: number;
  matched?: number;
}

export interface AggPage {
  table: AggTableId;
  rows: AggRow[];
  page: { limit: number; nextCursor: string | null; prevCursor: string | null; hasMore: boolean };
  total: number;
  meta: { queryMs: number; lastUpdate: string | null };
}

export interface DifferenceRow {
  table: string;
  label: string;
  valueDifference: number;
}

export const AGG_PAGE_DEFAULT = 12;
export const AGG_PAGE_MAX = 50;

export interface RatingQuery {
  start: string;
  end: string;
  stream: string;
  jobStatus: string;
  statusDescr: string;
  limit: number;
  cursor: string | null;
}

export interface RatingPage {
  rows: RatingJob[];
  page: { limit: number; nextCursor: string | null; prevCursor: string | null; hasMore: boolean };
  total: number;
  meta: { queryMs: number; lastUpdate: string | null };
}

export interface RatingSummary {
  jobs: number;
  decoded: number;
  filtered: number;
  rated: number;
  errored: number;
  lastUpdate: string | null;
}

const STATUS: Record<number, string> = {
  1: 'Queued',
  2: 'Running',
  3: 'Processed',
  4: 'Failed',
};

export function statusLabel(code: number): string {
  return STATUS[code] ?? 'Unknown';
}

export function generatedRatingJobs(): RatingJob[] {
  const jobs: RatingJob[] = [
    {
      id: 5329,
      streamName: 'IN',
      startTime: '2026-09-23T09:06:05.000Z',
      endTime: '2026-09-23T09:23:51.000Z',
      jobStatus: 3,
      statusDescr: 'Processed',
      decoded: 382496,
      filtered: 198384,
      rated: 197998,
      erroredRate: 22,
    },
  ];
  for (let index = 1; index < 44; index += 1) {
    const id = 5329 - index;
    const day = Math.max(1, 23 - Math.floor(index / 2));
    const evening = index % 2 === 0;
    const startHour = evening ? 23 : 9;
    const startMinute = (index * 7) % 50;
    const streamName: 'IN' | 'BSCS' = index % 6 === 0 ? 'BSCS' : 'IN';
    const failed = index % 13 === 0;
    const decoded = 140000 + ((index * 7919) % 1400000);
    const filtered = Math.round(decoded * (0.45 + (index % 5) * 0.08));
    const erroredRate = failed ? 800 + (index % 40) : 4 + (index % 260);
    const rated = Math.max(0, filtered - erroredRate);
    const start = new Date(Date.UTC(2026, 8, day, startHour, startMinute, (index * 3) % 60));
    const end = new Date(start.getTime() + (12 + (index % 20)) * 60_000);
    jobs.push({
      id,
      streamName,
      startTime: start.toISOString(),
      endTime: end.toISOString(),
      jobStatus: failed ? 4 : 3,
      statusDescr: failed ? 'Failed' : 'Processed',
      decoded,
      filtered,
      rated,
      erroredRate,
    });
  }
  return jobs;
}

export function listRatingJobs(extra: RatingJob[] = []): RatingJob[] {
  const byId = new Map<number, RatingJob>();
  for (const job of generatedRatingJobs()) byId.set(job.id, job);
  for (const job of extra) byId.set(job.id, job);
  return [...byId.values()].sort((left, right) => right.id - left.id);
}

export function queryRatingJobs(extra: RatingJob[], raw: unknown): { ok: true; body: RatingPage } | { ok: false; problem: Problem } {
  const parsed = parseQuery(raw);
  if ('problem' in parsed) return { ok: false, problem: parsed.problem };
  const started = performance.now();
  const matched = listRatingJobs(extra).filter((job) => matches(job, parsed.query));
  const offset = parsed.offset;
  const limit = parsed.query.limit;
  const rows = matched.slice(offset, offset + limit);
  const hasMore = offset + limit < matched.length;
  const last = matched[0];
  return {
    ok: true,
    body: {
      rows,
      page: {
        limit,
        nextCursor: hasMore ? encodeCursor(offset + limit) : null,
        prevCursor: offset > 0 ? encodeCursor(Math.max(0, offset - limit)) : null,
        hasMore,
      },
      total: matched.length,
      meta: {
        queryMs: Math.max(1, Math.round(performance.now() - started)),
        lastUpdate: last ? last.endTime : null,
      },
    },
  };
}

export function summarizeRatingJobs(extra: RatingJob[], raw: unknown): { ok: true; body: RatingSummary } | { ok: false; problem: Problem } {
  const parsed = parseQuery({ ...(isRecord(raw) ? raw : {}), limit: 1, cursor: null });
  if ('problem' in parsed) return { ok: false, problem: parsed.problem };
  const matched = listRatingJobs(extra).filter((job) => matches(job, parsed.query));
  return {
    ok: true,
    body: {
      jobs: matched.length,
      decoded: matched.reduce((sum, job) => sum + job.decoded, 0),
      filtered: matched.reduce((sum, job) => sum + job.filtered, 0),
      rated: matched.reduce((sum, job) => sum + job.rated, 0),
      errored: matched.reduce((sum, job) => sum + job.erroredRate, 0),
      lastUpdate: matched[0]?.endTime ?? null,
    },
  };
}

export function detailFor(job: RatingJob): RatingJobDetail {
  const durationSec = Math.max(0, Math.round((Date.parse(job.endTime) - Date.parse(job.startTime)) / 1000));
  const inCsl =
    job.id === 5329
      ? [
          { msisdn: '2010016150804', scope: 0 },
          { msisdn: '201001740808', scope: 0 },
          { msisdn: '201001740809', scope: 0 },
        ]
      : Array.from({ length: 4 }, (_, index) => ({
          msisdn: String(2010016150804 + (job.id % 1000) * 3 + index),
          scope: index === 0 ? 0 : index,
        }));
  const bscsCsl =
    job.id === 5329
      ? [
          { msisdn: '201000050023', billCycle: 'BC02' },
          { msisdn: '201000050080', billCycle: 'BC02' },
          { msisdn: '201000050250', billCycle: 'BC02' },
        ]
      : Array.from({ length: 4 }, (_, index) => ({
          msisdn: String(201000050023 + index * 57),
          billCycle: 'BC02',
        }));
  return {
    ...job,
    durationSec,
    ratedOfDecoded: job.decoded === 0 ? 0 : Math.round((job.rated / job.decoded) * 1000) / 10,
    errorOfRated: job.rated === 0 ? 0 : Math.round((job.erroredRate / job.rated) * 1000) / 10,
    billCycle: 'BC02',
    jobName: job.id === 5329 ? 'HU' : ['HU', 'IN', 'RV', 'NX', 'BC'][job.id % 5] ?? 'HU',
    comparisonLabel: `${job.streamName} Job on Start time of Day`,
    comparisonDay: job.id === 5329 ? '2026-09-21' : shiftDate(job.startTime, -2),
    gauges: gaugesFor(job),
    inCsl: inCsl.slice(0, CSL_SAMPLE_CAP),
    bscsCsl: bscsCsl.slice(0, CSL_SAMPLE_CAP),
  };
}

export function queryAggregates(job: RatingJob, raw: unknown): { ok: true; body: AggPage } | { ok: false; problem: Problem } {
  if (!isRecord(raw) || typeof raw['table'] !== 'string' || !isAggTable(raw['table'])) {
    return { ok: false, problem: problem(400, 'invalid-body', 'Choose one of the rating aggregate tables') };
  }
  const text = typeof raw['text'] === 'string' ? raw['text'] : '';
  if (text.length > 80) return { ok: false, problem: problem(400, 'invalid-body', 'The filter text is too long') };
  let minDifference: number | null = null;
  if (raw['minDifference'] != null) {
    if (typeof raw['minDifference'] !== 'number' || !Number.isFinite(raw['minDifference'])) {
      return { ok: false, problem: problem(400, 'invalid-body', 'Minimum value difference must be a number') };
    }
    minDifference = raw['minDifference'];
  }
  const limitValue = raw['limit'] === undefined ? AGG_PAGE_DEFAULT : raw['limit'];
  if (typeof limitValue !== 'number' || !Number.isInteger(limitValue) || limitValue < 1 || limitValue > AGG_PAGE_MAX) {
    return { ok: false, problem: problem(400, 'invalid-body', 'Page limit must be between 1 and 50') };
  }
  let offset = 0;
  if (raw['cursor'] != null) {
    if (typeof raw['cursor'] !== 'string') return { ok: false, problem: problem(400, 'invalid-body', 'The cursor is invalid') };
    const decoded = decodeCursor(raw['cursor']);
    if (decoded === null) return { ok: false, problem: problem(400, 'invalid-body', 'The cursor signature is invalid') };
    offset = decoded;
  }
  const started = performance.now();
  const matched = rowsFor(job, raw['table']).filter((row) => aggregateMatches(row, text, minDifference));
  const rows = matched.slice(offset, offset + limitValue);
  const hasMore = offset + limitValue < matched.length;
  return {
    ok: true,
    body: {
      table: raw['table'],
      rows,
      page: {
        limit: limitValue,
        nextCursor: hasMore ? encodeCursor(offset + limitValue) : null,
        prevCursor: offset > 0 ? encodeCursor(Math.max(0, offset - limitValue)) : null,
        hasMore,
      },
      total: matched.length,
      meta: {
        queryMs: Math.max(1, Math.round(performance.now() - started)),
        lastUpdate: job.endTime,
      },
    },
  };
}

export function topDifferences(job: RatingJob, limit = 8): DifferenceRow[] {
  const bounded = Math.min(20, Math.max(1, limit));
  const rows: DifferenceRow[] = [
    ...rowsFor(job, 'rate-plan').map((row) => ({ table: 'By Rate Plan', label: row.label, valueDifference: row.valueDifference })),
    ...rowsFor(job, 'sub-plan').map((row) => ({ table: 'Drill by Sub Plan', label: row.label, valueDifference: row.valueDifference })),
    ...rowsFor(job, 'call-type').map((row) => ({ table: 'Drill by Call Type', label: row.label, valueDifference: row.valueDifference })),
  ];
  return rows.sort((left, right) => right.valueDifference - left.valueDifference).slice(0, bounded);
}

export function countsForNewRun(id: number): Pick<RatingJob, 'decoded' | 'filtered' | 'rated' | 'erroredRate'> {
  const decoded = 120000 + (id % 80) * 1500;
  const filtered = Math.round(decoded * 0.52);
  const erroredRate = 8 + (id % 30);
  return { decoded, filtered, rated: filtered - erroredRate, erroredRate };
}

const RATE_PLANS: { label: string; original: number; valueDifference: number }[] = [
  { label: 'Business RED Control 750 2025', original: 48000, valueDifference: 2100 },
  { label: 'Enterprise Flex_150_2025', original: 32000, valueDifference: 980 },
  { label: 'Business RED Control 360 2025', original: 24000, valueDifference: 720 },
  { label: 'Red 150 Control', original: 20000, valueDifference: 540 },
  { label: 'Flex_345_2024', original: 18000, valueDifference: 410 },
  { label: 'Business red 1000 2020', original: 15000, valueDifference: 330 },
  { label: 'RED Essential 2024', original: 14000, valueDifference: 260 },
  { label: 'Flex_115_2024', original: 12000, valueDifference: 210 },
  { label: 'Business RED Control 1500 2025', original: 10000, valueDifference: 160 },
  { label: 'Enterprise Business Flex 45_2020', original: 8000, valueDifference: 120 },
  { label: 'Flex_175_2024', original: 5997.97, valueDifference: 90 },
  { label: 'Flex_52_2024', original: 3000, valueDifference: 61.05 },
];

const SUB_PLANS: { label: string; original: number; valueDifference: number }[] = [
  { label: 'LOCAL GPRS', original: 184823.17, valueDifference: 4102.55 },
  { label: 'Voice', original: 19777.03, valueDifference: 612.4 },
  { label: 'Internal Voice', original: 1578, valueDifference: 88.1 },
  { label: 'CONTENT', original: 1026.36, valueDifference: 41.2 },
  { label: 'IVR Voice', original: 54.32, valueDifference: 2.15 },
  { label: 'Roaming Incoming', original: 400, valueDifference: 36 },
  { label: 'SMS', original: 155.38, valueDifference: 9.4 },
  { label: 'USSD', original: 1.71, valueDifference: 0.05 },
  { label: 'Account Adjustment', original: 0, valueDifference: 0 },
  { label: 'IVR SMS', original: 0, valueDifference: 0 },
  { label: 'Roaming GPRS', original: 1470, valueDifference: 318.2 },
  { label: 'Roaming Outgoing', original: 712, valueDifference: 771 },
];

const CALL_TYPES: { label: string; original: number; valueDifference: number }[] = [
  { label: 'Roaming Zone 1', original: 8420.5, valueDifference: 56 },
  { label: 'IVR SMS 0', original: 120, valueDifference: 0 },
  { label: 'Roaming Zone 2', original: 15110.25, valueDifference: 352 },
  { label: 'Roaming Zone 3', original: 6404, valueDifference: 64 },
  { label: 'acc_adj_add', original: 80, valueDifference: 0 },
  { label: 'Roaming Zone 4', original: 9100.4, valueDifference: 192 },
  { label: 'Roaming Zone 5', original: 11280, valueDifference: 280 },
  { label: 'International Zone', original: 22150.75, valueDifference: 963 },
  { label: 'Roaming Zone 6', original: 4300, valueDifference: 48 },
  { label: 'Roaming GPRS National', original: 18640, valueDifference: 670 },
  { label: 'Roaming GPRS International', original: 20480.6, valueDifference: 800 },
  { label: 'acc_adj_reset', original: 40, valueDifference: 0 },
];

function gaugesFor(job: RatingJob): RatingGauges {
  if (job.id === 5329) {
    return {
      overallMatched: 93.13,
      overallValueAccuracy: 97.15,
      overallMatchedAccuracy: 91.75,
      selectionMatched: 93.13,
      selectionValueAccuracy: 97.15,
      selectionMatchedAccuracy: 91.75,
    };
  }
  const base = job.decoded === 0 ? 0 : Math.round((job.rated / job.decoded) * 1000) / 10;
  const wobble = (job.id % 7) * 0.35;
  const clamp = (value: number) => Math.max(0, Math.min(100, Math.round(value * 100) / 100));
  return {
    overallMatched: clamp(base),
    overallValueAccuracy: clamp(base + 3.2 - wobble),
    overallMatchedAccuracy: clamp(base - 1.4),
    selectionMatched: clamp(base - 0.8),
    selectionValueAccuracy: clamp(base + 2.1),
    selectionMatchedAccuracy: clamp(base - 2.2 + wobble),
  };
}

function rowsFor(job: RatingJob, table: AggTableId): AggRow[] {
  if (table === 'job') {
    return [
      {
        id: `job-${job.id}`,
        label: String(job.id),
        original: scaleAmount(job, 209997.97),
        valueDifference: scaleAmount(job, 5981.05),
        mismatched: scaleCount(job, 13594),
        matched: scaleCount(job, 184404),
      },
    ];
  }
  if (table === 'subscriber') {
    return [
      {
        id: `sub-${job.id}`,
        label: 'All',
        original: scaleAmount(job, 209997.97),
        valueDifference: job.id === 5329 ? 5981.0464 : scaleAmount(job, 5981.0464),
        mismatched: scaleCount(job, 13594),
        matched: scaleCount(job, 184404),
      },
    ];
  }
  const source = table === 'rate-plan' ? RATE_PLANS : table === 'sub-plan' ? SUB_PLANS : CALL_TYPES;
  return source.map((row, index) => ({
    id: `${table}-${index}`,
    label: row.label,
    origin: table === 'rate-plan' ? job.streamName : undefined,
    original: scaleAmount(job, row.original),
    valueDifference: scaleAmount(job, row.valueDifference),
  }));
}

function scaleAmount(job: RatingJob, amount: number): number {
  if (job.id === 5329) return amount;
  if (job.decoded === 0) return 0;
  return Math.round(amount * (job.decoded / 382496) * 100) / 100;
}

function scaleCount(job: RatingJob, amount: number): number {
  if (job.id === 5329) return amount;
  if (job.decoded === 0) return 0;
  return Math.round(amount * (job.decoded / 382496));
}

function aggregateMatches(row: AggRow, text: string, minDifference: number | null): boolean {
  const needle = text.trim().toLowerCase();
  if (needle) {
    const haystack = `${row.label} ${row.origin ?? ''}`.toLowerCase();
    if (!haystack.includes(needle)) return false;
  }
  if (minDifference !== null && row.valueDifference < minDifference) return false;
  return true;
}

function isAggTable(value: string): value is AggTableId {
  return AGG_TABLES.some((table) => table.id === value);
}

function shiftDate(iso: string, days: number): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso.slice(0, 10);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

function parseQuery(raw: unknown): { query: RatingQuery; offset: number } | { problem: Problem } {
  if (!isRecord(raw)) return { problem: problem(400, 'invalid-body', 'The rating query is invalid') };
  const start = typeof raw['start'] === 'string' ? raw['start'] : '';
  const end = typeof raw['end'] === 'string' ? raw['end'] : '';
  const startIso = dateStart(start);
  const endIso = dateEnd(end);
  if (!startIso || !endIso) {
    return { problem: problem(422, 'validation', 'Choose a start and end date') };
  }
  const windowProblem = validateWindow(startIso, endIso, 31);
  if (windowProblem) return { problem: windowProblem };
  const limitValue = raw['limit'] === undefined ? RATING_PAGE_DEFAULT : raw['limit'];
  if (typeof limitValue !== 'number' || !Number.isInteger(limitValue) || limitValue < 1 || limitValue > RATING_PAGE_MAX) {
    return { problem: problem(400, 'invalid-body', 'Page limit must be between 1 and 100') };
  }
  let offset = 0;
  if (raw['cursor'] != null) {
    if (typeof raw['cursor'] !== 'string') return { problem: problem(400, 'invalid-body', 'The cursor is invalid') };
    const decoded = decodeCursor(raw['cursor']);
    if (decoded === null) return { problem: problem(400, 'invalid-body', 'The cursor signature is invalid') };
    offset = decoded;
  }
  const stream = typeof raw['stream'] === 'string' ? raw['stream'] : '';
  if (stream && stream !== 'IN' && stream !== 'BSCS') {
    return { problem: problem(400, 'invalid-body', 'Stream must be IN or BSCS') };
  }
  return {
    offset,
    query: {
      start: startIso,
      end: endIso,
      stream,
      jobStatus: typeof raw['jobStatus'] === 'string' ? raw['jobStatus'] : '',
      statusDescr: typeof raw['statusDescr'] === 'string' ? raw['statusDescr'] : '',
      limit: limitValue,
      cursor: typeof raw['cursor'] === 'string' ? raw['cursor'] : null,
    },
  };
}

function matches(job: RatingJob, query: RatingQuery): boolean {
  const when = Date.parse(job.startTime);
  if (when < Date.parse(query.start) || when >= Date.parse(query.end)) return false;
  if (query.stream && job.streamName !== query.stream) return false;
  if (query.jobStatus && String(job.jobStatus) !== query.jobStatus) return false;
  if (query.statusDescr && !job.statusDescr.toLowerCase().includes(query.statusDescr.trim().toLowerCase())) return false;
  return true;
}

function dateStart(value: string): string | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  return `${value}T00:00:00.000Z`;
}

function dateEnd(value: string): string | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const end = new Date(`${value}T00:00:00.000Z`);
  end.setUTCDate(end.getUTCDate() + 1);
  return end.toISOString();
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
