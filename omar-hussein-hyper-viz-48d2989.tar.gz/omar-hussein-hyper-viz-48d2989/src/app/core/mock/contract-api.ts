import { HttpErrorResponse, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import type {
  ExportJob,
  IconKey,
  NavNode,
  Problem,
  ViewDefinition,
  ViewKind,
} from '../models/contracts';
import { ICON_KEYS, VIEW_KINDS } from '../models/contracts';
import { DEMO_EXPORT_ROW_CAP, problem } from '../query/query-rules';
import { CYCLES, ICON_ALLOWLIST, PERMISSIONS, REGIONS, SITES, reportById, reportSummaries, synthesizeView } from './catalog';
import { ContractStore, FIXTURE_USERS } from './contract-store';
import { runAggregate, runQuery } from './virtual-query';
import {
  countsForNewRun,
  detailFor,
  listRatingJobs,
  queryAggregates,
  queryRatingJobs,
  statusLabel,
  summarizeRatingJobs,
  topDifferences,
  type RatingJob,
} from './rating-jobs';

@Injectable({ providedIn: 'root' })
export class ContractApi {
  private readonly store = inject(ContractStore);

  delayFor(req: HttpRequest<unknown>): number {
    if (req.url.includes('/rating/')) return 280;
    if (req.url.includes('/query') || req.url.includes('/aggregate')) return 650;
    if (req.url.includes('/exports') && req.method === 'POST') return 250;
    return 90;
  }

  dispatch(req: HttpRequest<unknown>): HttpResponse<unknown> | HttpErrorResponse {
    const url = new URL(req.url, 'http://hyperviz.local');
    const path = url.pathname;
    if (req.method !== 'GET' && req.headers.get('X-CSRF-Token') !== 'hyperviz') {
      return fail(problem(403, 'forbidden', 'Missing CSRF token'));
    }

    if (path === '/api/session' && req.method === 'GET') return this.session();
    if (path === '/api/session/login' && req.method === 'POST') return this.login(req.body);
    if (path === '/api/session/logout' && req.method === 'POST') return this.logout();
    if (path === '/api/navigation' && req.method === 'GET') return this.navigation();

    const viewMatch = /^\/api\/views\/([^/]+)$/.exec(path);
    if (viewMatch && req.method === 'GET') return this.view(decodeURIComponent(viewMatch[1] ?? ''));

    const referenceMatch = /^\/api\/references\/([^/]+)$/.exec(path);
    if (referenceMatch && req.method === 'GET') {
      return this.references(decodeURIComponent(referenceMatch[1] ?? ''), url.searchParams.get('q') ?? '', url.searchParams.get('limit'));
    }

    const queryMatch = /^\/api\/reports\/([^/]+)\/query$/.exec(path);
    if (queryMatch && req.method === 'POST') return this.query(decodeURIComponent(queryMatch[1] ?? ''), req.body);

    const aggregateMatch = /^\/api\/reports\/([^/]+)\/aggregate$/.exec(path);
    if (aggregateMatch && req.method === 'POST') return this.aggregate(decodeURIComponent(aggregateMatch[1] ?? ''), req.body);

    if (path === '/api/exports' && req.method === 'POST') return this.createExport(req);
    if (path === '/api/exports' && req.method === 'GET') return this.listExports();

    const exportMatch = /^\/api\/exports\/([^/]+)(?:\/(cancel|download))?$/.exec(path);
    if (exportMatch) {
      const jobId = decodeURIComponent(exportMatch[1] ?? '');
      const action = exportMatch[2];
      if (!action && req.method === 'GET') return this.exportStatus(jobId);
      if (action === 'cancel' && req.method === 'POST') return this.cancelExport(jobId);
      if (action === 'download' && req.method === 'GET') return this.downloadExport(jobId);
    }

    if (path === '/api/rating/jobs/query' && req.method === 'POST') return this.ratingQuery(req.body);
    if (path === '/api/rating/jobs/summary' && req.method === 'POST') return this.ratingSummary(req.body);
    if (path === '/api/rating/jobs/run' && req.method === 'POST') return this.ratingRun(req.body);
    if (path === '/api/rating/csl' && req.method === 'POST') return this.ratingCsl(req.body);
    const ratingAggregate = /^\/api\/rating\/jobs\/(\d+)\/aggregate$/.exec(path);
    if (ratingAggregate && req.method === 'POST') return this.ratingAggregate(Number(ratingAggregate[1]), req.body);
    const ratingDifferences = /^\/api\/rating\/jobs\/(\d+)\/differences$/.exec(path);
    if (ratingDifferences && req.method === 'POST') return this.ratingDifferences(Number(ratingDifferences[1]), req.body);
    const ratingJob = /^\/api\/rating\/jobs\/(\d+)$/.exec(path);
    if (ratingJob && req.method === 'GET') return this.ratingDetail(Number(ratingJob[1]));

    if (path.startsWith('/api/admin')) return this.admin(req, path);
    return fail(problem(404, 'not-found', 'Unknown API route'));
  }

  private session(): HttpResponse<unknown> | HttpErrorResponse {
    const session = this.store.session();
    if (!session) return fail(problem(401, 'unauthenticated', 'Sign in to continue'));
    return ok(session);
  }

  private login(body: unknown): HttpResponse<unknown> | HttpErrorResponse {
    if (!isRecord(body) || typeof body['userId'] !== 'string') {
      return fail(problem(400, 'invalid-body', 'Choose a fixture session'));
    }
    const user = FIXTURE_USERS[body['userId']];
    if (!user) return fail(problem(400, 'invalid-body', 'Unknown fixture session'));
    const session = {
      user: { id: user.id, displayName: user.displayName, roleLabel: user.roleLabel },
      permissions: [...user.permissions],
      configVersion: this.store.published.version,
    };
    this.store.session.set(session);
    return ok(session);
  }

  private logout(): HttpResponse<unknown> {
    this.store.session.set(null);
    return ok({ ok: true });
  }

  private navigation(): HttpResponse<unknown> | HttpErrorResponse {
    const session = this.store.session();
    if (!session) return fail(problem(401, 'unauthenticated', 'Sign in to continue'));
    return ok({
      version: this.store.published.version,
      nodes: visibleNodes(this.store.published.nodes, this.store.published.views, session.permissions),
    });
  }

  private view(id: string): HttpResponse<unknown> | HttpErrorResponse {
    const session = this.requireSession();
    if (session instanceof HttpErrorResponse) return session;
    const definition = this.store.published.views.find((view) => view.id === id);
    if (!definition) return fail(problem(404, 'not-found', 'This view is not available'));
    if (!session.permissions.includes(definition.requiredPermission)) {
      return fail(problem(403, 'forbidden', 'You do not have access to this view'));
    }
    return ok(definition);
  }

  private references(name: string, q: string, limitRaw: string | null): HttpResponse<unknown> | HttpErrorResponse {
    const session = this.requireSession();
    if (session instanceof HttpErrorResponse) return session;
    const limit = Math.min(100, Math.max(1, Number(limitRaw ?? 50) || 50));
    const needle = q.trim().toLowerCase();
    let items: { value: string; label: string }[] = [];
    if (name === 'regions') items = REGIONS.map((region) => ({ ...region }));
    else if (name === 'sites') items = SITES.map((site) => ({ value: site.value, label: `${site.label}` }));
    else if (name === 'cycles') items = CYCLES.map((cycle) => ({ ...cycle }));
    else return fail(problem(404, 'not-found', 'Unknown reference list'));
    const filtered = needle ? items.filter((item) => item.label.toLowerCase().includes(needle) || item.value.includes(needle)) : items;
    return ok({ items: filtered.slice(0, limit), page: { nextCursor: null, hasMore: filtered.length > limit } });
  }

  private query(reportId: string, body: unknown): HttpResponse<unknown> | HttpErrorResponse {
    const allowed = this.authorizeReport(reportId);
    if (allowed instanceof HttpErrorResponse) return allowed;
    if (reportId === 'rating_validation_jobs') {
      return fail(problem(400, 'invalid-body', 'Rating jobs are listed through /api/rating/jobs/query'));
    }
    const result = runQuery(reportId, body);
    return result.ok ? ok(result.body) : fail(result.problem);
  }

  private aggregate(reportId: string, body: unknown): HttpResponse<unknown> | HttpErrorResponse {
    const allowed = this.authorizeReport(reportId);
    if (allowed instanceof HttpErrorResponse) return allowed;
    const result = runAggregate(reportId, body);
    return result.ok ? ok(result.body) : fail(result.problem);
  }

  private createExport(req: HttpRequest<unknown>): HttpResponse<unknown> | HttpErrorResponse {
    const session = this.requireSession();
    if (session instanceof HttpErrorResponse) return session;
    const body = req.body;
    if (!isRecord(body)) return fail(problem(400, 'invalid-body', 'Export body is invalid'));
    const reportId = body['reportId'];
    if (typeof reportId !== 'string') return fail(problem(400, 'invalid-body', 'reportId is required'));
    const allowed = this.authorizeReport(reportId);
    if (allowed instanceof HttpErrorResponse) return allowed;
    const key = req.headers.get('Idempotency-Key');
    const hash = JSON.stringify(body);
    if (key) {
      const prior = this.store.idempotency.get(key);
      if (prior) {
        if (prior.hash !== hash) return fail(problem(409, 'conflict', 'This idempotency key was used for a different export'));
        const existing = this.store.jobs.find((job) => job.id === prior.jobId);
        if (existing) return ok(existing, 202);
      }
    }
    const columns = Array.isArray(body['columns']) ? body['columns'] : [];
    const preview = runQuery(reportId, {
      filter: body['filter'],
      sort: [{ field: 'id', direction: 'asc' }],
      page: { limit: DEMO_EXPORT_ROW_CAP, cursor: null, includeTotal: true },
      columns,
    });
    if (!preview.ok) return fail(preview.problem);
    const total = preview.body.total ?? preview.body.rows.length;
    const truncated = total > preview.body.rows.length;
    const csv = toCsv(preview.body.meta.columns, preview.body.rows);
    const jobId = this.store.nextId('job');
    const job: ExportJob = {
      id: jobId,
      status: 'queued',
      reportId,
      format: 'csv',
      bytes: null,
      rowCount: null,
      truncated,
      detail: truncated
        ? `Matched ${total.toLocaleString('en-US')} rows. This demo worker writes at most ${DEMO_EXPORT_ROW_CAP}.`
        : null,
      createdAt: new Date().toISOString(),
      finishedAt: null,
      expiresAt: null,
      ownerId: session.user.id,
    };
    this.store.rememberJob(job, csv);
    if (key) this.store.idempotency.set(key, { hash, jobId });
    this.store.schedule(
      jobId,
      600,
      1600,
      () => this.patchJob(jobId, { status: 'running' }),
      () =>
        this.patchJob(jobId, {
          status: 'ready',
          bytes: csv.length,
          rowCount: preview.body.rows.length,
          finishedAt: new Date().toISOString(),
          expiresAt: new Date(Date.now() + 86_400_000).toISOString(),
        }),
    );
    return ok(job, 202);
  }

  private listExports(): HttpResponse<unknown> | HttpErrorResponse {
    const session = this.requireSession();
    if (session instanceof HttpErrorResponse) return session;
    return ok({ jobs: this.store.jobs.filter((job) => job.ownerId === session.user.id) });
  }

  private exportStatus(jobId: string): HttpResponse<unknown> | HttpErrorResponse {
    const job = this.ownedJob(jobId);
    if (job instanceof HttpErrorResponse) return job;
    return ok(job);
  }

  private cancelExport(jobId: string): HttpResponse<unknown> | HttpErrorResponse {
    const job = this.ownedJob(jobId);
    if (job instanceof HttpErrorResponse) return job;
    if (job.status === 'ready' || job.status === 'failed' || job.status === 'cancelled') return ok(job);
    this.store.clearJob(jobId);
    this.patchJob(jobId, { status: 'cancelled', finishedAt: new Date().toISOString() });
    return ok(this.store.jobs.find((item) => item.id === jobId) ?? job);
  }

  private downloadExport(jobId: string): HttpResponse<unknown> | HttpErrorResponse {
    const job = this.ownedJob(jobId);
    if (job instanceof HttpErrorResponse) return job;
    if (job.status !== 'ready') return fail(problem(409, 'conflict', 'The export is not ready'));
    const csv = this.store.files.get(jobId);
    if (!csv) return fail(problem(404, 'not-found', 'The export file is no longer available'));
    return new HttpResponse({
      status: 200,
      body: csv,
      headers: undefined,
    });
  }

  private admin(req: HttpRequest<unknown>, path: string): HttpResponse<unknown> | HttpErrorResponse {
    const session = this.requireSession();
    if (session instanceof HttpErrorResponse) return session;
    if (!session.permissions.includes('config.manage')) {
      return fail(problem(403, 'forbidden', 'Admin configuration requires config.manage'));
    }
    if (path === '/api/admin/catalog' && req.method === 'GET') {
      return ok({
        permissions: [...PERMISSIONS],
        icons: [...ICON_ALLOWLIST],
        kinds: [...VIEW_KINDS],
        reports: reportSummaries(),
      });
    }
    if (path === '/api/admin/draft' && req.method === 'GET') {
      return ok({ version: this.store.published.version, nodes: this.store.draftNodes });
    }
    if (path === '/api/admin/nodes' && req.method === 'POST') return this.addNode(req.body);
    const nodeMatch = /^\/api\/admin\/nodes\/([^/]+)(?:\/(move))?$/.exec(path);
    if (nodeMatch && req.method === 'PATCH') return this.patchNode(decodeURIComponent(nodeMatch[1] ?? ''), req.body);
    if (nodeMatch?.[2] === 'move' && req.method === 'POST') {
      return this.moveNode(decodeURIComponent(nodeMatch[1] ?? ''), req.body);
    }
    if (path === '/api/admin/publications' && req.method === 'POST') {
      if (!isRecord(req.body) || typeof req.body['baseVersion'] !== 'number') {
        return fail(problem(400, 'invalid-body', 'baseVersion is required'));
      }
      const result = this.store.publish(req.body['baseVersion']);
      if (!result.ok) return fail(problem(409, 'conflict', 'The published configuration changed. Reload and try again.'));
      return ok({ version: result.version });
    }
    if (path === '/api/admin/rollback' && req.method === 'POST') {
      const version = this.store.rollback();
      if (version === null) return fail(problem(409, 'conflict', 'There is no earlier publication to restore'));
      return ok({ version });
    }
    return fail(problem(404, 'not-found', 'Unknown admin route'));
  }

  private addNode(body: unknown): HttpResponse<unknown> | HttpErrorResponse {
    if (!isRecord(body) || typeof body['label'] !== 'string') {
      return fail(problem(400, 'invalid-body', 'A label is required'));
    }
    const label = cleanLabel(body['label']);
    if (!label) return fail(problem(422, 'validation', 'Enter a plain-text label'));
    const parentId = body['parentId'] == null ? null : body['parentId'];
    if (parentId !== null && (typeof parentId !== 'string' || !this.store.draftNodes.some((node) => node.id === parentId))) {
      return fail(problem(422, 'validation', 'Choose a parent folder that exists'));
    }
    const icon = body['icon'];
    if (!isIcon(icon)) return fail(problem(422, 'validation', 'Choose an icon from the registry'));
    const folder = body['folder'] === true;
    let viewId: string | null = null;
    if (!folder) {
      const kind = body['kind'];
      const reportId = body['reportId'];
      const permission = body['requiredPermission'];
      if (!isKind(kind) || typeof reportId !== 'string' || typeof permission !== 'string') {
        return fail(problem(422, 'validation', 'A leaf needs a view kind, catalog report, and permission'));
      }
      if (!reportById(reportId)) return fail(problem(422, 'validation', 'That report is not in the catalog'));
      if (!PERMISSIONS.includes(permission as (typeof PERMISSIONS)[number])) {
        return fail(problem(422, 'validation', 'Choose a permission from the catalog'));
      }
      viewId = this.store.nextId('view');
      const view = synthesizeView({ id: viewId, label, kind, reportId, permission });
      this.store.draftViews.push(view);
    }
    const siblings = this.store.draftNodes.filter((node) => node.parentId === parentId);
    const node: NavNode = {
      id: this.store.nextId('nav'),
      parentId,
      label,
      icon,
      order: Math.max(0, ...siblings.map((item) => item.order)) + 10,
      enabled: true,
      viewId,
    };
    this.store.draftNodes.push(node);
    return ok(node, 201);
  }

  private patchNode(id: string, body: unknown): HttpResponse<unknown> | HttpErrorResponse {
    const node = this.store.draftNodes.find((item) => item.id === id);
    if (!node) return fail(problem(404, 'not-found', 'Unknown navigation item'));
    if (!isRecord(body)) return fail(problem(400, 'invalid-body', 'Invalid update'));
    if (typeof body['label'] === 'string') {
      const label = cleanLabel(body['label']);
      if (!label) return fail(problem(422, 'validation', 'Enter a plain-text label'));
      node.label = label;
      if (node.viewId) {
        const view = this.store.draftViews.find((item) => item.id === node.viewId);
        if (view) view.label = label;
      }
    }
    if (typeof body['enabled'] === 'boolean') node.enabled = body['enabled'];
    return ok(node);
  }

  private moveNode(id: string, body: unknown): HttpResponse<unknown> | HttpErrorResponse {
    const node = this.store.draftNodes.find((item) => item.id === id);
    if (!node || !isRecord(body) || (body['direction'] !== 'up' && body['direction'] !== 'down')) {
      return fail(problem(400, 'invalid-body', 'Cannot move that item'));
    }
    const siblings = this.store.draftNodes
      .filter((item) => item.parentId === node.parentId)
      .sort((a, b) => a.order - b.order);
    const index = siblings.findIndex((item) => item.id === id);
    const swapIndex = body['direction'] === 'up' ? index - 1 : index + 1;
    const swap = siblings[swapIndex];
    if (!swap) return ok(node);
    const order = node.order;
    node.order = swap.order;
    swap.order = order;
    return ok(node);
  }

  private ratingQuery(body: unknown): HttpResponse<unknown> | HttpErrorResponse {
    const allowed = this.requireRating();
    if (allowed instanceof HttpErrorResponse) return allowed;
    const result = queryRatingJobs(this.store.ratingRuns, body);
    return result.ok ? ok(result.body) : fail(result.problem);
  }

  private ratingSummary(body: unknown): HttpResponse<unknown> | HttpErrorResponse {
    const allowed = this.requireRating();
    if (allowed instanceof HttpErrorResponse) return allowed;
    const result = summarizeRatingJobs(this.store.ratingRuns, body);
    return result.ok ? ok(result.body) : fail(result.problem);
  }

  private ratingAggregate(id: number, body: unknown): HttpResponse<unknown> | HttpErrorResponse {
    const allowed = this.requireRating();
    if (allowed instanceof HttpErrorResponse) return allowed;
    const job = listRatingJobs(this.store.ratingRuns).find((item) => item.id === id);
    if (!job) return fail(problem(404, 'not-found', 'That rating job is not available'));
    const result = queryAggregates(job, body);
    return result.ok ? ok(result.body) : fail(result.problem);
  }

  private ratingDifferences(id: number, body: unknown): HttpResponse<unknown> | HttpErrorResponse {
    const allowed = this.requireRating();
    if (allowed instanceof HttpErrorResponse) return allowed;
    const job = listRatingJobs(this.store.ratingRuns).find((item) => item.id === id);
    if (!job) return fail(problem(404, 'not-found', 'That rating job is not available'));
    const limit = isRecord(body) && typeof body['limit'] === 'number' ? body['limit'] : 8;
    if (!Number.isInteger(limit) || limit < 1 || limit > 20) {
      return fail(problem(400, 'invalid-body', 'Difference limit must be between 1 and 20'));
    }
    return ok(topDifferences(job, limit));
  }

  private ratingDetail(id: number): HttpResponse<unknown> | HttpErrorResponse {
    const allowed = this.requireRating();
    if (allowed instanceof HttpErrorResponse) return allowed;
    const job = listRatingJobs(this.store.ratingRuns).find((item) => item.id === id);
    if (!job) return fail(problem(404, 'not-found', 'That rating job is not available'));
    return ok({ ...detailFor(job), uploads: this.store.cslUploads.slice(0, 5) });
  }

  private ratingRun(body: unknown): HttpResponse<unknown> | HttpErrorResponse {
    const allowed = this.requireRating();
    if (allowed instanceof HttpErrorResponse) return allowed;
    if (!isRecord(body) || (body['stream'] !== 'IN' && body['stream'] !== 'BSCS')) {
      return fail(problem(422, 'validation', 'Choose stream IN or BSCS'));
    }
    const stream = body['stream'];
    const id = Math.max(0, ...listRatingJobs(this.store.ratingRuns).map((job) => job.id)) + 1;
    const now = new Date();
    const job: RatingJob = {
      id,
      streamName: stream,
      startTime: now.toISOString(),
      endTime: now.toISOString(),
      jobStatus: 1,
      statusDescr: statusLabel(1),
      decoded: 0,
      filtered: 0,
      rated: 0,
      erroredRate: 0,
    };
    this.store.ratingRuns.unshift(job);
    this.store.schedule(
      `rating_${id}`,
      500,
      1400,
      () => this.patchRating(id, { jobStatus: 2, statusDescr: statusLabel(2) }),
      () => {
        const counts = countsForNewRun(id);
        this.patchRating(id, {
          jobStatus: 3,
          statusDescr: statusLabel(3),
          endTime: new Date().toISOString(),
          ...counts,
        });
      },
    );
    return ok(job, 202);
  }

  private ratingCsl(body: unknown): HttpResponse<unknown> | HttpErrorResponse {
    const allowed = this.requireRating();
    if (allowed instanceof HttpErrorResponse) return allowed;
    if (!isRecord(body) || typeof body['name'] !== 'string' || typeof body['bytes'] !== 'number') {
      return fail(problem(400, 'invalid-body', 'CSL registration needs a file name and size'));
    }
    if (body['bytes'] > 262_144) {
      return fail(
        problem(413, 'payload-too-large', 'That CSL file is too large to hold in the browser', 'Register files up to 256 KB here. A production worker would store the object and return a reference.'),
      );
    }
    const upload = { name: body['name'].slice(0, 120), bytes: body['bytes'], at: new Date().toISOString() };
    this.store.cslUploads.unshift(upload);
    return ok(upload, 201);
  }

  private requireRating(): true | HttpErrorResponse {
    const session = this.requireSession();
    if (session instanceof HttpErrorResponse) return session;
    if (!session.permissions.includes('reports.read')) {
      return fail(problem(403, 'forbidden', 'You do not have access to rating validation'));
    }
    return true;
  }

  private patchRating(id: number, patch: Partial<RatingJob>): void {
    const job = this.store.ratingRuns.find((item) => item.id === id);
    if (!job) return;
    Object.assign(job, patch);
  }

  private authorizeReport(reportId: string): true | HttpErrorResponse {
    const session = this.requireSession();
    if (session instanceof HttpErrorResponse) return session;
    const report = reportById(reportId);
    if (!report) return fail(problem(404, 'not-found', 'Unknown report'));
    if (!session.permissions.includes(report.permission)) {
      return fail(problem(403, 'forbidden', 'You do not have access to this report'));
    }
    return true;
  }

  private requireSession(): { user: { id: string }; permissions: string[] } | HttpErrorResponse {
    const session = this.store.session();
    if (!session) return fail(problem(401, 'unauthenticated', 'Sign in to continue'));
    return session;
  }

  private ownedJob(jobId: string): ExportJob | HttpErrorResponse {
    const session = this.requireSession();
    if (session instanceof HttpErrorResponse) return session;
    const job = this.store.jobs.find((item) => item.id === jobId && item.ownerId === session.user.id);
    if (!job) return fail(problem(404, 'not-found', 'That export is not available'));
    return job;
  }

  private patchJob(jobId: string, patch: Partial<ExportJob>): void {
    const job = this.store.jobs.find((item) => item.id === jobId);
    if (!job || job.status === 'cancelled') return;
    Object.assign(job, patch);
  }
}

function visibleNodes(nodes: NavNode[], views: ViewDefinition[], permissions: string[]): NavNode[] {
  const enabled = nodes.filter((node) => node.enabled);
  const allowed = new Set<string>();
  for (const node of enabled) {
    if (!node.viewId) continue;
    const view = views.find((item) => item.id === node.viewId);
    if (view && permissions.includes(view.requiredPermission)) allowed.add(node.id);
  }
  let changed = true;
  while (changed) {
    changed = false;
    for (const node of enabled) {
      if (allowed.has(node.id) && node.parentId && !allowed.has(node.parentId)) {
        allowed.add(node.parentId);
        changed = true;
      }
    }
  }
  return enabled.filter((node) => allowed.has(node.id)).sort((a, b) => a.order - b.order);
}

function toCsv(columns: string[], rows: Record<string, string | number>[]): string {
  const header = columns.join(',');
  const lines = rows.map((row) => columns.map((column) => csvCell(row[column] ?? '')).join(','));
  return [header, ...lines].join('\n');
}

function csvCell(value: string | number): string {
  const text = String(value);
  if (/[",\n]/.test(text)) return `"${text.replaceAll('"', '""')}"`;
  return text;
}

function cleanLabel(value: string): string | null {
  const label = value.trim().replace(/\s+/g, ' ');
  if (!label || label.length > 60 || /[<>]/.test(label)) return null;
  return label;
}

function isIcon(value: unknown): value is IconKey {
  return typeof value === 'string' && (ICON_KEYS as readonly string[]).includes(value);
}

function isKind(value: unknown): value is ViewKind {
  return typeof value === 'string' && (VIEW_KINDS as readonly string[]).includes(value);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function ok(body: unknown, status = 200): HttpResponse<unknown> {
  return new HttpResponse({ status, body });
}

function fail(issue: Problem): HttpErrorResponse {
  return new HttpErrorResponse({ status: issue.status, statusText: issue.title, error: issue });
}
