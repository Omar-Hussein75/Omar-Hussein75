import type {
  ColumnDef,
  IconKey,
  ParameterDef,
  ReportSummary,
  ViewDefinition,
  ViewKind,
} from '../models/contracts';

export interface ReportField {
  key: string;
  label: string;
  type: 'string' | 'number' | 'date-time';
  sortable: boolean;
}

export interface ReportDef {
  id: string;
  label: string;
  permission: string;
  shape: 'timeline' | 'ledger';
  fields: ReportField[];
  maxWindowDays?: number;
  ledgerSize?: number;
  requires: string[];
}

export const PERMISSIONS = ['network.read', 'billing.read', 'reports.read', 'config.manage'] as const;

export const REGIONS = [
  { value: 'eu-west', label: 'EU West' },
  { value: 'eu-central', label: 'EU Central' },
  { value: 'us-east', label: 'US East' },
  { value: 'ap-south', label: 'AP South' },
] as const;

export const SITES = [
  { value: 'dub-1', label: 'Dublin 1', region: 'eu-west' },
  { value: 'dub-2', label: 'Dublin 2', region: 'eu-west' },
  { value: 'ams-1', label: 'Amsterdam 1', region: 'eu-central' },
  { value: 'fra-1', label: 'Frankfurt 1', region: 'eu-central' },
  { value: 'iad-1', label: 'Ashburn 1', region: 'us-east' },
  { value: 'iad-2', label: 'Ashburn 2', region: 'us-east' },
  { value: 'bom-1', label: 'Mumbai 1', region: 'ap-south' },
  { value: 'bom-2', label: 'Mumbai 2', region: 'ap-south' },
] as const;

export const CYCLES = [
  { value: '2026-07', label: 'July 2026' },
  { value: '2026-08', label: 'August 2026' },
  { value: '2026-09', label: 'September 2026' },
] as const;

const timelineFields: ReportField[] = [
  { key: 'id', label: 'Id', type: 'string', sortable: true },
  { key: 'timestamp', label: 'Time', type: 'date-time', sortable: true },
  { key: 'regionCode', label: 'Region', type: 'string', sortable: true },
  { key: 'site', label: 'Site', type: 'string', sortable: true },
  { key: 'status', label: 'Status', type: 'string', sortable: true },
  { key: 'latencyMs', label: 'Latency (ms)', type: 'number', sortable: true },
  { key: 'lossPct', label: 'Loss %', type: 'number', sortable: true },
  { key: 'bytes', label: 'Bytes', type: 'number', sortable: true },
];

export const REPORTS: ReportDef[] = [
  {
    id: 'network_performance',
    label: 'Network performance',
    permission: 'network.read',
    shape: 'timeline',
    fields: timelineFields,
    maxWindowDays: 31,
    requires: ['timestamp'],
  },
  {
    id: 'network_traffic',
    label: 'Network traffic',
    permission: 'network.read',
    shape: 'timeline',
    fields: timelineFields,
    maxWindowDays: 14,
    requires: ['timestamp'],
  },
  {
    id: 'network_availability',
    label: 'Network availability',
    permission: 'network.read',
    shape: 'timeline',
    fields: timelineFields,
    maxWindowDays: 31,
    requires: ['timestamp'],
  },
  {
    id: 'customer_accounts',
    label: 'Customer accounts',
    permission: 'billing.read',
    shape: 'ledger',
    ledgerSize: 180_000,
    requires: [],
    fields: [
      { key: 'id', label: 'Id', type: 'string', sortable: true },
      { key: 'name', label: 'Customer', type: 'string', sortable: true },
      { key: 'regionCode', label: 'Region', type: 'string', sortable: true },
      { key: 'status', label: 'Status', type: 'string', sortable: true },
      { key: 'mrr', label: 'MRR', type: 'number', sortable: true },
    ],
  },
  {
    id: 'billing_lines',
    label: 'Billing lines',
    permission: 'billing.read',
    shape: 'ledger',
    ledgerSize: 80_000,
    requires: ['cycle'],
    fields: [
      { key: 'id', label: 'Id', type: 'string', sortable: true },
      { key: 'cycle', label: 'Cycle', type: 'string', sortable: false },
      { key: 'customer', label: 'Customer', type: 'string', sortable: true },
      { key: 'service', label: 'Service', type: 'string', sortable: true },
      { key: 'status', label: 'Status', type: 'string', sortable: true },
      { key: 'amount', label: 'Amount', type: 'number', sortable: true },
    ],
  },
  {
    id: 'reconciliation_breaks',
    label: 'Reconciliation breaks',
    permission: 'billing.read',
    shape: 'ledger',
    ledgerSize: 12_000,
    requires: ['cycle'],
    fields: [
      { key: 'id', label: 'Id', type: 'string', sortable: true },
      { key: 'cycle', label: 'Cycle', type: 'string', sortable: false },
      { key: 'customer', label: 'Customer', type: 'string', sortable: true },
      { key: 'breakType', label: 'Break', type: 'string', sortable: true },
      { key: 'status', label: 'Status', type: 'string', sortable: true },
      { key: 'amount', label: 'Amount', type: 'number', sortable: true },
    ],
  },
  {
    id: 'rating_validation_jobs',
    label: 'Rating validation jobs',
    permission: 'reports.read',
    shape: 'ledger',
    ledgerSize: 44,
    requires: [],
    fields: [
      { key: 'id', label: 'Id', type: 'string', sortable: true },
      { key: 'streamName', label: 'Stream', type: 'string', sortable: true },
      { key: 'startTime', label: 'Start', type: 'date-time', sortable: true },
      { key: 'endTime', label: 'End', type: 'date-time', sortable: true },
      { key: 'jobStatus', label: 'Status', type: 'number', sortable: true },
      { key: 'statusDescr', label: 'Status description', type: 'string', sortable: false },
      { key: 'decoded', label: 'Decoded', type: 'number', sortable: true },
      { key: 'filtered', label: 'Filtered', type: 'number', sortable: true },
      { key: 'rated', label: 'Rated', type: 'number', sortable: true },
      { key: 'erroredRate', label: 'Errored', type: 'number', sortable: true },
    ],
  },
];

export function reportById(id: string): ReportDef | undefined {
  return REPORTS.find((report) => report.id === id);
}

export function reportSummaries(): ReportSummary[] {
  return REPORTS.map((report) => ({ id: report.id, label: report.label, permission: report.permission }));
}

const dateRange = (): ParameterDef[] => [
  {
    key: 'startDate',
    label: 'Start',
    type: 'date-time',
    required: true,
    bindsTo: 'timestamp',
    operator: 'gte',
  },
  {
    key: 'endDate',
    label: 'End',
    type: 'date-time',
    required: true,
    bindsTo: 'timestamp',
    operator: 'lt',
  },
  {
    key: 'region',
    label: 'Region',
    type: 'multi-select',
    required: false,
    bindsTo: 'regionCode',
    operator: 'in',
    source: { kind: 'reference', name: 'regions' },
  },
];

export function seedViews(): ViewDefinition[] {
  return [
    {
      id: 'view_overview',
      label: 'Overview',
      description: 'Warehouse aggregates for the default window. Cards request summaries, not raw samples.',
      kind: 'dashboard',
      reportId: 'network_performance',
      requiredPermission: 'reports.read',
      defaults: { startDate: 'P7D', endDate: 'now', region: [] },
      parameters: dateRange(),
      constraints: { maxWindowDays: 31 },
      widgets: [
        {
          id: 'latency',
          title: 'Average latency',
          reportId: 'network_performance',
          permission: 'network.read',
          presentation: 'kpi',
          metric: 'avgLatencyMs',
          unit: 'ms',
        },
        {
          id: 'loss',
          title: 'Average loss',
          reportId: 'network_performance',
          permission: 'network.read',
          presentation: 'kpi',
          metric: 'avgLossPct',
          unit: '%',
        },
        {
          id: 'uptime',
          title: 'Uptime',
          reportId: 'network_availability',
          permission: 'network.read',
          presentation: 'kpi',
          metric: 'uptimePct',
          unit: '%',
        },
        {
          id: 'traffic',
          title: 'Traffic',
          reportId: 'network_traffic',
          permission: 'network.read',
          presentation: 'line',
          metric: 'sumBytes',
          unit: 'bytes',
        },
      ],
    },
    {
      id: 'view_customers',
      label: 'Customer Data',
      description: 'Account directory. The server returns one page. The full ledger stays in the warehouse.',
      kind: 'data-table',
      reportId: 'customer_accounts',
      requiredPermission: 'billing.read',
      defaults: { region: [], status: '', search: '' },
      parameters: [
        {
          key: 'region',
          label: 'Region',
          type: 'multi-select',
          required: false,
          bindsTo: 'regionCode',
          operator: 'in',
          source: { kind: 'reference', name: 'regions' },
        },
        {
          key: 'status',
          label: 'Status',
          type: 'select',
          required: false,
          bindsTo: 'status',
          operator: 'eq',
          source: {
            kind: 'static',
            options: [
              { value: 'ACTIVE', label: 'Active' },
              { value: 'INACTIVE', label: 'Inactive' },
            ],
          },
        },
        {
          key: 'search',
          label: 'Customer search',
          type: 'text',
          required: false,
          bindsTo: 'name',
          operator: 'contains',
        },
      ],
      constraints: {},
      table: {
        columns: [
          { key: 'name', label: 'Customer', sortable: true, type: 'string' },
          { key: 'regionCode', label: 'Region', sortable: true, type: 'string' },
          { key: 'status', label: 'Status', sortable: true, type: 'string' },
          { key: 'mrr', label: 'MRR', sortable: true, type: 'number' },
        ],
        defaultColumns: ['name', 'regionCode', 'status', 'mrr'],
        defaultSort: [{ field: 'name', direction: 'asc' }],
      },
    },
    {
      id: 'view_net_perf',
      label: 'Network performance',
      description: 'Latency for the selected window, aggregated before it reaches the chart.',
      kind: 'time-series',
      reportId: 'network_performance',
      requiredPermission: 'network.read',
      defaults: { startDate: 'P7D', endDate: 'now', region: [] },
      parameters: dateRange(),
      constraints: { maxWindowDays: 31 },
      chart: {
        timeField: 'timestamp',
        defaultBucket: 'hour',
        buckets: ['hour', 'day'],
        maxPoints: 2000,
        metric: 'avgLatencyMs',
        metricLabel: 'Avg latency',
        unit: 'ms',
      },
    },
    {
      id: 'view_availability',
      label: 'Availability',
      description: 'Uptime is computed in the warehouse for the selected window.',
      kind: 'kpi-board',
      reportId: 'network_availability',
      requiredPermission: 'network.read',
      defaults: { startDate: 'P7D', endDate: 'now', region: [] },
      parameters: dateRange(),
      constraints: { maxWindowDays: 31 },
      kpis: [
        { key: 'uptimePct', label: 'Uptime', unit: '%' },
        { key: 'sampleCount', label: 'Samples in window' },
        { key: 'avgLossPct', label: 'Average loss', unit: '%' },
      ],
    },
    {
      id: 'view_traffic',
      label: 'Traffic',
      description: 'Byte volume by bucket. A minute bucket over a long window is rejected before any points are drawn.',
      kind: 'time-series',
      reportId: 'network_traffic',
      requiredPermission: 'network.read',
      defaults: { startDate: 'P7D', endDate: 'now', region: [] },
      parameters: dateRange(),
      constraints: { maxWindowDays: 14 },
      chart: {
        timeField: 'timestamp',
        defaultBucket: 'hour',
        buckets: ['minute', 'hour', 'day'],
        maxPoints: 2000,
        metric: 'sumBytes',
        metricLabel: 'Bytes',
        unit: 'bytes',
      },
    },
    {
      id: 'view_billing',
      label: 'Billing',
      description: 'Invoice lines for one billing cycle, one page at a time.',
      kind: 'data-table',
      reportId: 'billing_lines',
      requiredPermission: 'billing.read',
      defaults: { cycle: '2026-09', status: '', search: '' },
      parameters: [
        {
          key: 'cycle',
          label: 'Billing cycle',
          type: 'select',
          required: true,
          bindsTo: 'cycle',
          operator: 'eq',
          source: { kind: 'static', options: [...CYCLES] },
        },
        {
          key: 'status',
          label: 'Status',
          type: 'select',
          required: false,
          bindsTo: 'status',
          operator: 'eq',
          source: {
            kind: 'static',
            options: [
              { value: 'POSTED', label: 'Posted' },
              { value: 'DISPUTED', label: 'Disputed' },
            ],
          },
        },
        {
          key: 'search',
          label: 'Customer',
          type: 'text',
          required: false,
          bindsTo: 'customer',
          operator: 'contains',
        },
      ],
      constraints: {},
      table: {
        columns: [
          { key: 'customer', label: 'Customer', sortable: true, type: 'string' },
          { key: 'service', label: 'Service', sortable: true, type: 'string' },
          { key: 'status', label: 'Status', sortable: true, type: 'string' },
          { key: 'amount', label: 'Amount', sortable: true, type: 'number' },
        ],
        defaultColumns: ['customer', 'service', 'status', 'amount'],
        defaultSort: [{ field: 'amount', direction: 'desc' }],
      },
    },
    {
      id: 'view_recon',
      label: 'Reconciliation',
      description: 'Breaks for a single cycle. Sorting and paging run on the server.',
      kind: 'data-table',
      reportId: 'reconciliation_breaks',
      requiredPermission: 'billing.read',
      defaults: { cycle: '2026-09', status: '' },
      parameters: [
        {
          key: 'cycle',
          label: 'Billing cycle',
          type: 'select',
          required: true,
          bindsTo: 'cycle',
          operator: 'eq',
          source: { kind: 'static', options: [...CYCLES] },
        },
        {
          key: 'status',
          label: 'Status',
          type: 'select',
          required: false,
          bindsTo: 'status',
          operator: 'eq',
          source: {
            kind: 'static',
            options: [
              { value: 'OPEN', label: 'Open' },
              { value: 'RESOLVED', label: 'Resolved' },
            ],
          },
        },
      ],
      constraints: {},
      table: {
        columns: [
          { key: 'customer', label: 'Customer', sortable: true, type: 'string' },
          { key: 'breakType', label: 'Break', sortable: true, type: 'string' },
          { key: 'status', label: 'Status', sortable: true, type: 'string' },
          { key: 'amount', label: 'Amount', sortable: true, type: 'number' },
        ],
        defaultColumns: ['customer', 'breakType', 'status', 'amount'],
        defaultSort: [{ field: 'amount', direction: 'desc' }],
      },
    },
    {
      id: 'view_rating_admin',
      label: 'Job Admin',
      description: 'Rating validation runs for the selected month. The list is a page of jobs. Counts on each run are already aggregated.',
      kind: 'rating-jobs',
      reportId: 'rating_validation_jobs',
      requiredPermission: 'reports.read',
      defaults: {},
      parameters: [],
      constraints: { maxWindowDays: 31 },
    },
    {
      id: 'view_rating_summary',
      label: 'Job Summary',
      description: 'Totals for the rating jobs in the selected window. These figures come from the job results, not from raw CDRs.',
      kind: 'rating-jobs',
      reportId: 'rating_validation_jobs',
      requiredPermission: 'reports.read',
      defaults: {},
      parameters: [],
      constraints: { maxWindowDays: 31 },
    },
    {
      id: 'view_reports',
      label: 'Reports',
      description: 'Export jobs are built on the server. This screen only tracks status and downloads the finished file.',
      kind: 'export',
      reportId: 'network_performance',
      requiredPermission: 'reports.read',
      defaults: {},
      parameters: [],
      constraints: {},
    },
  ];
}

export function columnsFor(keys: string[], fields: ReportField[]): ColumnDef[] {
  return keys.map((key) => {
    const field = fields.find((item) => item.key === key);
    if (!field) throw new Error(`Unknown column ${key}`);
    return { key, label: field.label, sortable: field.sortable, type: field.type };
  });
}

export function synthesizeView(input: {
  id: string;
  label: string;
  kind: ViewKind;
  reportId: string;
  permission: string;
}): ViewDefinition {
  const existing = seedViews().find((view) => view.reportId === input.reportId && view.kind === input.kind);
  if (existing) {
    return {
      ...existing,
      id: input.id,
      label: input.label,
      requiredPermission: input.permission,
      widgets: existing.widgets?.map((widget) => ({ ...widget })),
      parameters: existing.parameters.map((parameter) => ({ ...parameter })),
    };
  }
  const report = reportById(input.reportId);
  return {
    id: input.id,
    label: input.label,
    description: `${input.label} is bound to catalog report ${input.reportId}.`,
    kind: input.kind,
    reportId: input.reportId,
    requiredPermission: input.permission,
    defaults: {},
    parameters: [],
    constraints: report?.maxWindowDays ? { maxWindowDays: report.maxWindowDays } : {},
  };
}

export const ICON_ALLOWLIST: readonly IconKey[] = [
  'dashboard',
  'users',
  'network',
  'activity',
  'pulse',
  'traffic',
  'billing',
  'reconcile',
  'reports',
  'rating',
  'folder',
];
