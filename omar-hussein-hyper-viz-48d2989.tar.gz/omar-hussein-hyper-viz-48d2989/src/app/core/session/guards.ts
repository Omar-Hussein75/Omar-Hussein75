import { HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { catchError, map, of } from 'rxjs';
import { SessionStore } from './session-store';

export const sessionGuard: CanActivateFn = () => {
  const session = inject(SessionStore);
  const router = inject(Router);
  if (session.session()) return true;
  return session.probe().pipe(
    map(() => true),
    catchError((error: unknown) => {
      if (error instanceof HttpErrorResponse && error.status === 401) {
        return of(router.createUrlTree(['/login']));
      }
      return of(router.createUrlTree(['/login']));
    }),
  );
};

export const adminGuard: CanActivateFn = () => {
  const session = inject(SessionStore);
  const router = inject(Router);
  const current = session.session();
  if (current?.permissions.includes('config.manage')) return true;
  return router.createUrlTree(['/app']);
};
