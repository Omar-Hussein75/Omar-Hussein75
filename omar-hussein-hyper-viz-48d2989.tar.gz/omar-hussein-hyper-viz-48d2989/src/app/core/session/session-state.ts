import { Injectable, inject } from '@angular/core';
import { ContractStore } from '../mock/contract-store';

@Injectable({ providedIn: 'root' })
export class SessionState {
  private readonly store = inject(ContractStore);
  readonly session = this.store.session;
}
