import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import type { Session } from '../models/contracts';
import { SessionState } from './session-state';

@Injectable({ providedIn: 'root' })
export class SessionStore {
  private readonly http = inject(HttpClient);
  private readonly state = inject(SessionState);
  readonly session = this.state.session;

  probe() {
    return this.http.get<Session>('/api/session');
  }

  login(userId: string) {
    return this.http.post<Session>('/api/session/login', { userId });
  }

  logout() {
    return this.http.post<{ ok: boolean }>('/api/session/logout', {});
  }
}
