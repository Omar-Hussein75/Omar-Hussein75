export const VIEW_KINDS = ['dashboard', 'data-table', 'time-series', 'kpi-board', 'export', 'rating-jobs'] as const;
export type ViewKind = (typeof VIEW_KINDS)[number];

export const ICON_KEYS = [
  'dashboard',
  'users',
  'network',
  'activity',
  'pulse',
  'traffic',
  'billing',
  'reconcile',
  'reports',
  'rating',
  'folder',
] as const;
export type IconKey = (typeof ICON_KEYS)[number];

export interface Session {
  user: { id: string; displayName: string; roleLabel: string };
  permissions: string[];
  configVersion: number;
}

export interface NavNode {
  id: string;
  parentId: string | null;
  label: string;
  icon: IconKey;
  order: number;
  enabled: boolean;
  viewId: string | null;
}

export interface NavPayload {
  version: number;
  nodes: NavNode[];
}

export interface ParameterOption {
  value: string;
  label: string;
}

export interface ParameterDef {
  key: string;
  label: string;
  type: 'date-time' | 'select' | 'multi-select' | 'text';
  required: boolean;
  bindsTo: string;
  operator: 'eq' | 'in' | 'gte' | 'lt' | 'contains';
  source?:
    | { kind: 'static'; options: ParameterOption[] }
    | { kind: 'reference'; name: string };
}

export interface ColumnDef {
  key: string;
  label: string;
  sortable: boolean;
  type: 'string' | 'number' | 'date-time';
}

export interface SortSpec {
  field: string;
  direction: 'asc' | 'desc';
}

export interface WidgetDef {
  id: string;
  title: string;
  reportId: string;
  permission: string;
  presentation: 'kpi' | 'line';
  metric: string;
  unit?: string;
}

export interface ViewDefinition {
  id: string;
  label: string;
  description: string;
  kind: ViewKind;
  reportId: string;
  requiredPermission: string;
  defaults: Record<string, string | string[]>;
  parameters: ParameterDef[];
  constraints: { maxWindowDays?: number };
  table?: {
    columns: ColumnDef[];
    defaultColumns: string[];
    defaultSort: SortSpec[];
  };
  chart?: {
    timeField: string;
    defaultBucket: Bucket;
    buckets: Bucket[];
    maxPoints: number;
    metric: string;
    metricLabel: string;
    unit?: string;
  };
  kpis?: { key: string; label: string; unit?: string }[];
  widgets?: WidgetDef[];
}

export type Bucket = 'minute' | 'hour' | 'day';

export interface FilterCondition {
  field: string;
  op: 'eq' | 'in' | 'gte' | 'lt' | 'contains';
  value: string | string[];
}

export interface FilterTree {
  op: 'and';
  conditions: FilterCondition[];
}

export type FilterDraft = Record<string, string | string[]>;

export interface QueryRequest {
  filter: FilterTree;
  sort: SortSpec[];
  page: { limit: number; cursor: string | null; includeTotal: boolean };
  columns: string[];
}

export interface QueryResponse {
  rows: Record<string, string | number>[];
  page: {
    limit: number;
    nextCursor: string | null;
    prevCursor: string | null;
    hasMore: boolean;
  };
  total: number | null;
  meta: { queryMs: number; columns: string[] };
}

export interface AggregateRequest {
  filter: FilterTree;
  time?: { field: string; bucket: Bucket };
  metric?: string;
  maxPoints?: number;
  kpis?: string[];
}

export interface SeriesPoint {
  t: string;
  v: number;
}

export interface AggregateResponse {
  bucket?: Bucket;
  series?: { name: string; points: SeriesPoint[] };
  metrics?: Record<string, number>;
  meta: { queryMs: number; pointCount: number; truncated: false };
}

export interface Problem {
  type: string;
  title: string;
  status: number;
  detail?: string;
  errors?: { field?: string; code: string; suggestion?: string }[];
}

export interface ReferenceItem {
  value: string;
  label: string;
}

export interface ExportJob {
  id: string;
  status: 'queued' | 'running' | 'ready' | 'failed' | 'cancelled' | 'expired';
  reportId: string;
  format: 'csv';
  bytes: number | null;
  rowCount: number | null;
  truncated: boolean;
  detail: string | null;
  createdAt: string;
  finishedAt: string | null;
  expiresAt: string | null;
  ownerId: string;
}

export interface ReportSummary {
  id: string;
  label: string;
  permission: string;
}

export interface AdminCatalog {
  permissions: string[];
  icons: IconKey[];
  kinds: ViewKind[];
  reports: ReportSummary[];
}

export type UiKind =
  | 'loading'
  | 'empty'
  | 'error'
  | 'timeout'
  | 'forbidden'
  | 'not-found'
  | 'point-cap'
  | 'rate-limited'
  | 'processing';
