import { Routes } from '@angular/router';
import { adminGuard, sessionGuard } from './core/session/guards';

export const routes: Routes = [
  { path: 'login', loadComponent: () => import('./features/login/login').then((module) => module.Login) },
  {
    path: 'app',
    canActivate: [sessionGuard],
    loadComponent: () => import('./layout/shell/shell').then((module) => module.Shell),
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'views/view_overview' },
      {
        path: 'views/:viewId',
        loadComponent: () => import('./features/view-host/view-host').then((module) => module.ViewHost),
      },
      {
        path: 'exports/:jobId',
        loadComponent: () => import('./features/exports/export-job').then((module) => module.ExportJobPage),
      },
    ],
  },
  {
    path: 'admin',
    canActivate: [sessionGuard, adminGuard],
    loadComponent: () => import('./layout/shell/shell').then((module) => module.Shell),
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'navigation' },
      {
        path: 'navigation',
        loadComponent: () => import('./features/admin/navigation-admin').then((module) => module.NavigationAdmin),
      },
    ],
  },
  { path: '', pathMatch: 'full', redirectTo: 'app' },
  { path: '**', redirectTo: 'app' },
];
